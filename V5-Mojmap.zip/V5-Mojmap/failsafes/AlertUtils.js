import { drawRect, drawText } from '../gui/Utils';
import { chatFailsafe } from '../utils/Chat';
import { AudioSystem, File, FloatControl, GLFW, globalAssetsDir, IS_MC_26_3, SDLVideo } from '../utils/Constants';
import { getConfigFile, writeConfigFile } from '../utils/Utils';
import FailsafeUtils from './FailsafeUtils';

let failsafeSound = 'Tave Check.wav';

// todo
// touchen up colours rn they ugly
// touch up code
// rewrite some stuff!
// allow edit of failsafe sound

class AlertUtilsClass {
    constructor() {
        this.clip = null;
        this.audioStream = null;
        this.gainControl = null;
        this.savedSound = null;
        this.isAlerting = false;

        this.cancelKeyBind = null;
        this.cancelKey = null;

        this.render = null;
        this.tracker = null;

        this._makeFailsafeKeybind();

        register('command', () => {
            AlertUtils.triggerReaction();
        }).setName('trigger');
    }

    /**
     * Combines all internal methods to create a failsafe alert
     */
    triggerReaction() {
        if (this.isAlerting) return;

        chatFailsafe('Suspicious activity detected, reaction occuring!');
        chatFailsafe(`Press &c&l${this.cancelKey}&r &fto disable the reaction`);

        this.isAlerting = true;
        this.playSound();
        this._grabWindowOnFailsafe();

        const line1 = 'V5 BELIEVES YOU HAVE BEEN MACRO CHECKED!';
        const key = this.cancelKey;
        const line2Start = 'PRESS ';
        const line2End = ' TO DISABLE THE REACTION';

        const fontSize = 20;
        const lineSpacing = 8;
        const yOffset = 100;
        const redColor = Math.trunc(0xffff0000); // change this
        const highlightColor = Math.trunc(0xffffffff); // this too

        this.render = register('renderOverlay', () => {
            const screenW = Render2D.screen.getWidth();
            const screenH = Render2D.screen.getHeight();
            try {
                Render2D.save();
                this._renderAlertScreen(screenW, screenH);

                const scale = fontSize / 10;
                const x1 = screenW / 2 - (Render2D.getStringWidth(line1) * scale) / 2;
                const totalLine2Width = (Render2D.getStringWidth(line2Start) + Render2D.getStringWidth(key) + Render2D.getStringWidth(line2End)) * scale;
                let currentX2 = screenW / 2 - totalLine2Width / 2;

                const totalBlockHeight = fontSize * 2 + lineSpacing;
                const startY = screenH / 2 - totalBlockHeight / 2 - yOffset;
                const y2 = startY + fontSize + lineSpacing;

                drawText(line1, x1, startY, fontSize, redColor);
                drawText(line2Start, currentX2, y2, fontSize, redColor);

                currentX2 += Render2D.getStringWidth(line2Start) * scale;
                drawText(key, currentX2, y2, fontSize, highlightColor);

                currentX2 += Render2D.getStringWidth(key) * scale;
                drawText(line2End, currentX2, y2, fontSize, redColor);
                Render2D.restore();
            } catch (e) {
                console.error(e);
            }
        });
    }

    /**
     * Disables the reaction & nulls all registers included
     */
    disableReaction() {
        this.isAlerting = false;
        this.stopSound();

        if (this.render) {
            this.render.unregister();
            this.render = null;
        }

        if (this.tracker) {
            this.tracker.unregister();
            this.tracker = null;
        }
    }

    /**
     * Plays a sound if the player has the setting toggled
     */
    playSound() {
        if (!FailsafeUtils.getFailsafeSettings('Play sound on check').playSoundOnCheck) return;
        const currentSound = failsafeSound;
        if (!this.clip || this.savedSound !== currentSound) this._loadsoundFile();

        if (this.clip) {
            this.clip.stop();
            this.clip.setFramePosition(0);
            this.clip.start();
        }
    }

    /**
     * Stops any sounds from playing
     */
    stopSound() {
        if (this.clip && this.clip.isRunning()) this.clip.stop();
    }

    setFailsafeSound(fileName) {
        failsafeSound = fileName;
    }

    /**
     * Loads a sound file using Java methods
     */
    _loadsoundFile() {
        this._closeSound();

        const currentSound = failsafeSound;
        this.savedSound = !currentSound || currentSound.includes('undefined') ? 'Tave Check.wav' : currentSound;

        this.soundFile = new File(globalAssetsDir, `failsafes/sounds/${this.savedSound}`);
        if (!this.soundFile.exists()) return;

        try {
            this.audioStream = AudioSystem.getAudioInputStream(this.soundFile);
            this.clip = AudioSystem.getClip();
            this.clip.open(this.audioStream);
            if (this.clip.isControlSupported(FloatControl.Type.MASTER_GAIN)) {
                this.gainControl = this.clip.getControl(FloatControl.Type.MASTER_GAIN);
            }
        } catch (e) {
            this._closeSound();
            console.error(e);
        }
    }

    _closeSound() {
        if (this.clip) {
            try {
                this.clip.stop();
                this.clip.close();
            } catch (e) {
                console.error(e);
            }
            this.clip = null;
        }

        if (this.audioStream) {
            try {
                this.audioStream.close();
            } catch (e) {
                console.error(e);
            }
            this.audioStream = null;
        }
        this.gainControl = null;
    }

    /**
     * Uses Render2D to draw a overlay over the whole screen
     */
    _renderAlertScreen(screenW, screenH) {
        if (Client.isInChat()) return;
        drawRect({
            x: 0,
            y: 0,
            width: screenW,
            height: screenH,
            color: Math.trunc((120 << 24) | (255 << 16) | (0 << 8)), // change this too pls
        });
    }

    /**
     * Creates a keybind for canceling the reaction
     */
    _makeFailsafeKeybind() {
        const keyName = 'Cancel Reaction';
        const existingKeybinds = getConfigFile('keybinds.json') || {};
        let savedKeycode = existingKeybinds[keyName];

        if (savedKeycode === undefined || savedKeycode === 0 || savedKeycode === -1) savedKeycode = Keyboard.KEY_K;

        this.cancelKeyBind = new KeyBind(keyName, savedKeycode, 'v5_core');
        this.cancelKey = this.cancelKeyBind.getKeyName();

        this.cancelKeyBind.registerKeyPress(() => {
            if (!this.isAlerting) return;
            chatFailsafe('Reaction disabled due to keybind being pressed');
            this.disableReaction();
        });

        register('gameUnload', () => {
            this.disableReaction();
            this._closeSound();
            const allKeybinds = getConfigFile('keybinds.json') || {};
            allKeybinds[keyName] = this.cancelKeyBind.getKeyCode();
            writeConfigFile('keybinds.json', allKeybinds);
        });
    }

    _grabWindowOnFailsafe() {
        try {
            const windowHandle = Client.getMinecraft().getWindow().handle();

            if (IS_MC_26_3) {
                const flags = SDLVideo.SDL_GetWindowFlags(windowHandle);
                const wasIconified = (flags & SDLVideo.SDL_WINDOW_MINIMIZED) !== 0;
                const wasMaximized = (flags & SDLVideo.SDL_WINDOW_MAXIMIZED) !== 0;

                SDLVideo.SDL_ShowWindow(windowHandle);
                if (wasIconified) SDLVideo.SDL_RestoreWindow(windowHandle);
                if (wasMaximized) SDLVideo.SDL_MaximizeWindow(windowHandle);
                SDLVideo.SDL_RaiseWindow(windowHandle);
                SDLVideo.SDL_FlashWindow(windowHandle, SDLVideo.SDL_FLASH_UNTIL_FOCUSED);
                return;
            }

            const wasIconified = GLFW.glfwGetWindowAttrib(windowHandle, GLFW.GLFW_ICONIFIED) === GLFW.GLFW_TRUE;
            const wasMaximized = GLFW.glfwGetWindowAttrib(windowHandle, GLFW.GLFW_MAXIMIZED) === GLFW.GLFW_TRUE;

            GLFW.glfwSetWindowAttrib(windowHandle, GLFW.GLFW_FOCUS_ON_SHOW, GLFW.GLFW_TRUE);
            GLFW.glfwShowWindow(windowHandle);

            if (wasIconified) {
                GLFW.glfwRestoreWindow(windowHandle);
            }

            if (wasMaximized) {
                GLFW.glfwMaximizeWindow(windowHandle);
            }

            GLFW.glfwFocusWindow(windowHandle);
            GLFW.glfwRequestWindowAttention(windowHandle);
        } catch (e) {
            chatFailsafe('Window error occurred! Report this. ' + e);
            console.error(e);
        }
    }
}

export const AlertUtils = new AlertUtilsClass();

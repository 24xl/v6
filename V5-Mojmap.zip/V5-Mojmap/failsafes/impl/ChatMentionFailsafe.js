import { chatFailsafe } from '../../utils/Chat';
import { Failsafe } from '../Failsafe';
import FailsafeUtils from '../FailsafeUtils';
import { ClientboundSystemChatPacket } from '../../utils/Packets';

class ChatMentionFailsafe extends Failsafe {
    constructor() {
        super();
        this.settings = FailsafeUtils.getFailsafeSettings('Chat Mention');
        this.registerChatListeners();
        this.FailsafeReactionTime = 600;
        this.isFailsafeEnabled = true;
        this.mediumBlacklist = ['idk what words to put here they are all high or completely useless'].map((word) => word.toLowerCase());
        this.highBlacklist = ['wdr', 'report', 'macro', 'cheat', 'exploit', 'hack', 'bot', `${Player.getName()}`].map((word) => word.toLowerCase());
    }

    registerChatListeners() {
        register('packetReceived', (packet) => {
            if (!this.isActive() || this.disabled) return;
            if (packet.overlay()) return; // action bar

            this.settings = FailsafeUtils.getFailsafeSettings('Chat Mention');
            if (!this.settings.isEnabled) return;
            this.FailsafeReactionTime = this.settings.FailsafeReactionTime || 600;

            const content = packet.content().getString();
            const colonIndex = content.indexOf(':');
            if (colonIndex === -1) return;
            const messageBody = content.slice(colonIndex + 1).trim();

            const result = this.scanMessage(messageBody, content.trim());
            if (!result.isBlocked) return;

            this.onTrigger(result);
        }).setFilteredClass(ClientboundSystemChatPacket);
    }

    scanMessage(msg, fullMessage = msg) {
        const lower = msg.toLowerCase();
        const highMatch = this.highBlacklist.find((word) => lower.includes(word));
        const mediumMatch = this.mediumBlacklist.find((word) => lower.includes(word));
        const isBlocked = !!highMatch || !!mediumMatch;
        const isHigh = !!highMatch;
        const blockedWord = highMatch || mediumMatch;

        return { isBlocked, blockedWord, isHigh, fullMessage };
    }

    onTrigger(result) {
        const pressure = result.isHigh ? 30 : 10;
        const severity = result.isHigh ? 'high' : 'medium';
        const embedColour = result.isHigh ? 16744448 : 16776960;

        chatFailsafe(`&c&lDetected blacklisted word - "${result.blockedWord}"!`);
        FailsafeUtils.incrementFailsafeIntensity(pressure);
        FailsafeUtils.sendFailsafeEmbed(
            'Chat Mention',
            severity,
            `Someone mentioned: "${result.blockedWord}"\nFull message: "${result.fullMessage}"`,
            embedColour
        );
    }
}

new ChatMentionFailsafe();

import { AlertUtils } from '../../failsafes/AlertUtils';
import { getSetting } from '../../gui/GuiSave';
import { File, globalAssetsDir } from '../../utils/Constants';
import { ModuleBase } from '../../utils/ModuleBase';
import { ClientboundDisconnectPacket, ClientboundLoginDisconnectPacket } from '../../utils/Packets';
import { getLastActiveMacros, getLastDisableMeta, getStartTime, isMacroRunning } from '../../utils/MacroState';
import { formatUptime } from '../../utils/TimeUtils';
const JURL = Java.type('java.net.URL');
const JOutputStreamWriter = Java.type('java.io.OutputStreamWriter');

class Failsafes extends ModuleBase {
    constructor() {
        super({
            name: 'Failsafes',
            subcategory: 'Core',
            description: 'Failsafe settings.',
            tooltip: 'Failsafe config.',
            hideInModules: true,
        });

        this.tp = true;
        this.rotation = true;
        this.velocity = true;
        this.slotChange = true;
        this.chatMention = true;
        this.playerGrief = true;
        this.clipOnBan = true;
        this.playerProximityDistance = 3;
        this.actionDelay = { low: 500, high: 2000 };
        this.pingOnCheck = 'Ping';
        this.playSoundOnCheck = true;
        this.lastBanLogTime = 0;

        register('packetReceived', (packet) => {
            const reason = packet?.reason();
            const fullText = reason?.getString?.() || reason?.toString?.();
            const lowerText = fullText?.toLowerCase();

            if (this.isBanReason(lowerText)) this.postBanLog(fullText);
        }).setFilteredClasses([ClientboundLoginDisconnectPacket, ClientboundDisconnectPacket]);

        const sectionName = 'Failsafes';

        this.addDirectMultiToggle(
            'Enabled Failsafes',
            ['TP', 'Rotation', 'Velocity', 'Slot Change', 'Chat Mention', 'Player Grief'],
            false,
            (value) => {
                const enabled = Array.isArray(value) ? value : [];
                this.tp = enabled.includes('TP');
                this.rotation = enabled.includes('Rotation');
                this.velocity = enabled.includes('Velocity');
                this.slotChange = enabled.includes('Slot Change');
                this.chatMention = enabled.includes('Chat Mention');
                this.playerGrief = enabled.includes('Player Grief');
            },
            'Select which failsafes are enabled',
            ['TP', 'Rotation', 'Velocity', 'Slot Change', 'Chat Mention', 'Player Grief'],
            sectionName
        );
        this.addDirectRangeSlider(
            'Failsafe Detection Delay (ms)',
            500,
            5000,
            this.actionDelay,
            (value) => {
                this.actionDelay = value;
            },
            'Delay in milliseconds between detection of failsafe',
            sectionName
        );
        this.addDirectSlider(
            'Player Proximity Distance',
            1,
            10,
            this.playerProximityDistance,
            (value) => {
                this.playerProximityDistance = value;
            },
            'Distance in blocks for player nearby detection',
            sectionName
        );
        this.addDirectToggle(
            'Clip on ban',
            (value) => {
                this.clipOnBan = value;
            },
            'Toggle clip on ban',
            this.clipOnBan,
            sectionName
        );
        this.addDirectMultiToggle(
            'Discord ping on Check',
            ['None', 'Embed Only', 'Ping', 'Screenshot Only', 'Ping & Screenshot'],
            true,
            (value) => {
                this.pingOnCheck = value;
            },
            'Toggle discord ping on check',
            this.pingOnCheck,
            sectionName
        );
        this.addDirectToggle(
            'Play sound on check',
            (value) => {
                this.playSoundOnCheck = value;
            },
            'Toggle play sound on check',
            this.playSoundOnCheck,
            sectionName
        );
        this.addDirectMultiToggle(
            'Failsafe sound',
            this.getFilesInDir(),
            true,
            () => {
                const selectedFiles = getSetting('Failsafes', 'Failsafe sound');
                if (!Array.isArray(selectedFiles)) return;
                const enabledNames = selectedFiles.filter((fileObject) => fileObject.enabled).map((fileObject) => fileObject.name);
                if (enabledNames.length === 0) return;

                const singleEnabledName = enabledNames[0] + '.wav';

                AlertUtils.setFailsafeSound(singleEnabledName);
            },
            null,
            false,
            sectionName
        );
    }

    isBanReason(text) {
        if (!text) return false;
        return text.includes('banned') || text.includes('cheating') || text.includes('boosting') || text.includes('security');
    }

    postBanLog(reason) {
        if (!reason?.includes('https://www.hypixel.net/appeal')) return;

        const now = Date.now();
        if (now - this.lastBanLogTime < 60000) return;
        this.lastBanLogTime = now;

        new Thread(() => {
            try {
                const jwt = V5Auth.getFreshJwtToken();
                const url = new JURL('https://backend.rdbt.top/api/logs/bans');
                const conn = url.openConnection();
                conn.setRequestMethod('POST');
                conn.setDoOutput(true);
                conn.setRequestProperty('User-Agent', 'V5Loader/1.1');
                if (jwt) conn.setRequestProperty('Authorization', `Bearer ${jwt}`);
                conn.setRequestProperty('Content-Type', 'application/json; charset=UTF-8');

                const lastMacros = getLastActiveMacros();
                const lastMacroMeta = getLastDisableMeta(lastMacros[0]);
                const lastDisableTimestamp = lastMacroMeta?.timestamp;
                const within5Minutes = typeof lastDisableTimestamp === 'number' && Date.now() - lastDisableTimestamp <= 5 * 60 * 1000;

                const body = JSON.stringify({
                    reason,
                    lastMacro: lastMacros.join(', ') || 'None',
                    currentlyMacroing: isMacroRunning() || within5Minutes,
                    macroRuntime: isMacroRunning() ? formatUptime(getStartTime()) : null,
                    ingame_username: Player?.getName?.() || 'unknown',
                    config_contents: this.getConfigFileContents(),
                    installed_mods: new File('./mods').listFiles().join('\n'),
                });

                const wr = new JOutputStreamWriter(conn.getOutputStream());
                wr.write(body);
                wr.close();

                const status = conn.getResponseCode();
                if (status < 200 || status >= 300) {
                    console.error(`Error sending ban log. Status: ${status}`);
                }
                conn.disconnect();
            } catch (e) {
                console.error(`Exception sending ban log: ${e}`);
            }
        }).start();
    }

    getConfigFileContents() {
        try {
            return FileLib.read('V5Config', 'config.json');
        } catch (e) {
            console.error(`Exception reading config for ban log: ${e}`);
            return null;
        }
    }

    getFilesInDir() {
        const targetPath = new File(globalAssetsDir, 'failsafes/sounds');

        if (!targetPath.exists() || !targetPath.isDirectory()) {
            this.message('&cError: Directory not found.');
            return [];
        }

        const fileArray = targetPath.listFiles();
        const fileNames = [];

        if (!fileArray) return [];

        for (const file of fileArray) {
            const name = file.getName();
            if (name.endsWith('.wav')) fileNames.push(name.slice(0, -4));
        }

        return fileNames.sort((a, b) => a.localeCompare(b));
    }
}

new Failsafes();

import { OverlayManager } from '../../gui/OverlayUtils';
import { ArmorStandEntity, DataComponents, Vec3d } from '../../utils/Constants';
import { calculateDistance, getDistanceToPlayer } from '../../utils/Math';
import { ModuleBase } from '../../utils/ModuleBase';
import { findItemInHotbar, setItemSlot } from '../../utils/player/Inventory';
import { setKeysForStraightLineCoords } from '../../utils/player/Movement';
import { ScheduleTask } from '../../utils/ScheduleTask';
import { regrab, ungrab } from '../../utils/Ungrab';

const SMALL_BEACHBALL_BASE64 =
    'ewogICJ0aW1lc3RhbXAiIDogMTczNjQyNzQ4ODAwNCwKICAicHJvZmlsZUlkIiA6ICIzN2JhNjRkYzkxOTg0OGI4YjZhNDdiYTg0ZDgwNDM3MCIsCiAgInByb2ZpbGVOYW1lIiA6ICJTb3lLb3NhIiwKICAic2lnbmF0dXJlUmVxdWlyZWQiIDogdHJ1ZSwKICAidGV4dHVyZXMiIDogewogICAgIlNLSU4iIDogewogICAgICAidXJsIiA6ICJodHRwOi8vdGV4dHVyZXMubWluZWNyYWZ0Lm5ldC90ZXh0dXJlLzJhZGY5ZDcxMzY3Y2Q2ZTUwNWZiNDhjYWFhNWFjZGNkZmYyYTA5ZjY2YzQ4OGRhZjA0ZDA0NWVlMGJmNTI4ZTEiLAogICAgICAibWV0YWRhdGEiIDogewogICAgICAgICJtb2RlbCIgOiAic2xpbSIKICAgICAgfQogICAgfQogIH0KfQ==';

const LARGE_BEACHBALL_BASE64 =
    'eyJ0aW1lc3RhbXAiOjE1ODY2NjcxNjgzNzksInByb2ZpbGVJZCI6ImJlY2RkYjI4YTJjODQ5YjRhOWIwOTIyYTU4MDUxNDIwIiwicHJvZmlsZU5hbWUiOiJTdFR2Iiwic2lnbmF0dXJlUmVxdWlyZWQiOnRydWUsInRleHR1cmVzIjp7IlNLSU4iOnsidXJsIjoiaHR0cDovL3RleHR1cmVzLm1pbmVjcmFmdC5uZXQvdGV4dHVyZS8yOTllYTEyMGJkODNkMGM4MWEzYzQ2MjdmNWJjZTFiMTJmYjAzYmNiNTc3NzljNjNkY2M3N2UzZjRhZThhNzkzIn19fQ==';

const States = {
    WAITING: 0,
    BOUNCE: 1,
    RETURN: 2,
    PLACE: 3,
};

const TRAIL_MAX_POINTS = 30;
const PREDICTION_STEPS = 100;
const GRAVITY = 0.03;
const DRAG = 0.99;
const HEAD_HEIGHT_OFFSET = 1.8;
const LANDING_COLOR = new RenderColor(50, 255, 50, 255);

class Beachballer extends ModuleBase {
    constructor() {
        super({
            name: 'Beachballer',
            subcategory: 'Other',
            description: 'Automatically bounces beach balls',
            tooltip: 'Bounces beach balls and returns to start position at 40 bounces',
            theme: '#ffb347',
            isMacro: true,
        });
        this.bindToggleKey();

        this.bounceCount = 0;
        this.tickCounter = 0;
        this.bounceTimer = 0;
        this.hasActiveRun = false;
        this.startPos = [0, 0, 0];
        this.state = States.WAITING;
        this.trackedBall = null;

        this.trailHistory = [];
        this.predictedPath = [];
        this.landingPoint = null;
        this.lastVelocityY = 0;
        this.ballDescending = false;
        this.trailColors = [];
        this.predictionColors = [];
        this.trailColorLength = -1;
        this.predictionColorLength = -1;
        this.trajectoryToken = 0;
        this.holdShift = true;

        this.addToggle(
            'Hold Shift',
            (value) => {
                this.holdShift = value;
                if (!value) Client.setKey('shift', false);
            },
            'Hold Shift.',
            true
        );

        this.createOverlay(
            [
                {
                    title: 'Status',
                    data: {
                        State: () => this.getStateName(),
                        Bounces: () => `${this.bounceCount}/40`,
                        'Total Completed': () => this.getTotalBallsBounced(),
                    },
                },
            ],
            {
                sessionTrackedValues: {
                    totalBallsBounced: 0,
                },
            }
        );

        this.on('tick', () => {
            if (Client.isInGui() && !Client.isInChat()) {
                this.toggle(false);
                return;
            }

            this.updateTrajectory();

            switch (this.state) {
                case States.WAITING:
                    break;

                case States.BOUNCE:
                    this.handleBounceState();
                    break;

                case States.RETURN:
                    this.handleReturnState();
                    break;

                case States.PLACE:
                    this.handlePlaceState();
                    break;
            }
        });

        this.on('postRenderWorld', () => {
            if (this.state === States.WAITING) return;
            this.renderTrajectory();
        });

        this.on('actionBar', (text) => {
            const clean = ChatLib.removeFormatting(text);
            const match = clean.match(/Bounces: (\d{1,3})/);

            if (match) {
                this.bounceCount = Number.parseInt(match[1]);
                this.bounceTimer = Date.now();
            }

            if (Date.now() - this.bounceTimer > 2000) {
                this.bounceCount = 0;
            }
        }).setCriteria('${text}');
    }

    getStateName() {
        switch (this.state) {
            case States.WAITING:
                return 'Waiting';
            case States.BOUNCE:
                return 'Bouncing';
            case States.RETURN:
                return 'Returning';
            case States.PLACE:
                return 'Placing';
            default:
                return 'Unknown';
        }
    }

    getTotalBallsBounced() {
        return OverlayManager.getTrackedValue(this.oid, 'totalBallsBounced', 0);
    }

    updateTrajectory() {
        if (!this.trackedBall || this.trackedBall.isDead()) {
            this.trailHistory = [];
            this.predictedPath = [];
            this.landingPoint = null;
            this.lastVelocityY = 0;
            this.ballDescending = false;
            this.trajectoryToken++;
            return;
        }

        const currentPos = {
            x: this.trackedBall.getX(),
            y: this.trackedBall.getY(),
            z: this.trackedBall.getZ(),
        };

        const velocity = {
            x: currentPos.x - this.trackedBall.getLastX(),
            y: currentPos.y - this.trackedBall.getLastY(),
            z: currentPos.z - this.trackedBall.getLastZ(),
        };

        if (this.lastVelocityY > 0 && velocity.y <= 0) {
            const trackedBall = this.trackedBall;
            const token = ++this.trajectoryToken;
            ScheduleTask(5, () => {
                if (this.enabled && token === this.trajectoryToken && this.trackedBall === trackedBall && !trackedBall.isDead()) this.ballDescending = true;
            });
        }
        if (velocity.y > 0.1) {
            this.trajectoryToken++;
            this.ballDescending = false;
        }
        this.lastVelocityY = velocity.y;

        this.trailHistory.push(new Vec3d(currentPos.x, currentPos.y, currentPos.z));

        if (this.trailHistory.length > TRAIL_MAX_POINTS) {
            this.trailHistory.shift();
        }
        if (this.trailColorLength !== this.trailHistory.length) {
            this.trailColors = this.trailHistory
                .slice(0, -1)
                .map((_, i) => new RenderColor(0, 255, 255, Math.floor(80 + (120 * i) / this.trailHistory.length)));
            this.trailColorLength = this.trailHistory.length;
        }

        if (this.ballDescending && velocity.y <= 0) {
            const prediction = this.predictParabola(currentPos, velocity);
            this.predictedPath = prediction.path;
            this.landingPoint = prediction.landing;
        } else {
            this.predictedPath = this.simpleExtrapolation(currentPos, velocity);
            this.landingPoint = null;
        }
        if (this.predictionColorLength !== this.predictedPath.length) {
            this.predictionColors = this.predictedPath
                .slice(0, -1)
                .map((_, i) => new RenderColor(255, 165, 0, Math.floor(200 * (1 - i / this.predictedPath.length))));
            this.predictionColorLength = this.predictedPath.length;
        }
    }

    simpleExtrapolation(startPos, velocity) {
        const path = [];
        let x = startPos.x;
        let y = startPos.y;
        let z = startPos.z;

        path.push(new Vec3d(x, y, z));

        for (let i = 0; i < 10; i++) {
            x += velocity.x;
            y += velocity.y;
            z += velocity.z;
            path.push(new Vec3d(x, y, z));
        }

        return path;
    }

    predictParabola(startPos, velocity) {
        const path = [];
        let x = startPos.x;
        let y = startPos.y;
        let z = startPos.z;
        let vx = velocity.x;
        let vy = velocity.y;
        let vz = velocity.z;
        let landing = null;

        path.push(new Vec3d(x, y, z));

        const bounceY = Player.getY() + HEAD_HEIGHT_OFFSET;

        for (let i = 0; i < PREDICTION_STEPS; i++) {
            const prevY = y;

            vy -= GRAVITY;
            vx *= DRAG;
            vy *= DRAG;
            vz *= DRAG;

            x += vx;
            y += vy;
            z += vz;

            path.push(new Vec3d(x, y, z));

            if (vy < 0 && prevY > bounceY && y <= bounceY) {
                const t = (prevY - bounceY) / (prevY - y);
                const landX = path[path.length - 2].x + t * (x - path[path.length - 2].x);
                const landZ = path[path.length - 2].z + t * (z - path[path.length - 2].z);

                landing = new Vec3d(landX, bounceY, landZ);
                break;
            }

            if (y < bounceY - 10) break;
        }

        return { path, landing };
    }

    renderTrajectory() {
        const LINE_THICKNESS = 3;

        if (this.trailHistory.length >= 2) {
            Render3D.drawLines(this.trailHistory, this.trailColors, LINE_THICKNESS, true);
        }

        if (this.predictedPath.length >= 2) {
            Render3D.drawLines(this.predictedPath, this.predictionColors, LINE_THICKNESS, true);
        }

        if (this.landingPoint) {
            const markerSize = 0.3;
            const lp = this.landingPoint;

            Render3D.drawLine(new Vec3d(lp.x - markerSize, lp.y, lp.z), new Vec3d(lp.x + markerSize, lp.y, lp.z), LANDING_COLOR, 4, true);
            Render3D.drawLine(new Vec3d(lp.x, lp.y, lp.z - markerSize), new Vec3d(lp.x, lp.y, lp.z + markerSize), LANDING_COLOR, 4, true);

            const groundVec = new Vec3d(Math.floor(lp.x), Math.floor(Player.getY()), Math.floor(lp.z));
            Render3D.drawWireFrameBox(groundVec, LANDING_COLOR, 2, true);
        }
    }

    handleBounceState() {
        const hasTrackedBall = this.trackedBall && !this.trackedBall.isDead();
        const hasRecentBounceUpdate = Date.now() - this.bounceTimer < 1500;

        if (hasTrackedBall && this.bounceCount > 0 && this.bounceCount <= 40) {
            this.hasActiveRun = true;
        }

        if (this.bounceCount >= 40) {
            const validCompletion = hasTrackedBall && this.hasActiveRun && hasRecentBounceUpdate;

            if (validCompletion) {
                OverlayManager.incrementTrackedValue(this.oid, 'totalBallsBounced');
                this.setState(States.RETURN);
            }

            this.bounceCount = 0;
            this.hasActiveRun = false;
            this.trackedBall = null;
            return;
        }

        if (hasTrackedBall) {
            this.tickCounter = 0;

            const dx = this.trackedBall.getX() + (this.trackedBall.getX() - this.trackedBall.getLastX()) * 3;
            const dz = this.trackedBall.getZ() + (this.trackedBall.getZ() - this.trackedBall.getLastZ()) * 3;
            const ballY = this.trackedBall.getY();

            const playerPos = [Player.getX(), Player.getY(), Player.getZ()];
            const distance = calculateDistance(playerPos, [dx, ballY, dz]);

            Client.setKey('shift', this.holdShift);

            if (distance.distanceFlat > 0.5) {
                setKeysForStraightLineCoords(dx, ballY, dz);
            }
            if (distance.distanceFlat < 0.2) {
                Client.stopMovement();
            }
        } else {
            this.tickCounter++;
            if (this.tickCounter > 10) {
                this.setState(States.RETURN);
                this.trackedBall = null;
            }
        }
    }

    handleReturnState() {
        Client.unpressKeys();
        this.trackedBall = null;

        const playerPos = [Player.getX(), Player.getY(), Player.getZ()];
        const distanceToStart = calculateDistance(playerPos, this.startPos);

        if (distanceToStart.distance < 2) {
            Client.rightClick();
            this.setState(States.PLACE);
            return;
        }

        setKeysForStraightLineCoords(this.startPos[0], this.startPos[1], this.startPos[2]);
    }

    handlePlaceState() {
        if (!this.trackedBall || this.trackedBall.isDead()) {
            this.trackedBall = this.findBeachBall();

            if (this.trackedBall) {
                this.bounceCount = 0;
                this.hasActiveRun = false;
                this.message('Found ball!');
                this.setState(States.BOUNCE);
                return;
            }
        }

        const ballSlot = findItemInHotbar('Bouncy Beach Ball');
        if (ballSlot === -1) {
            this.message('&cNo bouncy balls in hotbar!');
            this.toggle(false);
            return;
        }

        setItemSlot(ballSlot);

        this.tickCounter++;
        if (this.tickCounter % 10 === 0) {
            Client.rightClick();
        }
    }

    findBeachBall() {
        const radius = 10;
        const stands = World.getAllEntitiesOfType(ArmorStandEntity);

        for (let element of stands) {
            const ex = element.getX();
            const ey = element.getY();
            const ez = element.getZ();

            const distance = getDistanceToPlayer(ex, ey, ez).distance;
            if (distance > radius) continue;

            const headItem = element.getStackInSlot(5);
            if (!headItem) continue;

            if (this.isBeachBall(headItem)) {
                return element;
            }
        }
        return null;
    }

    isBeachBall(item) {
        try {
            const mcItem = item.toMC();
            const profileType = DataComponents.PROFILE;

            const profileComponent = mcItem.get(profileType);
            const data = profileComponent.partialProfile().toString();

            return data.includes(SMALL_BEACHBALL_BASE64) || data.includes(LARGE_BEACHBALL_BASE64);
        } catch (e) {
            console.error(e);
            return false;
        }
    }

    setState(newState) {
        this.state = newState;
        this.tickCounter = 0;
        if (newState !== States.BOUNCE) this.hasActiveRun = false;

        if (newState === States.WAITING || newState === States.RETURN) {
            this.trackedBall = null;
            this.trailHistory = [];
            this.predictedPath = [];
            this.landingPoint = null;
            this.ballDescending = false;
        }
    }

    onEnable() {
        const player = Player.getPlayer();
        if (!player) {
            this.toggle(false);
            return;
        }

        this.setState(States.PLACE);
        this.startPos = [player.getX(), player.getY(), player.getZ()];
        this.trackedBall = null;
        this.trailHistory = [];
        this.predictedPath = [];
        this.landingPoint = null;
        this.ballDescending = false;
        this.lastVelocityY = 0;
        this.hasActiveRun = false;
        ungrab();
        this.message('&aEnabled');
    }

    onDisable() {
        this.trajectoryToken++;
        Client.unpressKeys();
        this.trackedBall = null;
        this.state = States.WAITING;
        this.trailHistory = [];
        this.predictedPath = [];
        this.landingPoint = null;
        this.ballDescending = false;
        regrab();
        this.message('&cDisabled');
    }
}

new Beachballer();

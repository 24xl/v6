import { isDeveloperModeEnabled } from '../../utils/DeveloperModeState';
import { wrapTo180 } from '../../utils/Math';
import { ModuleBase } from '../../utils/ModuleBase';
import { Rotations } from '../../utils/player/Rotations';
import { angleDifference, applyToPlayer } from '../../utils/player/RotationGCD';
import { registerSkyblockEvent } from '../../utils/SkyblockEvents';

const CHEST_BLOCKS = new Set(['minecraft:chest', 'minecraft:trapped_chest']);
const CHEST_SEARCH_RADIUS = 3;
const RETURN_THRESHOLD = 2.0;
const RETURN_SPEED = 0.15;
const VECTOR_TOLERANCE = 0.05;
const TICK_INTERVAL_MS = 10;

const SEARCH_OFFSETS = (() => {
    const offsets = [];
    for (let dx = -CHEST_SEARCH_RADIUS; dx <= CHEST_SEARCH_RADIUS; dx++) {
        for (let dy = -CHEST_SEARCH_RADIUS; dy <= CHEST_SEARCH_RADIUS; dy++) {
            for (let dz = -CHEST_SEARCH_RADIUS; dz <= CHEST_SEARCH_RADIUS; dz++) {
                if (dx === 0 && dy === 0 && dz === 0) continue;
                offsets.push([dx, dy, dz, dx * dx + dy * dy + dz * dz]);
            }
        }
    }
    return offsets.sort((a, b) => a[3] - b[3]).map(([dx, dy, dz]) => [dx, dy, dz]);
})();

const State = {
    IDLE: 'idle',
    MINING: 'mining',
    CHEST: 'chest',
    RETURNING: 'returning',
};

class PowderMacro extends ModuleBase {
    constructor() {
        super({
            name: 'Powder Macro',
            description: 'Powder Macro',
            subcategory: 'Mining',
            developerMode: true,
            isMacro: true,
        });

        this.bindToggleKey();
        this.loopToken = 0;
        this.initSettings();
        this.resetState();
        this.registerSkyblockEvents();

        this.createOverlay([
            {
                title: 'Status',
                data: {
                    State: () => this.state,
                    'Target Chest': () => (this.targetChest ? 'Found' : 'Searching'),
                },
            },
        ]);
    }

    initSettings() {
        this.height = 8;
        this.width = 12;
        this.speed = 4;
        this.compression = 0.4;
        this.maxPitch = 75;

        this.addSlider('Height (Pitch)', 1, 30, 8, (v) => (this.height = v), 'Vertical size of the loop');
        this.addSlider('Width (Yaw)', 1, 30, 12, (v) => (this.width = v), 'Horizontal size of the loop');
        this.addSlider('Speed', 1, 20, 4, (v) => (this.speed = v), 'Speed of the loop');
        this.addSlider('Top Compression', 0.1, 1.0, 0.4, (v) => (this.compression = v), 'How much to compress the top half of the circle');
        this.addSlider('Max Pitch', 45, 90, 75, (v) => (this.maxPitch = v), 'Maximum pitch (look down angle) to prevent breaking floor');
    }

    resetState() {
        this.state = State.IDLE;
        this.pivot = { yaw: 0, pitch: 0 };
        this.startTime = 0;
        this.savedRotation = null;
        this.targetChest = null;
    }

    registerSkyblockEvents() {
        registerSkyblockEvent('chestspawn', () => this.onChestSpawn());
        registerSkyblockEvent('chestopen', () => this.onChestOpen());
    }

    onChestSpawn() {
        if (!this.enabled || this.state === State.CHEST) return;
        const player = Player.getPlayer();
        if (!player) return;

        this.savedRotation = {
            yaw: wrapTo180(player.getYRot()),
            pitch: player.getXRot(),
        };

        this.targetChest = null;
        this.setState(State.CHEST);
    }

    onChestOpen() {
        if (!this.enabled) return;

        this.targetChest = null;
        Rotations.stop();

        if (!Client.isKeyDown('shift')) Client.setKey('shift', true);
        if (!Client.isKeyDown('leftclick')) Client.setKey('leftclick', true);

        this.setState(State.RETURNING);
    }

    setState(newState) {
        this.state = newState;
    }

    onEnable() {
        const player = Player.getPlayer();
        if (!player) {
            this.toggle(false);
            return;
        }

        Client.setKey('leftclick', true);
        Client.setKey('shift', true);

        this.pivot = {
            yaw: wrapTo180(player.getYRot()),
            pitch: player.getXRot(),
        };
        this.startTime = Date.now();

        this.message('&aPowder Macro Enabled!');

        this.setState(State.MINING);
        this.rotateLoop(++this.loopToken);
    }

    onDisable() {
        this.loopToken++;
        Client.setKey('leftclick', false);
        Client.setKey('shift', false);
        Rotations.stop();
        this.resetState();

        this.message('&cPowder Macro Disabled!');
    }

    rotateLoop(token) {
        if (!this.enabled || token !== this.loopToken) return;
        const player = Player.getPlayer();
        if (!player) {
            setTimeout(() => this.rotateLoop(token), TICK_INTERVAL_MS);
            return;
        }

        try {
            switch (this.state) {
                case State.MINING:
                    this.tickMining();
                    break;
                case State.CHEST:
                    this.tickChest();
                    break;
                case State.RETURNING:
                    this.tickReturning();
                    break;
            }
        } catch (e) {
            console.error(e);
        }

        setTimeout(() => this.rotateLoop(token), TICK_INTERVAL_MS);
    }

    tickMining() {
        const elapsed = (Date.now() - this.startTime) / 1000;
        const angle = elapsed * this.speed;

        let dPitch = Math.sin(angle) * this.height;
        if (dPitch < 0) dPitch *= this.compression;

        const targetYaw = this.pivot.yaw + Math.cos(angle) * this.width;
        const targetPitch = Math.min(this.pivot.pitch + dPitch, this.maxPitch);

        applyToPlayer(targetYaw, targetPitch);
    }

    tickChest() {
        Client.setKey('leftclick', false);
        Client.setKey('shift', false);

        if (!this.validateTargetChest()) {
            this.targetChest = this.findNearestChest();
        }

        if (this.targetChest) {
            this.rotateToTarget(this.getBlockCenter(this.targetChest));
        }
    }

    tickReturning() {
        const player = Player.getPlayer();
        if (!player) return;

        const current = { yaw: wrapTo180(player.getYRot()), pitch: player.getXRot() };
        const target = this.savedRotation ?? this.pivot;

        const diffYaw = angleDifference(target.yaw, current.yaw);
        const diffPitch = target.pitch - current.pitch;
        const distance = Math.hypot(diffYaw, diffPitch);

        if (distance < RETURN_THRESHOLD) {
            this.syncLoopAngle(current);
            this.setState(State.MINING);
        } else {
            applyToPlayer(current.yaw + diffYaw * RETURN_SPEED, current.pitch + diffPitch * RETURN_SPEED);
        }
    }

    syncLoopAngle(currentRotation) {
        const dYaw = currentRotation.yaw - this.pivot.yaw;
        let dPitch = currentRotation.pitch - this.pivot.pitch;

        if (dPitch < 0 && this.compression !== 0) {
            dPitch /= this.compression;
        }

        const currentAngle = Math.atan2(dPitch / this.height, dYaw / this.width);
        this.startTime = Date.now() - (currentAngle / this.speed) * 1000;
    }

    validateTargetChest() {
        if (!this.targetChest) return false;

        const block = World.getBlockAt(this.targetChest.getX(), this.targetChest.getY(), this.targetChest.getZ());

        return this.isChestBlock(block);
    }

    findNearestChest() {
        const player = Player.getPlayer();
        if (!player) return null;

        const baseX = Math.floor(player.getX());
        const baseY = Math.floor(player.getY());
        const baseZ = Math.floor(player.getZ());

        for (const [dx, dy, dz] of SEARCH_OFFSETS) {
            const block = World.getBlockAt(baseX + dx, baseY + dy, baseZ + dz);
            if (this.isChestBlock(block)) {
                return block;
            }
        }

        return null;
    }

    isChestBlock(block) {
        if (!block) return false;

        const blockType = block.getType();
        if (!blockType) return false;
        if (CHEST_BLOCKS.has(blockType.getRegistryName())) return true;

        const blockName = typeof blockType.getName === 'function' ? blockType.getName() : '';
        return blockName.toLowerCase().includes('chest');
    }

    getBlockCenter(block) {
        return {
            x: block.getX() + 0.5,
            y: block.getY() + 0.5,
            z: block.getZ() + 0.5,
        };
    }

    rotateToTarget(target) {
        const current = Rotations.currentVector;
        const needsUpdate =
            !current ||
            Math.abs(current.x - target.x) > VECTOR_TOLERANCE ||
            Math.abs(current.y - target.y) > VECTOR_TOLERANCE ||
            Math.abs(current.z - target.z) > VECTOR_TOLERANCE;

        if (needsUpdate) {
            Rotations.lookAtVector(target);
        }
    }
}

if (isDeveloperModeEnabled()) new PowderMacro();

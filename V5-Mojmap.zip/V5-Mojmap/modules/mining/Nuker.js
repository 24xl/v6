import { BP, BlockHitResult, Direction, MCHand, Vec3d } from '../../utils/Constants';
import { offsetPitch } from '../../utils/Math';
import { hasMaxGreatExplorer } from '../../utils/MiningUtils';
import { ModuleBase } from '../../utils/ModuleBase';
import { isVanillaNukeActive, nukeQueue, queueNuke, queueVanillaNuke } from '../../utils/NukerUtils';
import { ClientboundLevelParticlesPacket, getLevelParticleData, ServerboundUseItemOnPacket } from '../../utils/Packets';
import { Rotations } from '../../utils/player/Rotations';
import { registerSkyblockEvent } from '../../utils/SkyblockEvents';
import { executeAsync } from '../../utils/ThreadExecutor';
import { getPickaxeAbilityStatus, stripTabFormatting } from '../../utils/TabListUtils';
import { v5Command } from '../../utils/V5Commands';
import { setKeysForStraightLineCoords } from '../../utils/player/Movement';

class NukerClass extends ModuleBase {
    constructor() {
        super({
            name: 'Nuker',
            subcategory: 'Mining',
            description: 'Automatically nukes nearby blocks.',
            tooltip: 'Automatically nukes nearby blocks',
            theme: '#e23737',
            autoDisableOnWorldUnload: true,
            isMacro: true,
        });
        this.bindToggleKey();

        this.target = null;
        this.lastMineTick = 0;
        this.tickCounter = 0;
        this.minedBlocks = new Map();
        this.chestClickCooldowns = new Map();
        this.ignoredChests = new Set();
        this.chestClickedThisTick = false;
        this.solvingChest = null;
        this.blockFilter = null;
        this.chestFilter = null;
        this.chestWalkDistance = 0;

        this.BLOCK_COOLDOWN = 20;
        this.REQUIRED_ITEMS = ['Drill', 'Gauntlet', 'Pick'];

        this.customBlockList = [];

        this.targetMode = 'Random';
        this.breakMode = 'Hypixel';
        this.nukeBelow = false;
        this.onGroundOnly = false;
        this.autoChest = false;
        this.usePickaxeAbility = false;
        this.heightLimit = 5;
        this.onGroundDelay = 1;
        this.offGroundDelay = 1;
        this.customReach = 4.5;
        this.abilityFromChat = false;
        this.lastUse = 0;
        this.ABILITY_COOLDOWN_MS = 200000;

        v5Command('nuker add', () => {
            let block = Player.lookingAt();
            if (block?.getClass() === Block) {
                const newBlock = { name: block.type.getName(), registryName: block.type.getRegistryName() };
                if (!this.customBlockList.some((b) => b.registryName === newBlock.registryName)) {
                    this.customBlockList.push(newBlock);
                    this.message('Added ' + block.type.getName() + ' to Nuker list.');
                } else {
                    this.message('Block already in Nuker list.');
                }
            } else {
                this.message('Look at a block to add it');
            }
        });

        v5Command(
            'nuker remove',
            (index) => {
                if (index === undefined) return this.message('Usage: /v5 nuker remove <index>');
                if (index < 1 || index > this.customBlockList.length) return this.message('Invalid index.');
                this.customBlockList.splice(index - 1, 1);
                this.message('Removed block.');
            },
            ['integer']
        );

        v5Command('nuker list', () => {
            if (this.customBlockList.length === 0) {
                return this.message('List is currently empty.');
            }

            this.message('&7--- Custom Nuker List ---');
            this.customBlockList.forEach((block, index) => {
                this.message(`&e${index + 1}. &f${block.name}`);
            });
            this.message('&7----------------------');
        });

        v5Command('nuker clear', () => {
            this.customBlockList = [];
            this.message('Cleared Nuker list.');
        });

        this.on('tick', () => {
            this.tickCounter++;
            this.chestClickedThisTick = false;
            if (this.solvingChest) {
                const chest = this.solvingChest;
                if (this.chestFilter && !this.chestFilter(chest)) {
                    this.ignoreChest(chest.key);
                    this.finishChest();
                } else if (!this.autoChest || !this.isChestBlock(World.getBlockAt(chest.x, chest.y, chest.z))) {
                    this.finishChest();
                } else if (Date.now() - chest.startedAt > 10000) {
                    if (!hasMaxGreatExplorer()) this.ignoreChest(chest.key);
                    this.finishChest();
                } else if (Date.now() - chest.lastParticle > 4000) {
                    this.finishChest();
                } else {
                    if (
                        this.chestWalkDistance
                            ? Math.hypot(chest.x + 0.5 - Player.getX(), chest.z + 0.5 - Player.getZ()) <= this.chestWalkDistance
                            : hasMaxGreatExplorer()
                    )
                        Client.stopMovement();
                    else setKeysForStraightLineCoords(chest.x + 0.5, Player.getY(), chest.z + 0.5, false);
                    if (Client.isInGui()) Rotations.stop();
                    else Rotations.lookAtVector(chest.particle);
                    return;
                }
            }

            const now = Date.now();
            for (const [posStr, clickedAt] of this.chestClickCooldowns) {
                if (now - clickedAt >= 2000 && this.solvingChest?.key !== posStr) this.chestClickCooldowns.delete(posStr);
            }
            if (this.autoChest) this.scanForChests();
            if (this.customBlockList.length === 0) {
                this.message('Try setting targets with /v5 commands:');
                this.message('- /v5 nuker add - adds block at crosshair');
                this.message('- /v5 nuker remove <index> - removes block by list index');
                this.message('- /v5 nuker clear - clear all targets');
                this.message('- /v5 nuker list - list all targets');
                return;
            }

            if (Client.isInGui() && !Client.isInChat()) return;
            if (Client.getKeyBindFromDescription('key.attack')?.isKeyDown() || Client.getMinecraft().options.keyAttack?.isDown()) return;
            if (!this.onGround()) return;
            if (this.breakMode === 'Vanilla' && isVanillaNukeActive()) {
                this.lastMineTick = this.tickCounter;
                return;
            }

            let delay = Player.asPlayerMP().isOnGround() ? this.onGroundDelay : this.offGroundDelay;
            if (this.tickCounter - this.lastMineTick < delay) return;

            this.lastMineTick = this.tickCounter;

            if (this.shouldUsePickaxeAbility()) {
                this.usePickaxeAbilityNow();
                return;
            }

            for (const [pos, tick] of this.minedBlocks) {
                if (this.tickCounter - tick > this.BLOCK_COOLDOWN) {
                    this.minedBlocks.delete(pos);
                }
            }

            executeAsync(() => {
                if (!this.enabled || this.solvingChest) return;
                const target = this.scanForBlock();

                if (target && this.enabled && !this.solvingChest) {
                    const posArr = [target.getX(), target.getY(), target.getZ()];
                    if (this.breakMode === 'Vanilla') queueVanillaNuke(posArr, this.customReach);
                    else queueNuke(posArr, delay);
                    this.target = target;
                    this.minedBlocks.set(this.posToString(target), this.tickCounter);

                    if (['Random', 'Lowest', 'Highest'].includes(this.targetMode)) {
                        for (let dx = -1; dx <= 1; dx++) {
                            for (let dy = -1; dy <= 1; dy++) {
                                for (let dz = -1; dz <= 1; dz++) {
                                    const spreadPos = new BP(target.getX() + dx, target.getY() + dy, target.getZ() + dz);
                                    this.minedBlocks.set(this.posToString(spreadPos), this.tickCounter);
                                }
                            }
                        }
                    }
                }
            });
        });

        registerSkyblockEvent('abilityready', () => {
            if (!this.enabled || !this.usePickaxeAbility) return;
            this.abilityFromChat = true;
        });

        registerSkyblockEvent('abilityused', () => {
            if (!this.enabled || !this.usePickaxeAbility) return;
            this.lastUse = Date.now();
            this.abilityFromChat = false;
        });

        this.on('packetReceived', (packet) => {
            if (!this.autoChest || Client.isInGui()) return;
            const data = getLevelParticleData(packet);
            if (!data) return;
            if (data.particle?.getType() !== net.minecraft.core.particles.ParticleTypes.CRIT) return;
            const particle = { x: data.x, y: data.y, z: data.z };
            const player = Player.getPlayer();
            const distance = player ? Math.hypot(particle.x - player.getX(), particle.z - player.getZ()) : 0;
            const aim = offsetPitch(particle, 5 / Math.max(1, distance));
            for (const key of this.ignoredChests) {
                if (hasMaxGreatExplorer()) break;
                const [x, y, z] = key.split(',').map(Number);
                if (Math.abs(particle.x - x - 0.5) < 0.7 && Math.abs(particle.y - y - 0.5) < 0.7 && Math.abs(particle.z - z - 0.5) < 0.7) return;
            }
            for (const [key, clickedAt] of this.chestClickCooldowns) {
                if (!hasMaxGreatExplorer() && this.ignoredChests.has(key)) continue;
                if (Date.now() - clickedAt > 2000 && this.solvingChest?.key !== key) continue;
                const [x, y, z] = key.split(',').map(Number);
                if (this.solvingChest && this.solvingChest.key !== key) continue;
                if (Math.abs(particle.x - x - 0.5) >= 0.7 || Math.abs(particle.y - y - 0.5) >= 0.7 || Math.abs(particle.z - z - 0.5) >= 0.7) continue;
                this.solvingChest = {
                    key,
                    x,
                    y,
                    z,
                    particle: aim,
                    startedAt: this.solvingChest?.startedAt ?? Date.now(),
                    lastParticle: Date.now(),
                };
                this.chestClickCooldowns.set(key, Date.now());
                nukeQueue.length = 0;
                Client.stopMovement();
                Rotations.lookAtVector(aim);
                break;
            }
        }).setFilteredClass(ClientboundLevelParticlesPacket);
        for (const event of ['chestsolve', 'chestopen']) {
            registerSkyblockEvent(event, () => {
                if (this.enabled && this.solvingChest) this.finishChest();
            });
        }

        this.on('postRenderWorld', () => {
            if (this.target) this.renderRGB([this.target.getX(), this.target.getY(), this.target.getZ()]);
            if (this.chestPos && this.autoChest && this.distance(this.cords(), [this.chestPos.x, this.chestPos.y, this.chestPos.z]).distance <= 8) {
                Render3D.drawFilledBox(new Vec3d(this.chestPos.x, this.chestPos.y, this.chestPos.z), new RenderColor(100, 100, 255, 150), false);
            }
        });

        this.addToggle('Auto Chest', (v) => (this.autoChest = v), 'Auto-opens chests');
        this.addToggle("Don't nuke below", (v) => (this.nukeBelow = v), 'Prevents nuking below');
        this.addToggle('On Ground Only', (v) => (this.onGroundOnly = v), 'Only mine when on ground');
        this.addToggle('Use Pickaxe Ability', (v) => (this.usePickaxeAbility = v), 'Uses pickaxe ability when available');
        this.addSlider('Custom Reach', 4.5, 6.0, this.customReach, (v) => (this.customReach = Number(v)), 'Adjust player reach');
        this.addSlider('On Ground Delay', 1, 20, 1, (v) => (this.onGroundDelay = v));
        this.addSlider('Off Ground Delay', 1, 20, 1, (v) => (this.offGroundDelay = v));
        this.addMultiToggle('Target Mode', ['Random', 'Closest', 'Lowest', 'Highest'], true, (v) => {
            this.targetMode = v.find((o) => o.enabled)?.name;
        });
        this.addMultiToggle(
            'Break Mode',
            ['Hypixel', 'Vanilla'],
            true,
            (v) => {
                this.breakMode = v.find((o) => o.enabled)?.name || 'Hypixel';
            },
            'Use Hypixel mode for most hypixel things, only use vanilla for the rift.'
        );

        this.createOverlay([
            {
                title: 'Status',
                data: {
                    'Target Mode': () => this.targetMode,
                    'Blocks Queued': () => nukeQueue.length,
                },
            },
        ]);
    }

    scanForChests() {
        this.chestPos = null;
        if (Client.isInGui() && !Client.isInChat()) return;
        const eye = this.cords();
        if (!eye) return;
        const [x, y, z] = eye.map(Math.floor);
        const now = Date.now();
        let target = null;
        let nearest = Infinity;
        const blocks = World.getBlocksInBox(x - 6, y - 6, z - 6, x + 6, y + 6, z + 6, [
            new BlockType('minecraft:chest'),
            new BlockType('minecraft:trapped_chest'),
        ]);
        for (const block of blocks) {
            const chest = { x: block.x, y: block.y, z: block.z };
            const distance = this.distance(eye, [chest.x, chest.y, chest.z]).distance;
            const key = `${chest.x},${chest.y},${chest.z}`;
            if (distance > 6) continue;
            if (this.chestFilter && !this.chestFilter(chest)) continue;
            if (!hasMaxGreatExplorer() && this.ignoredChests.has(key)) continue;
            if (now - (this.chestClickCooldowns.get(key) ?? 0) < 1000) continue;
            if (distance < nearest) {
                target = { ...chest, key };
                nearest = distance;
            }
        }
        if (!target || this.chestClickedThisTick) return;
        this.chestPos = target;
        this.rightClickBlock([target.x, target.y, target.z]);
        this.chestClickCooldowns.set(target.key, now);
        this.chestClickedThisTick = true;
    }

    scanForBlock() {
        const pCords = this.cords();
        if (!pCords) return null;

        const pX = pCords[0];
        const pY = pCords[1];
        const pZ = pCords[2];
        const x = Math.floor(Player.getX());
        const y = Math.floor(Player.getY());
        const z = Math.floor(Player.getZ());
        const scanReach = this.customReach;
        const scanReachSq = scanReach * scanReach;
        const scanRadius = Math.ceil(scanReach);
        const maxY = y + Math.max(this.heightLimit, scanRadius);
        const minY = y - (this.nukeBelow ? 0 : scanRadius);

        const targetTypes = this.customBlockList.map((b) => new BlockType(b.registryName));
        const blocks = World.getBlocksInBox(x - scanRadius, minY, z - scanRadius, x + scanRadius, maxY, z + scanRadius, targetTypes);
        let selected = null;
        let selectedDistanceSq = Infinity;
        let candidates = 0;

        for (const block of blocks) {
            const blockX = block.x;
            const blockY = block.y;
            const blockZ = block.z;
            if (this.blockFilter && !this.blockFilter(blockX, blockY, blockZ)) continue;
            if (this.minedBlocks.has(`${blockX},${blockY},${blockZ}`)) continue;

            let dx = 0;
            let dy = 0;
            let dz = 0;

            if (pX < blockX) dx = blockX - pX;
            else if (pX > blockX + 1) dx = pX - blockX - 1;

            if (pY < blockY) dy = blockY - pY;
            else if (pY > blockY + 1) dy = pY - blockY - 1;

            if (pZ < blockZ) dz = blockZ - pZ;
            else if (pZ > blockZ + 1) dz = pZ - blockZ - 1;

            const distanceSq = dx * dx + dy * dy + dz * dz;
            if (distanceSq > scanReachSq) continue;

            if (this.targetMode === 'Closest') {
                if (distanceSq < selectedDistanceSq) {
                    selected = block;
                    selectedDistanceSq = distanceSq;
                }
            } else if (this.targetMode === 'Lowest' || this.targetMode === 'Highest') {
                const better = !selected || (this.targetMode === 'Lowest' ? blockY < selected.y : blockY > selected.y);

                if (better) {
                    selected = block;
                    candidates = 1;
                } else if (blockY === selected.y) {
                    candidates++;
                    if (Math.random() < 1 / candidates) selected = block;
                }
            } else {
                candidates++;
                if (Math.random() < 1 / candidates) selected = block;
            }
        }

        return selected ? new BP(selected.x, selected.y, selected.z) : null;
    }

    isHoldingMiningTool() {
        const heldName = stripTabFormatting(Player.getHeldItem()?.getName?.() ?? '');
        return this.REQUIRED_ITEMS.some((name) => heldName.includes(name));
    }

    shouldUsePickaxeAbility() {
        if (!this.usePickaxeAbility) return false;
        if (!this.isHoldingMiningTool()) return false;

        const now = Date.now();
        const abilityStatus = getPickaxeAbilityStatus();
        return abilityStatus.includes('Available') || this.abilityFromChat || this.lastUse + this.ABILITY_COOLDOWN_MS < now;
    }

    usePickaxeAbilityNow() {
        Client.rightClick();
        this.lastUse = Date.now();
        this.abilityFromChat = false;
    }

    posToString(pos) {
        return pos.getX ? `${pos.getX()},${pos.getY()},${pos.getZ()}` : `${pos[0]},${pos[1]},${pos[2]}`;
    }

    distance(from, to) {
        if (!from || !to) return { distance: Infinity };
        const dx = from[0] - to[0],
            dy = from[1] - to[1],
            dz = from[2] - to[2];
        return { distance: Math.hypot(dx, dy, dz) };
    }

    onGround() {
        return this.onGroundOnly ? Player.asPlayerMP().isOnGround() : true;
    }

    cords() {
        const eye = Player.getPlayer()?.getEyePosition();
        return eye ? [eye.x(), eye.y(), eye.z()] : null;
    }

    renderRGB(loc) {
        let time = Date.now() / 1000;
        let r = Math.sin(time) * 127 + 128,
            g = Math.sin(time + 2) * 127 + 128,
            b = Math.sin(time + 4) * 127 + 128;
        Render3D.drawWireFrameBox(new Vec3d(loc[0], loc[1], loc[2]), new RenderColor(r, g, b, 255), 5, true);
    }

    isChestBlock(block) {
        return ['minecraft:chest', 'minecraft:trapped_chest'].includes(block?.type?.getRegistryName?.() ?? block?.getRegistryName?.());
    }

    rightClickBlock(xyz) {
        let hitResult = new BlockHitResult(new Vec3d(xyz[0] + 0.5, xyz[1] + 0.5, xyz[2] + 0.5), Direction.UP, new BP(xyz[0], xyz[1], xyz[2]), false);
        Client.sendSequencedPacket((sequence) => new ServerboundUseItemOnPacket(MCHand.MAIN_HAND, hitResult, sequence));
    }

    init() {
        this.finishChest();
        nukeQueue.length = 0;
        this.target = null;
        this.chestPos = null;
        this.lastMineTick = 0;
        this.tickCounter = 0;
        this.minedBlocks.clear();
        this.chestClickCooldowns.clear();
        this.ignoredChests.clear();
        this.abilityFromChat = false;
    }

    onEnable() {
        this.message('&aEnabled');
        this.init();
    }

    onDisable() {
        this.finishChest();
        nukeQueue.length = 0;
        this.message('&cDisabled');
    }

    finishChest() {
        if (!this.solvingChest) return;
        this.chestClickCooldowns.set(this.solvingChest.key, Date.now());
        this.solvingChest = null;
        this.chestPos = null;
        Rotations.stop();
    }

    ignoreChest(key) {
        this.ignoredChests.add(key);
        if (this.chestPos && `${this.chestPos.x},${this.chestPos.y},${this.chestPos.z}` === key) this.chestPos = null;
    }
}

export const Nuker = new NukerClass();

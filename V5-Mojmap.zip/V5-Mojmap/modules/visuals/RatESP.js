import { ZombieEntity, Vec3d } from '../../utils/Constants';
import { ModuleBase } from '../../utils/ModuleBase';
import { area } from '../../utils/Utils';

const RAT_WIDTH = 0.49;
const RAT_HEIGHT = 0.99;
const EPSILON = 0.01;
const WORLD_TICK_MS = 50;

const approxEqual = (a, b, epsilon = EPSILON) => Math.abs(a - b) <= epsilon;

function isRatEntity(entity) {
    return !!entity && !entity.isDead() && isRawRatEntity(entity);
}

function isRawRatEntity(entity) {
    return !!entity && approxEqual(entity.getWidth(), RAT_WIDTH) && approxEqual(entity.getHeight(), RAT_HEIGHT);
}

export function getRatId(entity) {
    return entity ? entity.getUUID().toString() : null;
}

export function getHubRats() {
    if (!World.isLoaded() || area() !== 'Hub') return [];
    return getRawHubRats().filter((entity) => isRatEntity(entity));
}

export function getRawHubRats() {
    if (!World.isLoaded() || area() !== 'Hub') return [];
    return World.getAllEntitiesOfType(ZombieEntity).filter((entity) => isRawRatEntity(entity));
}

class RatESP extends ModuleBase {
    constructor() {
        super({
            name: 'Rat ESP',
            subcategory: 'Visuals',
            description: 'Highlights Hub rats.',
            tooltip: 'Highlights Hub rats.',
        });

        this.rats = [];
        this.lastWorldTickAt = 0;
        this.fillColor = new RenderColor(255, 255, 0, 80);
        this.tracerColor = new RenderColor(255, 255, 0, 255);

        this.on('tick', () => {
            this.lastWorldTickAt = Date.now();
            this.scanRats();
        });

        this.when(
            () => this.enabled && World.isLoaded() && area() === 'Hub' && this.rats.length > 0,
            'postRenderWorld',
            () => this.renderRats(),
            true
        );

        this.on('worldUnload', () => {
            this.rats = [];
            this.lastWorldTickAt = 0;
        });
    }

    scanRats() {
        if (!this.enabled || !World.isLoaded() || area() !== 'Hub') {
            this.rats = [];
            return;
        }

        this.rats = getHubRats();
    }

    renderRats() {
        this.rats = this.rats.filter((entity) => entity && !entity.isDead());

        const positions = [];
        this.rats.forEach((entity) => {
            const position = this.getInterpolatedHeadPosition(entity);
            if (!position) return;

            positions.push(new Vec3d(position.x, position.y, position.z));
        });
        Render3D.drawSizedBoxes(positions, 0.7, 0.7, 0.7, this.fillColor, true, 4, false);
        Render3D.drawTracers(positions, this.tracerColor, 2, false);
    }

    getInterpolatedHeadPosition(entity) {
        if (!entity) return null;

        const alpha = this.getFrameInterpolationAlpha();
        const lerp = (start, end) => start + (end - start) * alpha;
        return {
            x: lerp(entity.getLastX(), entity.getX()),
            y: lerp(entity.getLastY(), entity.getY()),
            z: lerp(entity.getLastZ(), entity.getZ()),
        };
    }

    getFrameInterpolationAlpha() {
        if (this.lastWorldTickAt <= 0) return 1;
        return Math.max(0, Math.min(1, (Date.now() - this.lastWorldTickAt) / WORLD_TICK_MS));
    }

    onDisable() {
        this.rats = [];
        this.lastWorldTickAt = 0;
    }
}

new RatESP();

import { isDeveloperModeEnabled } from '../../utils/DeveloperModeState';
import { ArmorStandEntity } from '../../utils/Constants';
import { ModuleBase } from '../../utils/ModuleBase';
import { clickSlot, setItemSlot } from '../../utils/player/Inventory';

class FishingMacro extends ModuleBase {
    constructor() {
        super({
            name: 'Fishing Macro',
            subcategory: 'Skills',
            developerMode: true,
            description: 'Fishing Macro general hype',
            tooltip: 'Fishing Macro general hype',
            isMacro: true,
        });
        this.bindToggleKey();

        this.tickDelay = 3;

        this.hypeSlot = 1;
        this.rodSlot = 0;
        this.petSwap = false;
        this.petSlot = 10;
        this.cooldown = 5;
        this.randomCooldown = 2;

        this.hypeClicksRemaining = 2;
        this.hypeClickAmount = 1;
        this.hypeClickAmountThunder = 1;

        this.thunderSpawn = false;
        this.eelSpawn = false;

        this.deployableUsageTime = 0;
        this.deployableCooldown = 180;
        this.deployableSlot = 2;
        this.useDeployable = false;

        this.on('tick', () => {
            this.tick();
        });

        this.on('chat', (event) => {
            const msg = event.message.getString();
            if (msg.includes('Thunder') || msg.includes('thunder')) {
                this.thunderSpawn = true;
            }
            if (msg.includes('fire eel') || msg.includes('Fire Eel')) {
                this.eelSpawn = true;
            }
        });

        this.addSlider('Hype Slot', 0, 8, 1, (v) => (this.hypeSlot = v));
        this.addSlider('Rod Slot', 0, 8, 0, (v) => (this.rodSlot = v));
        this.addToggle('Pet swap', (v) => (this.petSwap = v));
        this.addSlider('Pet slot', 10, 43, 10, (v) => (this.petSlot = v));
        this.addSlider('Tick cooldown', 3, 7, 5, (v) => (this.cooldown = v));
        this.addSlider('Additional random tick cooldown', 0, 5, 2, (v) => (this.randomCooldown = v));
        this.addSlider('Hyperion click amount', 1, 4, 1, (v) => (this.hypeClickAmount = v));
        this.addSlider('Hyperion click amount (thunder)', 1, 50, 1, (v) => (this.hypeClickAmountThunder = v));

        this.addToggle('Use deployable', (v) => (this.useDeployable = v));
        this.addSlider('Deployable slot', 0, 8, 2, (v) => (this.deployableSlot = v));
        this.addSlider('Deployable cooldown', 0, 300, 180, (v) => (this.deployableCooldown = v));

        this.createOverlay([
            {
                title: 'Status',
                data: {
                    Step: () => this.step,
                    Delay: () => this.tickDelay,
                },
            },
        ]);
    }

    tick() {
        if (this.tickDelay > 0) {
            this.tickDelay--;
            return;
        }
        this.tickDelay = Math.round(this.cooldown + this.randomCooldown * Math.random());
        switch (this.step) {
            case -2:
                setItemSlot(this.rodSlot);
                this.step++;
                break;
            case -1:
                Client.rightClick();
                this.step++;
                break;
            case 0: // detect fish bobber pull ready thing
                const stand = World.getAllEntitiesOfType(ArmorStandEntity);
                const target = stand.find((element) => element.getName() === '!!!');
                if (!target) return;
                Client.rightClick();
                this.step++;
                break;
            case 1: // swap to hype
                setItemSlot(this.hypeSlot);
                this.hypeClicksRemaining = this.hypeClickAmount;
                this.step++;
                break;
            case 2: // use hype x times
                if (this.hypeClicksRemaining > 0) {
                    Client.rightClick();
                    this.hypeClicksRemaining--;
                } else {
                    if (this.thunderSpawn) {
                        this.thunderSpawn = false;
                        this.hypeClicksRemaining = this.hypeClickAmountThunder;
                    } else {
                        if (this.useDeployable && Date.now() - this.deployableUsageTime > this.deployableCooldown * 1000) {
                            this.step = 3;
                        } else {
                            this.step = 5;
                        }
                    }
                }
                break;
            case 3:
                setItemSlot(this.deployableSlot);
                this.step++;
                break;
            case 4:
                Client.rightClick();
                this.deployableUsageTime = Date.now();
                this.step++;
                break;
            case 5:
                setItemSlot(this.rodSlot);
                this.step++;
                break;
            case 6:
                if (this.eelSpawn) {
                    this.eelSpawn = false;
                    return;
                }
                Client.rightClick();
                if (this.petSwap) {
                    this.step = 7;
                } else {
                    this.step = 0;
                }
                break;
            case 7:
                ChatLib.command('pets');
                this.tickDelay = Math.round((this.cooldown + this.randomCooldown * Math.random()) * 2);
                this.step++;
                break;
            case 8:
                clickSlot(this.petSlot);
                this.step = 0;
                break;
        }
    }

    onEnable() {
        this.message('&aEnabled');
        this.step = -2;
        this.tickDelay = 0;
        this.thunderSpawn = false;
        this.eelSpawn = false;
    }

    onDisable() {
        this.message('&cDisabled');
    }
}

if (isDeveloperModeEnabled()) new FishingMacro();

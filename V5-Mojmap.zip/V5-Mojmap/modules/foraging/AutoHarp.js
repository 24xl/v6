import { ModuleBase } from '../../utils/ModuleBase';
import { clickSlot, getGuiName } from '../../utils/player/Inventory';

class AutoHarp extends ModuleBase {
    constructor() {
        super({
            name: 'Auto Harp',
            subcategory: 'Foraging',
            description: 'Auto Harp',
            tooltip: 'Auto Harp',
        });

        this.DELAY = 3;

        this.notes = [37, 38, 39, 40, 41, 42, 43].map((slot) => ({ slot, clicked: false, DELAY: 0 }));

        this.on('tick', () => {
            const invName = getGuiName();
            if (!invName?.includes('Harp')) return;

            const container = Player.getContainer();
            if (!container) return;

            this.notes.forEach((note) => {
                if (note.DELAY > 0) note.DELAY--;

                const item = container.getStackInSlot(note.slot)?.type?.getRegistryName();

                if (!item || item.includes('terracotta')) {
                    note.clicked = false;
                    note.DELAY = 0;
                }

                if (!item?.includes('quartz') || note.clicked || note.DELAY !== 0) return;

                const belowItem = container.getStackInSlot(note.slot - 9)?.type?.getRegistryName();
                if (belowItem?.includes('wool')) {
                    note.DELAY = this.DELAY;
                } else {
                    note.clicked = true;
                }

                clickSlot(note.slot, false, 'MIDDLE');
            });
        });

        this.addSlider('Delay (ms)', 0, 500, 150, (v) => (this.DELAY = Math.round(v / 50)));
    }

    onDisable() {
        this.notes?.forEach((note) => {
            note.clicked = false;
            note.DELAY = 0;
        });
    }
}
new AutoHarp();

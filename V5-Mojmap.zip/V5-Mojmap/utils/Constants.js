export const MCHand = net.minecraft.world.InteractionHand;

export const CLIENT_VERSION = JSON.parse(FileLib.read('V5', 'metadata.json')).version;
export const IS_MC_26_3 = java.lang.System.getProperty('v5.minecraft_version') === '26.3';
export const ScriptKey = {
    SPACE: 32,
    V: 86,
    ESCAPE: 256,
    ENTER: 257,
    BACKSPACE: 259,
    RIGHT: 262,
    LEFT: 263,
};

export const StandardCharsets = java.nio.charset.StandardCharsets;
export const BufferedInputStream = java.io.BufferedInputStream;
export const DataFlavor = java.awt.datatransfer.DataFlavor;
export const InputStreamReader = java.io.InputStreamReader;
export const BufferedReader = java.io.BufferedReader;
export const FileInputStream = java.io.FileInputStream;
export const FileOutputStream = java.io.FileOutputStream;
export const OutputStreamWriter = java.io.OutputStreamWriter;
export const ProcessBuilder = java.lang.ProcessBuilder;
export const Files = java.nio.file.Files;
export const StandardCopyOption = java.nio.file.StandardCopyOption;
export const Runtime = java.lang.Runtime;
export const Scanner = java.util.Scanner;
export const Toolkit = java.awt.Toolkit;
export const AudioSystem = javax.sound.sampled.AudioSystem;
export const FloatControl = javax.sound.sampled.FloatControl;
export const AudioFormat = javax.sound.sampled.AudioFormat;
export const SourceDataLine = javax.sound.sampled.SourceDataLine;
export const DataLine = javax.sound.sampled.DataLine;
export const BufferUtils = org.lwjgl.BufferUtils;
export const GLFW = IS_MC_26_3 ? null : Java.type('org.lwjgl.glfw.GLFW');
export const SDLVideo = IS_MC_26_3 ? Java.type('org.lwjgl.sdl.SDLVideo') : null;
export const SDLRect = IS_MC_26_3 ? Java.type('org.lwjgl.sdl.SDL_Rect') : null;
export const System = java.lang.System;
export const SystemTray = java.awt.SystemTray;
export const TrayIcon = java.awt.TrayIcon;
export const Arrays = java.util.Arrays;
export const AtomicInteger = java.util.concurrent.atomic.AtomicInteger;
export const Executors = java.util.concurrent.Executors;
export const JavaArray = java.lang.reflect.Array;
export const JavaByte = java.lang.Byte;
export const JavaInteger = java.lang.Integer;
export const JavaLong = java.lang.Long;
export const Color = java.awt.Color;
export const File = java.io.File;
export const URL = java.net.URL;

const os = System.getProperty('os.name').toLowerCase();
export const isWindows = os.includes('win');
export const isLinux = os.includes('nux') || os.includes('nix');

export const globalAssetsDir = new File('./config/ChatTriggers/assets');

export const BP = net.minecraft.core.BlockPos;
export const Vec3d = net.minecraft.world.phys.Vec3;
export const ClipContext = net.minecraft.world.level.ClipContext;
export const Direction = net.minecraft.core.Direction;
export const BlockHitResult = net.minecraft.world.phys.BlockHitResult;
export const Blocks = net.minecraft.world.level.block.Blocks;
export const SnowBlock = net.minecraft.world.level.block.SnowLayerBlock;
export const MobEntity = net.minecraft.world.entity.Mob;
export const PlayerEntity = net.minecraft.world.entity.player.Player;
export const CreeperEntity = net.minecraft.world.entity.monster.Creeper;
export const ArmorStandEntity = net.minecraft.world.entity.decoration.ArmorStand;
export const ZombieEntity = net.minecraft.world.entity.monster.zombie.Zombie;
export const EndermanEntity = Java.type(`net.minecraft.world.entity.monster.${IS_MC_26_3 ? 'Enderman' : 'EnderMan'}`);
export const ShulkerEntity = net.minecraft.world.entity.monster.Shulker;
export const PortalParticle = net.minecraft.client.particle.PortalParticle;
export const ParticleTypes = net.minecraft.core.particles.ParticleTypes;
export const DataComponents = net.minecraft.core.component.DataComponents;
export const InputConstants = com.mojang.blaze3d.platform.InputConstants;
export const SkijaPIP = Java.type('com.chattriggers.ctjs.api.render.skia.SkijaPIP');
export const CritParticle = ParticleTypes.CRIT;
export const HappyVillagerParticle = ParticleTypes.HAPPY_VILLAGER;

export const SoundCategory = net.minecraft.sounds.SoundSource;
export const Identifier = net.minecraft.resources.Identifier;
export const SoundEvent = net.minecraft.sounds.SoundEvent;
export const Consumer = Java.type('java.util.function.Consumer');
export const ScreenshotRecorder = net.minecraft.client.Screenshot;

export const V5ConfigFile = new File('./config/ChatTriggers/modules/V5Config/config.json');

import { notificationManager } from '../gui/NotificationManager';
import { OverlayManager } from '../gui/OverlayUtils';
import { Categories } from '../gui/categories/CategorySystem';
import { chat } from './Chat';
import { getModule, isMacroRunning, markEnabledModulesChanged, onModuleDisabled, onModuleEnabled, registerModule } from './MacroState';
import { ScheduleTask } from './ScheduleTask';
import { registerSkyblockEvent } from './SkyblockEvents';
import { ScriptKey } from './Constants';
import { getConfigFile, writeConfigFile } from './Utils';

export class ModuleBase {
    static conditions = [];
    static conditionChecker = null;
    static worldUnloadModules = new Set();
    static worldUnloadRegister = null;
    static keybinds = null;
    static toggleKeys = [];
    static keybindUnloadRegister = null;
    static loadingUserScript = false;
    static defaultThemes = {
        Combat: '#c74d4d',
        Core: '#7c8cff',
        Farming: '#9bc53d',
        Foraging: '#4cbf7b',
        Mining: '#5a7cbb',
        Other: '#5fb0ff',
        Skills: '#65a6f0',
        Visuals: '#94a2bb',
    };

    /**
     * Create a new module
     * @param {string|object} nameOrOpts - Module name or options object
     * @param {string} [subcategory] - Subcategory name (required if nameOrOpts is string)
     * @param {string} [description=''] - Module description (required if nameOrOpts is string)
     * @param {string} [tooltip=null] - Tooltip text (required if nameOrOpts is string)
     * @param {object} [opts] - Options object with properties: name, subcategory, description, tooltip, theme, developerMode, showEnabledToggle, autoDisableOnWorldUnload, isMacro, ignoreFailsafes
     */
    constructor(nameOrOpts, subcategory, description = '', tooltip = null) {
        const opts = typeof nameOrOpts === 'object' ? nameOrOpts : { name: nameOrOpts, subcategory, description, tooltip };

        this.name = opts.name;
        this.subcategory = opts.subcategory;
        this.description = opts.description || '';
        this.tooltip = opts.tooltip || null;
        this.enabled = false;
        this.oid = null;
        this.hexCode = null;
        this.hideInModules = opts.hideInModules === true;
        this.isMacro = opts.isMacro === true;
        this.showEnabledToggle = opts.showEnabledToggle ?? !this.isMacro;
        this.setTheme(opts.theme || ModuleBase.getDefaultTheme(this.subcategory));

        this.isParentManaged = false;

        this.ignoreFailsafes = opts.ignoreFailsafes === true;

        registerModule(this);

        this._registers = [];

        // add to gui
        if (!this.hideInModules) {
            const moduleType = opts.developerMode === true ? 'developer' : ModuleBase.loadingUserScript ? 'user' : null;
            Categories.addCategoryItem(this.subcategory, this.name, this.description, this.tooltip, moduleType);
        }

        if (opts.autoDisableOnWorldUnload) {
            ModuleBase.worldUnloadModules.add(this);
            ModuleBase.worldUnloadRegister ??= register('worldUnload', () => {
                ModuleBase.worldUnloadModules.forEach((module) => module.toggle(false));
            });
        }

        if (opts.isMacro) {
            registerSkyblockEvent('limbo', () => {
                if (!this.enabled) return;
                this.toggle(false);
                chat('&cYou were spawned in limbo! Attempting to recover...');
                ChatLib.command('leave');
                ScheduleTask(20, () => {
                    ChatLib.command('play skyblock');
                });
                ScheduleTask(60, () => {
                    this.toggle(true, false, 'recovery');
                    chat('&aRecovered from limbo?');
                });
            });
        }

        ModuleBase.setupConditionChecker();
    }

    static getDefaultTheme(subcategory) {
        return ModuleBase.defaultThemes[subcategory] || '#5fb0ff';
    }

    static setupConditionChecker() {
        if (ModuleBase.conditionChecker) return ModuleBase.syncConditionChecker();

        ModuleBase.conditionChecker = register('tick', () => {
            for (const item of ModuleBase.conditions) {
                if (item.ownerEnabled && !item.parent.enabled) continue;
                const shouldBeActive = !!item.condition();

                if (shouldBeActive && !item.isRegistered) {
                    item.action.register();
                    item.isRegistered = true;
                } else if (!shouldBeActive && item.isRegistered) {
                    item.action.unregister();
                    item.isRegistered = false;
                }
            }
        }).unregister();
        ModuleBase.syncConditionChecker();
    }

    static syncConditionChecker() {
        const shouldPoll = ModuleBase.conditions.some((item) => !item.ownerEnabled || item.parent.enabled);
        if (shouldPoll && !ModuleBase.conditionChecker.isRegistered()) ModuleBase.conditionChecker.register();
        else if (!shouldPoll && ModuleBase.conditionChecker.isRegistered()) ModuleBase.conditionChecker.unregister();

        for (const item of ModuleBase.conditions) {
            if (item.ownerEnabled && !item.parent.enabled && item.isRegistered) {
                item.action.unregister();
                item.isRegistered = false;
            }
        }
    }

    // automatically handle enabling/disabling of registers
    trackRegister(register) {
        if (register && register.register && register.unregister) {
            this._registers.push(register);
        }
        return register;
    }

    // create + track a register in one line
    on(registerName, callback) {
        const h = register(registerName, callback).unregister();
        return this.trackRegister(h);
    }

    // toggle register based on the condition
    when(condition, registerName, callback, ownerEnabled = false) {
        const actionRegister = register(registerName, callback).unregister();

        ModuleBase.conditions.push({
            parent: this,
            condition: condition,
            action: actionRegister,
            isRegistered: false,
            ownerEnabled,
        });
        ModuleBase.syncConditionChecker();
    }

    /**
     * Toggle the module on/off
     * @param {boolean} [value] - Optional: force specific state (true/false). If undefined, toggles current state.
     * @param {boolean} [parentManaged=false] - If true, this enable was triggered by another module. Hides overlay and prevents double-state recording.
     * @param {string} [toggleContext='user'] - Source of the toggle event (user, scheduler).
     */
    toggle(value, parentManaged = false, toggleContext = 'user') {
        const newVal = typeof value === 'boolean' ? value : !this.enabled;

        if (this.enabled === newVal) {
            if (newVal) this.isParentManaged = parentManaged;
            return;
        }

        this.enabled = newVal;
        markEnabledModulesChanged();

        if (newVal) {
            this.isParentManaged = parentManaged;

            if (this.isMacro) {
                Client.setMacroEnabled(true);
                onModuleEnabled(this.name);
            }

            if (this.oid && !this.isParentManaged) {
                OverlayManager.startTime(this.oid, this.isMacro);
            }

            this.toggleContext = toggleContext;

            try {
                this.onEnable();
            } catch (e) {
                console.error(`Error in ${this.name}.onEnable():`);
                console.error('V5 Caught error' + e + e.stack);
                this.toggle(false, parentManaged, toggleContext);
                return;
            }
            if (!this.enabled) return;
            this._registers.forEach((h) => h.register());
            ModuleBase.syncConditionChecker();
        } else {
            if (this.isMacro) {
                onModuleDisabled(this.name, toggleContext);
                Client.setMacroEnabled(isMacroRunning());
            }

            if (this.oid) {
                if (this.isMacro) {
                    OverlayManager.pauseTime(this.oid);
                } else {
                    OverlayManager.resetTime(this.oid);
                }
            }

            this._registers.forEach((h) => h.unregister());
            ModuleBase.syncConditionChecker();
            try {
                this.onDisable();
            } catch (e) {
                console.error(`Error in ${this.name}.onDisable():`);
                console.error('V5 Caught error' + e + e.stack);
            }

            this.isParentManaged = false;
        }
    }

    setTheme(hexCode) {
        if (!hexCode || typeof hexCode !== 'string') {
            this.hexCode = null;
            return this;
        }

        if (hexCode.startsWith('&#') || hexCode.startsWith('&')) {
            this.hexCode = hexCode;
            return this;
        }

        this.hexCode = `&${hexCode}`;
        return this;
    }

    message(message) {
        if (!this.name) return chat('&cModule message error!');
        const theme = this.hexCode || `&${ModuleBase.getDefaultTheme(this.subcategory)}`;
        if (theme.startsWith('&#')) {
            return chat(new TextComponent({ text: `${this.name}: `, color: `#${theme.slice(2)}` }, `&f${message}`));
        }
        if (theme.startsWith('#')) {
            return chat(new TextComponent({ text: `${this.name}: `, color: theme }, `&f${message}`));
        }
        chat(`${theme}${this.name}: &f${message}`);
    }

    bindToggleKey(title = `Toggle ${this.name}`) {
        const existingKeybinds = (ModuleBase.keybinds ??= getConfigFile('keybinds.json') || {});
        const savedKeycode = existingKeybinds[title] || Keyboard.KEY_NONE;
        this._wrappedKeyTitle = title;
        this._wrappedKey = new KeyBind(title, savedKeycode, `v5_${this.subcategory.toLowerCase()}`);

        this._wrappedKey.registerKeyPress(() => {
            this.requestToggleFromUser();
        });

        ModuleBase.toggleKeys.push({ title, keybind: this._wrappedKey });
        ModuleBase.keybindUnloadRegister ??= register('gameUnload', () => {
            ModuleBase.toggleKeys.forEach(({ title, keybind }) => {
                ModuleBase.keybinds[title] = keybind.getKeyCode();
            });
            writeConfigFile('keybinds.json', ModuleBase.keybinds);
        });
        return this;
    }

    getToggleKeyName() {
        const keyCode = this._wrappedKey?.getKeyCode?.();
        return keyCode === undefined || keyCode === null || keyCode <= 0 ? 'Unbound' : this._wrappedKey.getKeyName();
    }

    setToggleKey(keyCode) {
        const unbound = keyCode === ScriptKey.ESCAPE;
        this._wrappedKey?.setKeyCode(unbound ? Keyboard.KEY_NONE : keyCode);
        this._saveKey(this._wrappedKeyTitle, unbound ? Keyboard.KEY_NONE : keyCode);
    }

    /**
     * Toggle initiated by user input (keybind/gui button).
     * Preserves scheduler cancel and parent-managed safeguards.
     * @returns {boolean} True when this action enabled the module.
     */
    requestToggleFromUser() {
        if (this.isMacro && !this.enabled) {
            const scheduler = getModule('Scheduler');
            if (scheduler && typeof scheduler.cancelScheduledMacro === 'function') {
                if (scheduler.cancelScheduledMacro(this.name)) return false;
            }
        }

        if (this.enabled && this.isParentManaged) {
            notificationManager.add('Cannot toggle module', `${this.name} is being managed by another macro. Toggle the parent macro.`, 'ERROR', 5000);
            return false;
        }

        const wasEnabled = this.enabled;
        this.toggle();
        return !wasEnabled && this.enabled;
    }

    createOverlay(args, options = {}) {
        this.oid = this.name;
        OverlayManager.createID(this.oid, args, options);
    }

    createSchedulerOverlay(args) {
        this.oid = this.name;
        OverlayManager.createSchedulerID(this.oid, args);
    }

    /**
     * Add a toggle to the module's GUI
     * @param {string} title - The title of the toggle
     * @param {function} callback - Callback function when toggle state changes
     * @param {string} [description=null] - Description/tooltip for the toggle
     * @param {boolean} [defaultValue=false] - Optional: Default value for the toggle
     */
    addToggle(title, callback, description = null, defaultValue = false) {
        return Categories.addToggle('Modules', this.name, title, callback, description, defaultValue);
    }

    /**
     * Add a toggle directly to the Settings page
     * @param {string} title - The title of the toggle
     * @param {function} callback - Callback function when toggle state changes
     * @param {string} [description=null] - Description/tooltip for the toggle
     * @param {boolean} [defaultValue=false] - Optional: Default value for the toggle
     * @param {string} [sectionName=null] - Optional: Section header within Settings
     */
    addDirectToggle(title, callback, description = null, defaultValue = false, sectionName = null) {
        return Categories.addSettingsToggle(title, callback, description, defaultValue, sectionName, 'Settings');
    }

    /**
     * Add a slider control to the module's GUI
     * @param {string} title - The title of the slider
     * @param {number} min - Minimum value
     * @param {number} max - Maximum value
     * @param {number} def - Default value
     * @param {function} callback - Callback function when slider value changes
     * @param {string} [description=null] - Description/tooltip for the slider
     */
    addSlider(title, min, max, def, callback, description = null) {
        return Categories.addSlider('Modules', this.name, title, min, max, def, callback, description);
    }

    /**
     * Add a slider directly to the Settings page
     * @param {string} title - The title of the slider
     * @param {number} min - Minimum value
     * @param {number} max - Maximum value
     * @param {number} def - Default value
     * @param {function} callback - Callback function when slider value changes
     * @param {string} [description=null] - Description/tooltip for the slider
     * @param {string} [sectionName=null] - Optional: Section header within Settings
     */
    addDirectSlider(title, min, max, def, callback, description = null, sectionName = null) {
        return Categories.addSettingsSlider(title, min, max, def, callback, description, sectionName, 'Settings');
    }

    /**
     * Add a range slider control to the module's GUI
     * @param {string} title - The title of the slider
     * @param {number} min - Minimum value
     * @param {number} max - Maximum value
     * @param {object} def - Default values {low, high}
     * @param {function} callback - Callback function when slider value changes
     * @param {string} [description=null] - Description/tooltip for the slider
     */
    addRangeSlider(title, min, max, def, callback, description = null) {
        return Categories.addRangeSlider('Modules', this.name, title, min, max, def, callback, description);
    }

    /**
     * Add a range slider directly to the Settings page
     * @param {string} title - The title of the slider
     * @param {number} min - Minimum value
     * @param {number} max - Maximum value
     * @param {object} def - Default values {low, high}
     * @param {function} callback - Callback function when slider value changes
     * @param {string} [description=null] - Description/tooltip for the slider
     * @param {string} [sectionName=null] - Optional: Section header within Settings
     */
    addDirectRangeSlider(title, min, max, def, callback, description = null, sectionName = null) {
        return Categories.addSettingsRangeSlider(title, min, max, def, callback, description, sectionName, 'Settings');
    }

    /**
     * Add a multi-toggle control to the module's GUI
     * @param {string} title - The title of the multi-toggle
     * @param {Array} options - Array of option names
     * @param {boolean} [singleSelect=false] - Whether only one option can be selected at a time
     * @param {function} callback - Callback function when selection changes
     * @param {string} [description=null] - Description/tooltip for the multi-toggle
     * @param {string} [defaultValue=false] - Optional: Default selected option name
     */
    addMultiToggle(title, options, singleSelect, callback, description = null, defaultValue = false) {
        return Categories.addMultiToggle('Modules', this.name, title, options, !!singleSelect, callback, description, defaultValue);
    }

    /**
     * Add a multi-toggle directly to the Settings page
     * @param {string} title - The title of the multi-toggle
     * @param {Array} options - Array of option names
     * @param {boolean} [singleSelect=false] - Whether only one option can be selected at a time
     * @param {function} callback - Callback function when selection changes
     * @param {string} [description=null] - Description/tooltip for the multi-toggle
     * @param {string} [defaultValue=false] - Optional: Default selected option name
     * @param {string} [sectionName=null] - Optional: Section header within Settings
     */
    addDirectMultiToggle(title, options, singleSelect, callback, description = null, defaultValue = false, sectionName = null) {
        return Categories.addSettingsMultiToggle(title, options, !!singleSelect, callback, description, defaultValue, sectionName, 'Settings');
    }

    /**
     * Add a color picker to the module's GUI
     * @param {string} title - The title of the color picker
     * @param {object} defaultColor - Default color (java.awt.Color)
     * @param {function} callback - Callback function when color changes
     * @param {string} [description=null] - Description/tooltip for the color picker
     */
    addColorPicker(title, defaultColor, callback, description = null) {
        return Categories.addColorPicker('Modules', this.name, title, defaultColor, callback, description);
    }

    /**
     * Add a text input to the module's GUI
     * @param {string} title - The title of the text input
     * @param {string} defaultValue - Default text
     * @param {function} callback - Callback function when text changes
     * @param {string} [description=null] - Description/tooltip
     */
    addTextInput(title, defaultValue, callback, description = null) {
        return Categories.addTextInput('Modules', this.name, title, defaultValue, callback, description);
    }

    /**
     * Add a button to the module's GUI
     * @param {string} title - The title of the button
     * @param {function} callback - Callback function when button is pressed
     * @param {string} [description=null] - Description/tooltip
     */
    addButton(title, callback, description = null) {
        return Categories.addButton('Modules', this.name, title, callback, description);
    }

    /**
     * Add a popup to the module's GUI
     * @param {string} title - The title of the popup
     * @param {function} callback - Callback function when popup opens/closes
     * @param {string} [description=null] - Description/tooltip
     */
    addPopup(title, callback, description = null) {
        return Categories.addPopup('Modules', this.name, title, callback, description);
    }

    /**
     * Add a separator to the module's GUI
     * @param {string} title - The title of the separator
     * @param {boolean} [fullWidth=false] - Whether the separator spans the full panel width
     */
    addSeparator(title, fullWidth = false) {
        return Categories.addSeparator('Modules', this.name, title, fullWidth);
    }

    // Allow for overriding onEnable and onDisable if you need more control
    // not required
    onEnable() {}
    onDisable() {}

    /**
     * @private
     * Saves a specific keybind description and keycode.
     */
    _saveKey(description, keycode) {
        const allKeybinds = (ModuleBase.keybinds ??= getConfigFile('keybinds.json') || {});
        allKeybinds[description] = keycode;
        writeConfigFile('keybinds.json', allKeybinds);
    }
}

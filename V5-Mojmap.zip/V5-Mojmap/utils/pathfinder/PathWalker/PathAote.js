import { chatPathfinder } from '../../Chat';
import { BP, SnowBlock } from '../../Constants';
import { wrapTo180 } from '../../Math';
import { getCurrentMana } from '../../Utils';
import { findItemInHotbar, setItemSlot } from '../../player/Inventory';
import PathConfig from '../PathConfig';
import { Jump } from './PathJumps';
import { isRecovering } from './PathMovement';

class PathAote {
    constructor() {
        this.cooldownTicks = 0;
        this.MAX_AIM_YAW_ERROR = 12;
        this.FINAL_POINT_NO_AOTE_RADIUS = 18;

        this.originalSlot = -1;
        this.activeAoteSlot = -1;
        this.hasSwappedToAote = false;

        this.lastSkipReason = '';
        this.lastMissingItemAt = 0;
        this.AOTE_MIN_GAIN = 10;
        this.AOTE_STRAIGHTNESS_THRESHOLD = 25;
        this.MINIMUM_MANA_TO_USE = 100;
        this.MINIMUM_TOTAL_PATH_LENGTH = 40;
        this.STRAIGHTNESS_RELAX_IN_FLUID_DEGREES = 10;
        this.MIN_GAIN_RELAX_IN_FLUID_DISTANCE = 4;
    }

    onPathTick(rotations, flying = false) {
        if (!rotations || !rotations.boxPositions || !rotations.rotationActive || rotations.complete) return;

        const player = Player.getPlayer();
        if (!player) return;

        if (!flying && this.getDistanceToFinalPoint(rotations) <= this.FINAL_POINT_NO_AOTE_RADIUS) {
            this.restoreOriginalSlot();
            return this.debug('near final point');
        }

        if (this.cooldownTicks > 0) {
            this.cooldownTicks--;
            this.debug('cooldown');
            return;
        }

        if (!flying && this.getTotalPathLength(rotations) < this.MINIMUM_TOTAL_PATH_LENGTH) {
            return this.debug(`total path too short (<${this.MINIMUM_TOTAL_PATH_LENGTH})`);
        }

        const slot = this.findAoteSlot();
        if (slot == null) {
            const now = Date.now();
            if (PathConfig.PATHFINDING_DEBUG && now - this.lastMissingItemAt > 1500) {
                this.lastMissingItemAt = now;
                chatPathfinder('§7AOTE: item missing');
            }
            return;
        }

        if (!this.ensureAoteHeld(slot)) return;

        const playerInFluid = this.isPlayerInFluid();
        let minGain = this.AOTE_MIN_GAIN;
        let straightness = this.AOTE_STRAIGHTNESS_THRESHOLD;
        if (playerInFluid) {
            straightness += this.STRAIGHTNESS_RELAX_IN_FLUID_DEGREES;
            minGain -= this.MIN_GAIN_RELAX_IN_FLUID_DISTANCE;
        }

        if (isRecovering()) {
            return this.debug('recovery');
        }

        if (!flying && Math.abs(Player.getMotionY()) > 0.25 && !playerInFluid) {
            return this.debug('vertical motion');
        }

        const candidate = this.getTargetAlongPath(rotations, minGain);
        if (!candidate || candidate.advanceDistance < minGain) {
            return this.debug('gain too small');
        }

        if (!this.isPathStraightEnough(rotations, candidate.targetPathPosition, straightness)) {
            return this.debug('not straight');
        }

        if (!this.isPlayerAimingTowardPath(rotations, candidate.targetPathPosition)) {
            return this.debug('not facing path');
        }

        if (this.estimateInstantTransmissionDistance(minGain) < minGain) {
            return this.debug('teleport too short');
        }

        if (!this.hasEnoughMana()) return;

        Client.rightClick();
        Jump.suppressJump(5);
        Jump.invalidateNearestIndex();
        rotations.onTeleportTriggered(candidate.targetPathPosition);
        this.cooldownTicks = 10;

        if (PathConfig.PATHFINDING_DEBUG) {
            chatPathfinder(`§bAOTE: used at pathPos ${rotations.currentPathPosition.toFixed(1)}`);
        }
    }

    findAoteSlot() {
        const aotv = findItemInHotbar('Aspect of the Void');
        if (aotv !== -1) return aotv;

        const aote = findItemInHotbar('Aspect of the End');
        return aote !== -1 ? aote : null;
    }

    getBlockName(block) {
        try {
            return block?.type?.getRegistryName?.()?.toLowerCase?.() || '';
        } catch (e) {
            return '';
        }
    }

    ensureAoteHeld(slot) {
        if (slot == null || slot < 0 || slot > 8) return false;

        if (this.originalSlot === -1) {
            this.originalSlot = Player.getHeldItemIndex();
        }

        if (!this.hasSwappedToAote) {
            this.hasSwappedToAote = true;
            this.activeAoteSlot = slot;
            if (PathConfig.PATHFINDING_DEBUG) chatPathfinder(`§7AOTE: swapped to slot ${slot + 1}`);
        }

        if (Player.getHeldItemIndex() !== slot) {
            setItemSlot(slot);
            this.debug('waiting for slot swap');
            return false;
        }

        return true;
    }

    getTargetAlongPath(rotations, desiredDistance) {
        const path = rotations.boxPositions;
        const startT = rotations.currentPathPosition;

        if (!path || path.length < 2) return null;
        const pathEnd = path.length - 1;
        if (startT >= pathEnd - 0.1) return null;

        let prevPoint = rotations.getInterpolatedPoint(startT);
        if (!prevPoint) return null;
        let traveled = 0;
        let targetT = null;

        for (let t = startT + 1; t <= pathEnd; t += 1) {
            const point = rotations.getInterpolatedPoint(Math.min(pathEnd, t));
            if (!point) break;
            traveled += this.distance(prevPoint, point);

            if (traveled >= desiredDistance) {
                targetT = Math.min(pathEnd, t);
                break;
            }

            prevPoint = point;
        }

        if (targetT === null) targetT = pathEnd;

        return {
            targetPathPosition: targetT,
            advanceDistance: traveled,
        };
    }

    hasEnoughMana() {
        const mana = getCurrentMana();
        if (mana === null) {
            this.debug('mana unavailable');
            //return false;
        }

        if (mana < this.MINIMUM_MANA_TO_USE) {
            this.debug('low mana (<100)');
            return false;
        }

        return true;
    }

    isPathStraightEnough(rotations, targetPathPosition, thresholdDegrees) {
        const curvatureDegrees = (rotations.currentPathCurvature || 0) * (180 / Math.PI);
        if (curvatureDegrees > thresholdDegrees) return false;

        const startT = rotations.currentPathPosition;
        const startPoint = rotations.getInterpolatedPoint(startT);
        const endPoint = rotations.getInterpolatedPoint(targetPathPosition);
        const baseX = endPoint.x - startPoint.x;
        const baseZ = endPoint.z - startPoint.z;
        const baseLength = Math.hypot(baseX, baseZ);

        if (baseLength < 0.001) return false;

        const baseDirX = baseX / baseLength;
        const baseDirZ = baseZ / baseLength;

        let prev = startPoint;
        const step = 2;
        for (let t = startT + step; t <= targetPathPosition; t += step) {
            const curr = rotations.getInterpolatedPoint(Math.min(targetPathPosition, t));
            const dirX = curr.x - prev.x;
            const dirZ = curr.z - prev.z;
            const length = Math.hypot(dirX, dirZ);
            prev = curr;
            if (length < 0.001) continue;

            const dot = Math.max(-1, Math.min(1, (dirX / length) * baseDirX + (dirZ / length) * baseDirZ));
            const angle = Math.acos(dot) * (180 / Math.PI);
            if (angle > thresholdDegrees) return false;
        }

        return true;
    }

    isPlayerInFluid() {
        const playerMP = Player.asPlayerMP();
        return !!playerMP && (playerMP.isInWater() || playerMP.isInLava());
    }

    isPlayerAimingTowardPath(rotations, targetPathPosition) {
        const player = Player.getPlayer();
        if (!player) return false;

        const eyePos = player.getEyePosition();
        const target = rotations.getInterpolatedPoint(targetPathPosition);
        if (!eyePos || !target) return false;

        const dx = target.x - eyePos.x();
        const dz = target.z - eyePos.z();
        const horiz = Math.hypot(dx, dz);
        if (horiz < 0.001) return true;

        const targetYaw = -(Math.atan2(dx, dz) * (180 / Math.PI));
        const yawError = Math.abs(this.wrapAngle(targetYaw - wrapTo180(player.getYRot())));
        return yawError <= this.MAX_AIM_YAW_ERROR;
    }

    wrapAngle(angle) {
        let result = angle;
        while (result > 180) result -= 360;
        while (result < -180) result += 360;
        return result;
    }

    getLookDirection(player) {
        const yawRad = (-wrapTo180(player.getYRot()) * Math.PI) / 180;
        const pitchRad = (-player.getXRot() * Math.PI) / 180;
        const cosPitch = Math.cos(pitchRad);
        return {
            x: Math.sin(yawRad) * cosPitch,
            y: Math.sin(pitchRad),
            z: Math.cos(yawRad) * cosPitch,
        };
    }

    estimateInstantTransmissionDistance(maxDistance) {
        const player = Player.getPlayer();
        const world = World.getWorld();
        if (!player || !world) return 0;

        const start = player.getEyePosition();
        if (!start) return 0;

        const direction = this.getLookDirection(player);
        const xDiagonalOffset = direction.x > 0 ? 1 : -1;
        const zDiagonalOffset = direction.z > 0 ? 1 : -1;
        let closeFloorY = 2147483647;

        for (let offset = 0; offset <= maxDistance; offset++) {
            const posX = start.x + direction.x * offset;
            const posY = start.y + direction.y * offset;
            const posZ = start.z + direction.z * offset;

            const checkX = Math.floor(posX);
            const checkY = Math.floor(posY);
            const checkZ = Math.floor(posZ);

            if (!this.canTeleportThrough(checkX, checkY, checkZ)) {
                if (offset === 0) return 0;
                return Math.max(0, offset - 1);
            }

            if (!this.canTeleportThrough(checkX, checkY + 1, checkZ)) {
                if (offset === 0) {
                    const justAheadY = start.y + direction.y * 0.2;
                    if (justAheadY - Math.floor(justAheadY) <= 0.495) continue;
                    return 0;
                }
                return Math.max(0, offset - 1);
            }

            if (offset !== 0) {
                const prevX = Math.floor(start.x + direction.x * (offset - 1));
                const prevY = Math.floor(start.y + direction.y * (offset - 1));
                const prevZ = Math.floor(start.z + direction.z * (offset - 1));

                if (direction.x < 0 && this.isBlockFloor(checkX + 1, checkY, checkZ) && this.isBlockFloor(prevX, prevY, prevZ + zDiagonalOffset)) {
                    return Math.max(0, offset - 1);
                }

                if (
                    direction.z < 0 &&
                    direction.x < 0 &&
                    this.isBlockFloor(checkX, checkY, checkZ + 1) &&
                    this.isBlockFloor(prevX + xDiagonalOffset, prevY, prevZ)
                ) {
                    return Math.max(0, offset - 1);
                }
            }

            const nearFloor =
                this.isBlockFloor(checkX, checkY - 1, checkZ) ||
                (this.isBlockFloor(checkX + xDiagonalOffset, checkY - 1, checkZ) && this.isBlockFloor(checkX, checkY - 1, checkZ + zDiagonalOffset));

            if (nearFloor && posY - Math.floor(posY) < 0.31) {
                closeFloorY = checkY - 1;
            }

            if (closeFloorY === checkY) {
                return Math.max(0, offset - 1);
            }
        }

        return maxDistance;
    }

    canTeleportThrough(x, y, z) {
        const world = World.getWorld();
        if (!world) return false;

        const pos = new BP(x, y, z);
        const state = world.getBlockState(pos);
        if (!state) return false;

        if (state.isAir()) return true;

        const shape = state.getCollisionShape(world, pos);
        if (shape && shape.isEmpty()) return true;

        const block = World.getBlockAt(x, y, z);
        if (!block || !block.type) return false;

        const name = this.getBlockName(block);
        if (!name) return false;
        if (name.includes('carpet') || name.includes('flower_pot') || name.includes('web')) return true;

        if (name === 'minecraft:snow') {
            const layers = this.getSnowLayers(block);
            return layers > 0 && layers <= 3;
        }

        return false;
    }

    isBlockFloor(x, y, z) {
        const world = World.getWorld();
        if (!world) return false;

        const pos = new BP(x, y, z);
        const state = world.getBlockState(pos);
        if (!state) return false;

        const shape = state.getCollisionShape(world, pos);
        if (!shape || shape.isEmpty()) return false;

        const block = World.getBlockAt(x, y, z);
        if (!block || !block.type) return false;
        const name = this.getBlockName(block);
        if (!name) return false;
        return name.includes('mud') || !this.canTeleportThrough(x, y, z);
    }

    getSnowLayers(block) {
        if (this.getBlockName(block) !== 'minecraft:snow') return 0;
        try {
            return block.getState().getValue(SnowBlock.LAYERS);
        } catch (e) {
            return 0;
        }
    }

    getDistanceToFinalPoint(rotations) {
        const path = rotations?.boxPositions;
        const finalPoint = Array.isArray(path) && path.length ? path[path.length - 1] : null;
        if (!finalPoint) return Number.MAX_VALUE;
        const player = Player.getPlayer();
        if (!player) return Number.MAX_VALUE;
        const eyes = player.getEyePosition();
        const dx = eyes.x() - finalPoint.x;
        const dy = eyes.y() - finalPoint.y;
        const dz = eyes.z() - finalPoint.z;
        return Math.hypot(dx, dy, dz);
    }

    getTotalPathLength(rotations) {
        const path = rotations?.boxPositions;
        if (!path || path.length < 2) return 0;

        let distance = 0;
        for (let i = 1; i < path.length; i += 1) {
            distance += this.distance(path[i - 1], path[i]);
        }

        return distance;
    }

    distance(a, b) {
        const dx = b.x - a.x;
        const dy = b.y - a.y;
        const dz = b.z - a.z;
        return Math.hypot(dx, dy, dz);
    }

    debug(reason) {
        if (!PathConfig.PATHFINDING_DEBUG) return;
        if (reason === this.lastSkipReason) return;
        this.lastSkipReason = reason;
        chatPathfinder(`§7AOTE: skipped (${reason})`);
    }

    restoreOriginalSlot() {
        if (this.originalSlot >= 0 && this.originalSlot <= 8) {
            if (Player.getHeldItemIndex() !== this.originalSlot) {
                setItemSlot(this.originalSlot);
            }
            if (PathConfig.PATHFINDING_DEBUG) {
                chatPathfinder(`§7AOTE: restored original slot (${this.originalSlot + 1})`);
            }
        }

        this.originalSlot = -1;
        this.activeAoteSlot = -1;
        this.hasSwappedToAote = false;
    }

    stop(restoreSlot = true) {
        if (restoreSlot) this.restoreOriginalSlot();

        this.cooldownTicks = 0;
        this.lastSkipReason = '';
        this.lastMissingItemAt = 0;
    }
}

export const Aote = new PathAote();

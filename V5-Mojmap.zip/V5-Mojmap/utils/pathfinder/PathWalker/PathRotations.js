import { BP, Vec3d } from '../../Constants';
import { raytraceBlocks } from '../../dependencies/BloomCore/RaytraceBlocks';
import { Vector3 } from '../../dependencies/BloomCore/Vector3';
import { calculateAbsoluteAngles, getAngleDifference, wrapTo180 } from '../../Math';
import { applyToPlayer } from '../../player/RotationGCD';
import { onPathTick } from '../PathExecutor';
import { createLookPoints } from '../PathSpline';
import { predictXZ } from './PathPrediction';

class PathRotations {
    constructor() {
        this.MIN_LOOKAHEAD = 1.1;
        this.MAX_LOOKAHEAD = 3.5;
        this.RECOVERY_MIN_LOOKAHEAD = 0.1;
        this.PROXIMITY_THRESHOLD = 4.0;
        this.COMPLETION_RADIUS = 1.9;
        this.BASE_KP = 0.05;
        this.KD = 0.55;
        this.MAX_VELOCITY = 8.0;
        this.ACCEL_LIMIT = 1.2;
        this.SETTLE_THRESHOLD = 0.15;
        this.PITCH_DEADZONE = 1.8;
        this.YAW_DEADZONE = 1.2;
        this.SMOOTH_FACTOR = 0.1;
        this.MAX_LOOK_DISTANCE = 0.8;
        this.LOOKAHEAD_STEP = 0.4;
        this.RECOVERY_LOOKAHEAD_STEP = 0.15;
        this.MAX_DIRECTION_DIVERGENCE = 50.0;
        this.MAX_UPWARD_PITCH = -45.0;
        this.PREDICTION_TICKS = 10;
        this.PREDICTION_MIN_SPEED_XZ = 0.05;
        this.PREDICTION_MAX_ADVANCE_GROUND = 0.9;
        this.PREDICTION_MAX_ADVANCE_AIR = 2.4;
        this.TELEPORT_RESYNC_DURATION_TICKS = 14;
        this.TELEPORT_RESYNC_SEARCH_WINDOW = 72;
        this.ENTITY_TRACK_DISTANCE = 8;
        this.ENTITY_BLEND_RATE = 0.08;
        this.MIN_HORIZONTAL_LOOK = 1.2;
        this.MAX_AIR_TURN = 90;
        this.lookaheadOverride = null;
        this.lookaheadOverrideExpiry = 0;
        this.currentPathCurvature = 0;
        this.entityTarget = null;
        this.entityTrackDistance = this.ENTITY_TRACK_DISTANCE;

        this.resetRotations();

        this.renderRegister = register('renderWorld', () => {
            if (!this.rotationActive || !this.boxPositions || this.boxPositions.length < 2) return;
            if (!Player.getPlayer()) {
                this.resetRotations();
                return;
            }
            const now = Date.now();
            const timeScale = this.lastRotationUpdate ? Math.min(2, (now - this.lastRotationUpdate) / (1000 / 120)) : 1;
            this.lastRotationUpdate = now;
            this.updateLookPoint(timeScale);
            this.applyHumanizedPhysics(timeScale);
            applyToPlayer(this.currentYaw, this.currentPitch);
        }).unregister();

        onPathTick(() => {
            if (this.postTeleportResyncTicks > 0) {
                this.postTeleportResyncTicks--;
            }

            if (this.lookaheadOverrideExpiry > 0) {
                this.lookaheadOverrideExpiry--;
                if (this.lookaheadOverrideExpiry <= 0) {
                    this.lookaheadOverride = null;
                }
            }
        });
    }

    resetRotations() {
        this.currentPathPosition = 0.0;
        this.isInitialized = false;
        this.complete = false;
        this.rotationActive = false;
        this.yawVelocity = 0;
        this.pitchVelocity = 0;
        this.rawTargetYaw = 0;
        this.rawTargetPitch = 0;
        this.currentYaw = 0;
        this.currentPitch = 0;
        this.boxPositions = null;
        this.currentTargetPoint = null;
        this.smoothedLookahead = this.MAX_LOOKAHEAD;
        this.lookaheadOverride = null;
        this.lookaheadOverrideExpiry = 0;
        this.unseenSince = 0;
        this.unseenStartPathPosition = 0;
        this.currentPathCurvature = 0;
        this.lastRotationUpdate = 0;
        this.initialTurnBoostTicks = 0;
        this.postTeleportResyncTicks = 0;
        this.entityTarget = null;
        this.entityTrackDistance = this.ENTITY_TRACK_DISTANCE;
        this.entityBlend = 0;
        this.lastEntityLookPoint = null;
        this.syncRender();
    }

    syncRender() {
        if (this.rotationActive && !this.renderRegister?.isRegistered()) this.renderRegister.register();
        else if (!this.rotationActive && this.renderRegister?.isRegistered()) this.renderRegister.unregister();
    }

    onTeleportTriggered(targetPathPosition = null) {
        this.postTeleportResyncTicks = this.TELEPORT_RESYNC_DURATION_TICKS;
        this.unseenSince = 0;
        this.unseenStartPathPosition = this.currentPathPosition;
        this.setTemporaryLookahead(this.MAX_LOOKAHEAD, this.TELEPORT_RESYNC_DURATION_TICKS);

        if (typeof targetPathPosition === 'number') {
            this.currentPathPosition = Math.max(this.currentPathPosition, Math.max(0, targetPathPosition - 2.0));
        }
    }

    shouldBoostInitialTurn(yawError) {
        return this.initialTurnBoostTicks > 0 && Math.abs(yawError) >= Math.max(35.0, this.YAW_DEADZONE * 4);
    }

    getInitialTurnBoostFactor(yawError) {
        return this.shouldBoostInitialTurn(yawError) ? 2.0 : 1.0;
    }

    isPointVisible(playerEyes, targetPoint, allowEndpointCollision = true) {
        const dx = targetPoint.x - playerEyes.x();
        const dy = targetPoint.y - playerEyes.y();
        const dz = targetPoint.z - playerEyes.z();
        const dist = Math.sqrt(dx * dx + dy * dy + dz * dz);
        if (dist < 0.2) return true;
        try {
            const dir = new Vector3(dx / dist, dy / dist, dz / dist);
            const hit = raytraceBlocks(
                [playerEyes.x(), playerEyes.y(), playerEyes.z()],
                dir,
                dist + 0.1,
                (block) => {
                    if (!block || !block.type || block.type.getID() === 0) return false;
                    try {
                        const world = World.getWorld();
                        const pos = new BP(Math.floor(block.getX()), Math.floor(block.getY()), Math.floor(block.getZ()));
                        const state = world.getBlockState(pos);
                        return !state.getCollisionShape(world, pos).isEmpty();
                    } catch (e) {
                        return true;
                    }
                },
                true
            );
            if (!hit || !allowEndpointCollision) return !hit;
            const hitX = hit[0] + 0.5;
            const hitY = hit[1] + 0.5;
            const hitZ = hit[2] + 0.5;
            const hdx = hitX - playerEyes.x();
            const hdy = hitY - playerEyes.y();
            const hdz = hitZ - playerEyes.z();
            const hitDist = Math.sqrt(hdx * hdx + hdy * hdy + hdz * hdz);
            return hitDist >= dist - 0.5;
        } catch (e) {
            return allowEndpointCollision;
        }
    }

    getAngleBetweenVectors(v1, v2) {
        const mag1 = Math.sqrt(v1.x * v1.x + v1.y * v1.y + v1.z * v1.z);
        const mag2 = Math.sqrt(v2.x * v2.x + v2.y * v2.y + v2.z * v2.z);
        if (mag1 < 0.001 || mag2 < 0.001) return 0;
        const dot = v1.x * v2.x + v1.y * v2.y + v1.z * v2.z;
        const val = Math.max(-1, Math.min(1, dot / (mag1 * mag2)));
        return Math.acos(val) * (180 / Math.PI);
    }

    setTemporaryLookahead(distance, durationTicks = 30) {
        this.lookaheadOverride = distance;
        this.lookaheadOverrideExpiry = durationTicks;
        this.smoothedLookahead = distance;
    }

    isInRecoveryMode() {
        return this.lookaheadOverride !== null && this.lookaheadOverrideExpiry > 0;
    }

    findVisibleLookahead(playerEyes, idealLookahead) {
        const immediateT = Math.min(this.boxPositions.length - 1, this.currentPathPosition + 0.5);
        const immediatePoint = this.getInterpolatedPoint(immediateT);
        const vecImmediate = {
            x: immediatePoint.x - playerEyes.x(),
            y: immediatePoint.y - playerEyes.y(),
            z: immediatePoint.z - playerEyes.z(),
        };
        const inRecovery = this.isInRecoveryMode();
        const effectiveMin = inRecovery ? this.RECOVERY_MIN_LOOKAHEAD : this.MIN_LOOKAHEAD;
        let lookahead = inRecovery ? idealLookahead : Math.max(idealLookahead, this.MIN_LOOKAHEAD);
        while (lookahead >= effectiveMin) {
            const t = Math.min(this.boxPositions.length - 1, this.currentPathPosition + lookahead);
            const point = this.getInterpolatedPoint(t);
            const dx = point.x - playerEyes.x();
            const dy = point.y - playerEyes.y();
            const dz = point.z - playerEyes.z();
            const horzDist = Math.hypot(dx, dz);
            if (lookahead >= this.MIN_LOOKAHEAD) {
                if (dy > 1.8 && horzDist < 0.8) {
                    lookahead -= this.LOOKAHEAD_STEP;
                    continue;
                }
                const pitch = -Math.atan2(dy, horzDist) * (180 / Math.PI);
                if (pitch < this.MAX_UPWARD_PITCH && horzDist < 1.5) {
                    lookahead -= this.LOOKAHEAD_STEP;
                    continue;
                }
                const vecTarget = { x: dx, y: dy, z: dz };
                const divergence = this.getAngleBetweenVectors(vecImmediate, vecTarget);
                if (divergence > this.MAX_DIRECTION_DIVERGENCE) {
                    lookahead -= this.LOOKAHEAD_STEP;
                    continue;
                }
            }
            if (this.isPointVisible(playerEyes, point)) {
                return { point, lookahead };
            }
            const step = lookahead < this.MIN_LOOKAHEAD ? this.RECOVERY_LOOKAHEAD_STEP : this.LOOKAHEAD_STEP;
            lookahead -= step;
        }
        let closeLookahead = Math.max(this.RECOVERY_MIN_LOOKAHEAD, this.MIN_LOOKAHEAD - 0.2);
        while (closeLookahead >= this.RECOVERY_MIN_LOOKAHEAD) {
            const t = Math.min(this.boxPositions.length - 1, this.currentPathPosition + closeLookahead);
            const point = this.getInterpolatedPoint(t);
            if (this.isPointVisible(playerEyes, point)) {
                return { point, lookahead: closeLookahead };
            }
            closeLookahead -= this.RECOVERY_LOOKAHEAD_STEP;
        }
        const t = Math.min(this.boxPositions.length - 1, this.currentPathPosition + effectiveMin);
        return { point: this.getInterpolatedPoint(t), lookahead: effectiveMin };
    }

    getAdaptiveLookahead(playerEyes, timeScale = 1) {
        if (this.lookaheadOverride !== null && this.lookaheadOverrideExpiry > 0) return this.lookaheadOverride;
        const targetIndex = Math.floor(this.currentPathPosition);
        if (targetIndex + 3 >= this.boxPositions.length) return this.smoothedLookahead;
        const pathPoint = this.getInterpolatedPoint(this.currentPathPosition);
        const pdx = playerEyes.x() - pathPoint.x;
        const pdz = playerEyes.z() - pathPoint.z;
        const deviationFromPath = Math.sqrt(pdx * pdx + pdz * pdz);
        const deviationFactor = Math.min(1, Math.max(0, (deviationFromPath - 1.6) / 2.0));
        const startIndex = this.boxPositions[targetIndex];
        const endIndex = this.boxPositions[Math.min(targetIndex + 2, this.boxPositions.length - 1)];
        const currDx = endIndex.x - startIndex.x;
        const currDy = endIndex.y - startIndex.y;
        const currDz = endIndex.z - startIndex.z;
        const startDirection = { x: currDx, y: currDy, z: currDz };
        const startDirectionMagnitude = Math.hypot(currDx, currDy, currDz);
        let maxAngle = 0;
        for (let lookahead = 4; lookahead <= 8; lookahead += 2) {
            const futureTargetIndex = Math.min(targetIndex + lookahead, this.boxPositions.length - 3);
            if (futureTargetIndex <= targetIndex + 2) continue;
            const futureA = this.boxPositions[futureTargetIndex];
            const futureB = this.boxPositions[Math.min(futureTargetIndex + 2, this.boxPositions.length - 1)];
            const futureDx = futureB.x - futureA.x;
            const futureDy = futureB.y - futureA.y;
            const futureDz = futureB.z - futureA.z;
            const futureDirection = { x: futureDx, y: futureDy, z: futureDz };
            const futureDirectionMagnitude = Math.hypot(futureDx, futureDy, futureDz);
            if (startDirectionMagnitude > 0.8 && futureDirectionMagnitude > 0.8) {
                const dotProduct =
                    (startDirection.x * futureDirection.x + startDirection.y * futureDirection.y + startDirection.z * futureDirection.z) /
                    (startDirectionMagnitude * futureDirectionMagnitude);
                const angle = Math.acos(Math.max(-1, Math.min(1, dotProduct)));
                maxAngle = Math.max(maxAngle, angle);
            }
        }
        this.currentPathCurvature = maxAngle;
        const isFalling = Player.getMotionY() < -0.1;
        if (isFalling) maxAngle *= 0.5;
        const curveFactor = Math.min(1, Math.max(0, (maxAngle - 0.61) / 0.7));
        const adjustFactor = Math.max(deviationFactor, curveFactor);
        const targetLookaheadDistance = this.MAX_LOOKAHEAD - (this.MAX_LOOKAHEAD - this.MIN_LOOKAHEAD) * adjustFactor;
        let lerpFactor = targetLookaheadDistance > this.smoothedLookahead ? 0.1 : 0.05;
        lerpFactor = 1 - Math.pow(1 - lerpFactor, timeScale);
        this.smoothedLookahead += (targetLookaheadDistance - this.smoothedLookahead) * lerpFactor;
        return this.smoothedLookahead;
    }

    isPathDropping() {
        if (!this.boxPositions || this.currentPathPosition >= this.boxPositions.length - 2) return false;
        const current = this.getInterpolatedPoint(this.currentPathPosition);
        const lookAhead = this.getInterpolatedPoint(Math.min(this.boxPositions.length - 1, this.currentPathPosition + 2));
        return current.y - lookAhead.y > 0.8;
    }

    updateLookPoint(timeScale = 1) {
        const player = Player.getPlayer();
        if (!player) return;
        const playerEyes = player.getEyePosition();

        const motionY = Player.getMotionY();
        const isFalling = motionY < -0.4;
        const isPathDropping = this.isPathDropping();
        const pathAnchor = this.getInterpolatedPoint(this.currentPathPosition);
        if (!pathAnchor) {
            this.rotationActive = false;
            this.syncRender();
            return;
        }
        const isJumpingHigh = motionY > 0.1 || player.getY() - pathAnchor.y > 2.0;

        let bestT = this.currentPathPosition;
        let minDistanceSq = Infinity;

        const isTeleportResync = this.postTeleportResyncTicks > 0;
        let searchWindow = isFalling ? 4 : isJumpingHigh ? 12 : 8;
        let startIdx = isFalling ? Math.floor(this.currentPathPosition) : Math.max(0, Math.floor(this.currentPathPosition) - 2);
        if (isTeleportResync) {
            searchWindow = Math.max(searchWindow, this.TELEPORT_RESYNC_SEARCH_WINDOW);
            startIdx = Math.max(0, Math.floor(this.currentPathPosition) - 24);
        }

        const endIdx = Math.min(this.boxPositions.length - 2, startIdx + searchWindow);

        for (let i = startIdx; i <= endIdx; i++) {
            const p1 = this.boxPositions[i];
            const p2 = this.boxPositions[i + 1];
            if (!p1 || !p2) continue;

            const segmentProgress =
                isFalling || isJumpingHigh ? this.getClosestPointOnSegmentHorizontal(playerEyes, p1, p2) : this.getClosestPointOnSegment(playerEyes, p1, p2);

            const candidateT = i + segmentProgress;

            if (isFalling && candidateT < this.currentPathPosition) continue;

            const projectedPoint = this.getInterpolatedPoint(candidateT);
            let distSq = isFalling
                ? Math.pow(playerEyes.x() - projectedPoint.x, 2) + Math.pow(playerEyes.z() - projectedPoint.z, 2)
                : this.getDistSq(playerEyes, projectedPoint);

            if (distSq < minDistanceSq) {
                minDistanceSq = distSq;
                bestT = candidateT;
            }
        }

        let effectiveThreshold = isFalling ? 5.0 : isJumpingHigh ? this.PROXIMITY_THRESHOLD * 2 : this.PROXIMITY_THRESHOLD;
        if (isTeleportResync) effectiveThreshold *= 1.8;
        if (minDistanceSq < effectiveThreshold * effectiveThreshold) {
            const maxJump = isTeleportResync ? 14.0 : isFalling ? 0.5 : 2.0;
            this.currentPathPosition = Math.min(this.currentPathPosition + maxJump, bestT);
        }
        if (!isTeleportResync && !isPathDropping) {
            this.applyPredictedPathProgress(player);
        }

        const adaptiveLookahead = this.getAdaptiveLookahead(playerEyes, timeScale);
        let result = this.findVisibleLookahead(playerEyes, adaptiveLookahead);
        const effectiveMin = this.isInRecoveryMode() ? this.RECOVERY_MIN_LOOKAHEAD : this.MIN_LOOKAHEAD;
        let targetVisible = this.isPointVisible(playerEyes, result.point);
        const now = Date.now();

        if (result.lookahead <= effectiveMin + 0.001 && !targetVisible) {
            if (!this.unseenSince) {
                this.unseenSince = now;
                this.unseenStartPathPosition = this.currentPathPosition;
            }
            // Rolling back mid-air puts the look point behind us and turns the camera around.
            if (now - this.unseenSince >= 600 && player.onGround()) {
                let attempts = 0;
                const minRollbackPosition = Math.max(0, this.unseenStartPathPosition - 8);
                while (this.currentPathPosition > minRollbackPosition && attempts < 8) {
                    this.currentPathPosition = Math.max(minRollbackPosition, this.currentPathPosition - 1);
                    const t = Math.min(this.boxPositions.length - 1, this.currentPathPosition + effectiveMin);
                    if (this.isPointVisible(playerEyes, this.getInterpolatedPoint(t))) {
                        this.unseenSince = 0;
                        this.unseenStartPathPosition = this.currentPathPosition;
                        result = this.findVisibleLookahead(playerEyes, adaptiveLookahead);
                        targetVisible = this.isPointVisible(playerEyes, result.point);
                        break;
                    }
                    attempts++;
                }
            }
        } else {
            this.unseenSince = 0;
            this.unseenStartPathPosition = this.currentPathPosition;
        }

        let targetPoint = this.getBlendedEntityLookPoint(result.point, playerEyes, timeScale);
        if (result.lookahead < this.smoothedLookahead) this.smoothedLookahead = this.smoothedLookahead * 0.9 + result.lookahead * 0.1;

        const rawDx = targetPoint.x - playerEyes.x();
        const rawDy = targetPoint.y - playerEyes.y();
        const rawDz = targetPoint.z - playerEyes.z();
        const rawHorz = Math.hypot(rawDx, rawDz);
        const rawPitch = -Math.atan2(rawDy, rawHorz) * (180 / Math.PI);

        if (rawPitch < -50 && rawHorz < 1.0) {
            const newDy = rawHorz * Math.tan(30 * (Math.PI / 180));
            targetPoint = new Vec3d(targetPoint.x, playerEyes.y() + newDy, targetPoint.z);
        }

        // A look point almost straight below us gives an unstable yaw that spins the camera while falling.
        let holdYaw = false;
        if ((!player.onGround() || isFalling || isPathDropping) && rawHorz < this.MIN_HORIZONTAL_LOOK) {
            const farPoint = this.findHorizontallyDistantPoint(playerEyes);
            if (farPoint) targetPoint = farPoint;
            else holdYaw = true;
        }

        const dx = targetPoint.x - playerEyes.x();
        const dy = targetPoint.y - playerEyes.y();
        const dz = targetPoint.z - playerEyes.z();
        const dist = Math.hypot(dx, dy, dz);

        if (dist > this.MAX_LOOK_DISTANCE) {
            const scale = this.MAX_LOOK_DISTANCE / dist;
            targetPoint = new Vec3d(playerEyes.x() + dx * scale, playerEyes.y() + dy * scale, playerEyes.z() + dz * scale);
        }

        this.currentTargetPoint = targetPoint;
        const angles = calculateAbsoluteAngles(this.currentTargetPoint);
        const targetYaw = wrapTo180(angles.yaw);
        const yawDelta = getAngleDifference(this.rawTargetYaw, targetYaw);
        const blockAirTurn = !player.onGround() && Math.abs(yawDelta) > this.MAX_AIR_TURN;

        const lastIndex = this.boxPositions.length - 1;
        const remainingPath = lastIndex - this.currentPathPosition;
        const pathFinishFactor = remainingPath < 3.0 ? Math.max(0.1, remainingPath / 3.0) : 1.0;
        const finishFactor = this.entityBlend > 0 ? Math.max(0.5, pathFinishFactor) : pathFinishFactor;
        const isStraight = this.currentPathCurvature < 0.15;
        const dynamicSmoothBase = (isStraight ? this.SMOOTH_FACTOR * 0.5 : this.SMOOTH_FACTOR) / finishFactor;
        const dynamicSmooth = 1 - Math.pow(1 - Math.min(1.0, dynamicSmoothBase * this.getInitialTurnBoostFactor(yawDelta)), timeScale);
        const dynamicYawDeadzone = (isStraight ? this.YAW_DEADZONE * 1.5 : this.YAW_DEADZONE) * finishFactor;

        if (!holdYaw && !blockAirTurn && Math.abs(yawDelta) > dynamicYawDeadzone) {
            this.rawTargetYaw = wrapTo180(this.rawTargetYaw + yawDelta * Math.min(1.0, dynamicSmooth));
        }

        const pitchDelta = angles.pitch - this.rawTargetPitch;
        if (!holdYaw && Math.abs(pitchDelta) > this.PITCH_DEADZONE * finishFactor) {
            this.rawTargetPitch += pitchDelta * Math.min(1.0, dynamicSmooth);
        }

        if (this.initialTurnBoostTicks > 0) {
            if (Math.abs(getAngleDifference(this.currentYaw, this.rawTargetYaw)) <= Math.max(10.0, this.YAW_DEADZONE * 2)) {
                this.initialTurnBoostTicks = 0;
            } else {
                this.initialTurnBoostTicks -= timeScale;
            }
        }

        const lastPoint = this.boxPositions[lastIndex];
        const endDistSq = Math.pow(playerEyes.x() - lastPoint.x, 2) + Math.pow(playerEyes.y() - lastPoint.y, 2) + Math.pow(playerEyes.z() - lastPoint.z, 2);
        const nearEndBy3D = endDistSq <= Math.pow(this.COMPLETION_RADIUS, 2) && this.currentPathPosition >= lastIndex - 2.0;
        const atEndByPosition = this.currentPathPosition >= lastIndex - 0.25;

        if (nearEndBy3D || atEndByPosition) {
            this.currentPathPosition = lastIndex;
            this.complete = true;
            this.rotationActive = false;
            this.syncRender();
        }
    }

    findHorizontallyDistantPoint(playerEyes) {
        const last = this.boxPositions.length - 1;
        const start = Math.max(this.currentPathPosition, this.projectPathPositionHorizontal(playerEyes.x(), playerEyes.z(), this.currentPathPosition));
        const anchor = this.getInterpolatedPoint(start);
        for (let t = start; t <= Math.min(last, start + 10); t += 0.5) {
            const point = this.getInterpolatedPoint(t);
            const dx = point.x - playerEyes.x();
            const dz = point.z - playerEyes.z();
            if (Math.hypot(dx, dz) < this.MIN_HORIZONTAL_LOOK + 0.3) continue;
            if (dx * (point.x - anchor.x) + dz * (point.z - anchor.z) > 0) return point;
        }
        return null;
    }

    applyHumanizedPhysics(timeScale = 1) {
        this.currentYaw = wrapTo180(this.currentYaw);
        const yawError = getAngleDifference(this.currentYaw, this.rawTargetYaw);
        const pitchError = this.rawTargetPitch - this.currentPitch;
        const absYawError = Math.abs(yawError);
        const isStraight = this.currentPathCurvature < 0.2;
        const initialTurnBoostFactor = this.getInitialTurnBoostFactor(yawError);
        const errorMultiplier = Math.min(1.5, Math.max(0.6, absYawError / 10));
        const dynamicKp = this.BASE_KP * errorMultiplier * initialTurnBoostFactor;
        const dynamicKd = isStraight ? this.KD * 1.3 : this.KD;
        const accelLimit = this.ACCEL_LIMIT * initialTurnBoostFactor;
        const maxVelocity = this.MAX_VELOCITY * initialTurnBoostFactor;

        if (absYawError < this.SETTLE_THRESHOLD && Math.abs(this.yawVelocity) < 0.02) {
            this.currentYaw = this.rawTargetYaw;
            this.yawVelocity = 0;
        } else {
            let desiredYawAccel = (yawError * dynamicKp - this.yawVelocity * dynamicKd) * timeScale;
            desiredYawAccel = Math.max(-accelLimit * timeScale, Math.min(accelLimit * timeScale, desiredYawAccel));
            this.yawVelocity += desiredYawAccel;
            this.yawVelocity *= Math.pow(0.92, timeScale);
            this.yawVelocity = Math.max(-maxVelocity, Math.min(maxVelocity, this.yawVelocity));
            this.currentYaw += this.yawVelocity * timeScale;
        }

        if (Math.abs(pitchError) < this.SETTLE_THRESHOLD && Math.abs(this.pitchVelocity) < 0.02) {
            this.currentPitch = this.rawTargetPitch;
            this.pitchVelocity = 0;
        } else {
            let desiredPitchAccel = (pitchError * dynamicKp - this.pitchVelocity * dynamicKd) * timeScale;
            desiredPitchAccel = Math.max(-accelLimit * timeScale, Math.min(accelLimit * timeScale, desiredPitchAccel));
            this.pitchVelocity += desiredPitchAccel;
            this.pitchVelocity *= Math.pow(0.92, timeScale);
            this.pitchVelocity = Math.max(-maxVelocity, Math.min(maxVelocity, this.pitchVelocity));
            this.currentPitch += this.pitchVelocity * timeScale;
        }
        this.currentPitch = Math.max(-90, Math.min(90, this.currentPitch));
    }

    getClosestPointOnSegment(p, p1, p2) {
        const dx = p2.x - p1.x;
        const dy = p2.y - p1.y;
        const dz = p2.z - p1.z;
        const dSq = dx * dx + dy * dy + dz * dz;
        if (dSq === 0) return 0;
        return Math.max(0, Math.min(1, ((p.x() - p1.x) * dx + (p.y() - p1.y) * dy + (p.z() - p1.z) * dz) / dSq));
    }

    getClosestPointOnSegmentHorizontal(p, p1, p2) {
        const dx = p2.x - p1.x,
            dz = p2.z - p1.z;
        const dSq = dx * dx + dz * dz;
        if (dSq === 0) return 0;
        return Math.max(0, Math.min(1, ((p.x() - p1.x) * dx + (p.z() - p1.z) * dz) / dSq));
    }

    projectPathPositionHorizontal(x, z, hint = 0) {
        if (!this.boxPositions || this.boxPositions.length < 2) return 0;
        const lastSegment = this.boxPositions.length - 2;
        const base = Math.max(0, Math.min(lastSegment, Math.floor(hint)));
        const start = Math.max(0, base - 8);
        const end = Math.min(lastSegment, base + 28);

        let bestT = Math.max(0, Math.min(this.boxPositions.length - 1, hint));
        let bestDistSq = Infinity;

        for (let i = start; i <= end; i++) {
            const a = this.boxPositions[i];
            const b = this.boxPositions[i + 1];
            if (!a || !b) continue;

            const abx = b.x - a.x;
            const abz = b.z - a.z;
            const lenSq = abx * abx + abz * abz;
            const t = lenSq <= 1e-8 ? 0 : Math.max(0, Math.min(1, ((x - a.x) * abx + (z - a.z) * abz) / lenSq));
            const px = a.x + abx * t;
            const pz = a.z + abz * t;
            const dx = x - px;
            const dz = z - pz;
            const distSq = dx * dx + dz * dz;

            if (distSq < bestDistSq) {
                bestDistSq = distSq;
                bestT = i + t;
            }
        }

        return bestT;
    }

    applyPredictedPathProgress(player) {
        if (!this.boxPositions || this.boxPositions.length < 2) return;

        const motionX = Player.getMotionX();
        const motionZ = Player.getMotionZ();
        const speedXZ = Math.hypot(motionX, motionZ);
        const onGround = player.onGround();

        if (onGround && speedXZ < this.PREDICTION_MIN_SPEED_XZ) return;

        const predicted = onGround ? { x: Player.getX(), z: Player.getZ() } : predictXZ(this.PREDICTION_TICKS);
        const projectedPredicted = this.projectPathPositionHorizontal(predicted.x, predicted.z, this.currentPathPosition);
        if (!Number.isFinite(projectedPredicted) || projectedPredicted <= this.currentPathPosition) return;

        const maxAdvance = onGround ? this.PREDICTION_MAX_ADVANCE_GROUND : this.PREDICTION_MAX_ADVANCE_AIR;
        this.currentPathPosition = Math.min(this.currentPathPosition + maxAdvance, projectedPredicted);
    }

    getInterpolatedPoint(indexFloat) {
        if (!this.boxPositions || this.boxPositions.length === 0) return null;
        const safeIndexFloat = Number.isFinite(indexFloat) ? Math.max(0, Math.min(indexFloat, this.boxPositions.length - 1)) : 0;
        const idx = Math.floor(safeIndexFloat),
            frac = safeIndexFloat - idx;
        const p1 = this.boxPositions[idx],
            p2 = this.boxPositions[Math.min(idx + 1, this.boxPositions.length - 1)];
        if (!p1) return null;
        if (!p2 || frac <= 0) return p1;
        return new Vec3d(p1.x + (p2.x - p1.x) * frac, p1.y + (p2.y - p1.y) * frac, p1.z + (p2.z - p1.z) * frac);
    }

    getDistSq(pos, box) {
        return (pos.x() - box.x) ** 2 + (pos.y() - box.y) ** 2 + (pos.z() - box.z) ** 2;
    }

    getEntityLookPoint(playerEyes) {
        if (!this.entityTarget || !this.isNearPathEnd()) return null;

        try {
            const entity = this.entityTarget.toMC ? this.entityTarget.toMC() : this.entityTarget;
            if (!entity || entity.isRemoved?.() || entity.isDeadOrDying?.()) return null;

            const box = entity.getBoundingBox?.();
            if (!box) return null;

            const x = (box.minX + box.maxX) / 2;
            const y = box.minY + (box.maxY - box.minY) * 0.85;
            const z = (box.minZ + box.maxZ) / 2;
            if (Math.hypot(playerEyes.x() - x, playerEyes.y() - y, playerEyes.z() - z) > this.entityTrackDistance) return null;

            const targetPoint = new Vec3d(x, y, z);
            return this.isPointVisible(playerEyes, targetPoint, false) ? targetPoint : null;
        } catch (e) {
            return null;
        }
    }

    isNearPathEnd(maxRemainingNodes = 2) {
        if (!this.boxPositions || !this.boxPositions.length) return false;
        return this.currentPathPosition >= this.boxPositions.length - 1 - maxRemainingNodes;
    }

    getBlendedEntityLookPoint(pathPoint, playerEyes, timeScale) {
        const entityPoint = this.getEntityLookPoint(playerEyes);
        if (entityPoint) this.lastEntityLookPoint = entityPoint;

        const targetBlend = entityPoint ? 1 : 0;
        const blendRate = 1 - Math.pow(1 - this.ENTITY_BLEND_RATE, timeScale);
        this.entityBlend += (targetBlend - this.entityBlend) * blendRate;

        if (!this.lastEntityLookPoint || this.entityBlend < 0.001) {
            if (!entityPoint) this.lastEntityLookPoint = null;
            return pathPoint;
        }

        return new Vec3d(
            pathPoint.x + (this.lastEntityLookPoint.x - pathPoint.x) * this.entityBlend,
            pathPoint.y + (this.lastEntityLookPoint.y - pathPoint.y) * this.entityBlend,
            pathPoint.z + (this.lastEntityLookPoint.z - pathPoint.z) * this.entityBlend
        );
    }

    pathRotations(splineData, entityTarget = null, entityTrackDistance = this.ENTITY_TRACK_DISTANCE) {
        if (this.entityTarget !== entityTarget) {
            this.entityBlend = 0;
            this.lastEntityLookPoint = null;
        }
        this.entityTarget = entityTarget;
        this.entityTrackDistance = Number.isFinite(entityTrackDistance) && entityTrackDistance > 0 ? entityTrackDistance : this.ENTITY_TRACK_DISTANCE;
        if (!this.boxPositions || this.boxPositions.length < 2) {
            const lookPoints = createLookPoints(splineData, 0.25, 4.5);
            if (!lookPoints || lookPoints.length < 2) {
                this.boxPositions = null;
                this.rotationActive = false;
                this.syncRender();
                return;
            }
            this.boxPositions = lookPoints;
        }
        const player = Player.getPlayer();
        if (player && !this.isInitialized) {
            this.currentYaw = wrapTo180(player.getYRot());
            this.currentPitch = player.getXRot();
            this.rawTargetYaw = this.currentYaw;
            this.rawTargetPitch = this.currentPitch;
            this.yawVelocity = 0;
            this.pitchVelocity = 0;
            this.currentPathPosition = 0;
            this.isInitialized = true;
            this.rotationActive = true;
            this.syncRender();
            this.initialTurnBoostTicks = 10;
        }
    }
}

export const Rotations = new PathRotations();

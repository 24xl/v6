import { chatPathfinder } from '../../Chat';
import { BP, SnowBlock, Vec3d } from '../../Constants';
import PathConfig from '../PathConfig';
import { onPathTick } from '../PathExecutor';
import { isRecovering } from './PathMovement';

const GRAVITY = 0.08;
const AIR_DRAG = 0.98;
const AIR_FRICTION = 0.91;
const SPRINT_JUMP_BOOST = 0.2;
const MAX_SIM_TICKS = 40;

let MobEffects = null;
let Attributes = null;
try {
    MobEffects = Java.type('net.minecraft.world.effect.MobEffects');
    Attributes = Java.type('net.minecraft.world.entity.ai.attributes.Attributes');
} catch (e) {
    console.error('PathJumps: could not load effect/attribute classes, assuming vanilla jump', e);
}

class PathJumps {
    constructor() {
        this.lastLookaheadPositions = [];
        this.currentLookaheadVecs = [];
        this.blockCache = new Map();
        this.cacheFrame = 0;
        this.lastFluidMessage = 0;
        this.jumpSuppressTicks = 0;
        this.lastNearestPath = null;
        this.lastNearestIndex = -1;

        this.STEP_HEIGHT = 0.6;
        this.LOOKAHEAD_NODES = 5;
        this.NEAREST_SEARCH_WINDOW = 16;
        this.MIN_JUMP_TRIGGER = 0.2;
        this.JUMP_EARLY_MARGIN = 0.15;
        this.LANDING_MARGIN = 0.4;

        this.FLAG_FLUID_FEET = 1 << 0;
        this.FLAG_FLUID_HEAD = 1 << 1;
        this.FLAG_LOW_HEADROOM = 1 << 2;
        this.FLAG_NEAR_EDGE = 1 << 3;
        this.FLAG_NEAR_WALL = 1 << 4;
        this.FLAG_STEP_UP_NEXT = 1 << 5;
        this.FLAG_DROP_NEXT = 1 << 6;
        this.FLAG_TIGHT_CORRIDOR = 1 << 7;

        onPathTick(() => {
            this.cacheFrame++;
            if (this.blockCache.size > 1000) this.blockCache.clear();
            if (this.jumpSuppressTicks > 0) {
                this.jumpSuppressTicks--;
                Client.setKey('space', false);
            }
        });
    }

    getCachedBlock(x, y, z) {
        const bx = Math.floor(x);
        const by = Math.floor(y);
        const bz = Math.floor(z);
        const key = `${bx},${by},${bz},${this.cacheFrame}`;
        if (!World.getWorld()) return null;

        if (!this.blockCache.has(key)) {
            this.blockCache.set(key, World.getBlockAt(bx, by, bz));
        }

        return this.blockCache.get(key);
    }

    getBlockName(block) {
        try {
            return block?.type?.getRegistryName?.()?.toLowerCase?.() || '';
        } catch (e) {
            return '';
        }
    }

    isBlockNonCollidable(world, blockVec) {
        const blockPosNMS = new BP(Math.floor(blockVec.x()), Math.floor(blockVec.y()), Math.floor(blockVec.z()));
        const blockState = world.getBlockState(blockPosNMS);
        if (!blockState) return false;
        return blockState.getCollisionShape(world, blockPosNMS).isEmpty();
    }

    isBlockSolid(x, y, z) {
        const block = this.getCachedBlock(x, y, z);
        if (!block || block.type.getID() === 0) return false;
        const world = World.getWorld();
        if (!world) return false;
        const blockPosNMS = new BP(Math.floor(x), Math.floor(y), Math.floor(z));
        const blockState = world.getBlockState(blockPosNMS);
        if (!blockState) return false;
        return !blockState.getCollisionShape(world, blockPosNMS).isEmpty();
    }

    hasLowCeiling(x, y, z) {
        const world = World.getWorld();
        if (!world) return false;
        for (let offset = 2; offset <= 3; offset++) {
            const block = this.getCachedBlock(x, y + offset, z);
            if (!block || block.type.getID() === 0) continue;
            if (this.getBlockName(block).includes('stair')) continue;
            const blockPosNMS = new BP(Math.floor(x), Math.floor(y + offset), Math.floor(z));
            const blockState = world.getBlockState(blockPosNMS);
            if (!blockState) continue;
            if (!blockState.getCollisionShape(world, blockPosNMS).isEmpty()) return true;
        }
        return false;
    }

    isPlayerInFluid() {
        const playerMP = Player.asPlayerMP();
        if (!playerMP) return false;
        if (playerMP.isInLava() || playerMP.isInWater()) return true;
        const block = this.getCachedBlock(Player.getX(), Player.getY(), Player.getZ());
        const name = this.getBlockName(block);
        if (name) return name.includes('water') || name.includes('lava');
        return false;
    }

    canWalkUpStairs(playerX, playerY, playerZ, blockX, blockY, blockZ) {
        const world = World.getWorld();
        if (!world) return false;
        const blockPosNMS = new BP(Math.floor(blockX), Math.floor(blockY), Math.floor(blockZ));
        const blockState = world.getBlockState(blockPosNMS);
        if (!blockState) return true;
        try {
            const stateString = blockState.toString();
            const facingMatch = stateString.match(/facing=(\w+)/);
            if (!facingMatch) return true;
            const facingDir = facingMatch[1].toLowerCase();
            const dx = blockX + 0.5 - playerX;
            const dz = blockZ + 0.5 - playerZ;
            let approach;
            if (Math.abs(dx) > Math.abs(dz)) {
                approach = dx > 0 ? 'west' : 'east';
            } else {
                approach = dz > 0 ? 'north' : 'south';
            }
            const walkable = { north: 'south', south: 'north', east: 'west', west: 'east' }[facingDir];
            return approach === walkable;
        } catch (e) {
            return true;
        }
    }

    getSnowLayers(block) {
        if (this.getBlockName(block) !== 'minecraft:snow') return 0;
        try {
            return block.getState().getValue(SnowBlock.LAYERS);
        } catch (e) {
            return 0;
        }
    }

    drawPathAndPlayerLookAhead(path) {
        if (!Player.getPlayer() || !path || path.length === 0) return { lookahead: [], closestIndex: -1 };

        const pX = Player.getX(),
            pY = Player.getY(),
            pZ = Player.getZ();
        let closestIndex = -1,
            minDSq = Infinity;

        const useLocalWindow = path === this.lastNearestPath && this.lastNearestIndex >= 0 && this.lastNearestIndex < path.length;
        const start = useLocalWindow ? Math.max(0, this.lastNearestIndex - this.NEAREST_SEARCH_WINDOW) : 0;
        const searchEnd = useLocalWindow ? Math.min(path.length, this.lastNearestIndex + this.NEAREST_SEARCH_WINDOW + 1) : path.length;

        for (let index = start; index < searchEnd; index++) {
            const node = path[index];
            const dSq = Math.pow(pX - (node.x + 0.5), 2) + Math.pow(pY - (node.y + 0.5), 2) + Math.pow(pZ - (node.z + 0.5), 2);
            if (dSq < minDSq) {
                minDSq = dSq;
                closestIndex = index;
            }
        }

        if (closestIndex === -1) return { lookahead: [], closestIndex: -1 };
        this.lastNearestPath = path;
        this.lastNearestIndex = closestIndex;

        const lookahead = [];
        const end = Math.min(closestIndex + 1 + this.LOOKAHEAD_NODES, path.length);
        const world = World.getWorld();
        if (!world) return { lookahead: [], closestIndex: -1 };

        for (let i = closestIndex + 1; i < end; i++) {
            const node = path[i];
            const floorY = Math.round(node.y);
            const blockVec = new Vec3d(Math.floor(node.x), floorY, Math.floor(node.z));
            const block = this.getCachedBlock(node.x, floorY, node.z);

            const isSolid = !this.isBlockNonCollidable(world, blockVec);

            if (isSolid) {
                const name = this.getBlockName(block) || 'minecraft:air';
                lookahead.push({ vec: blockVec, name, block });
            }
        }

        return { lookahead, closestIndex };
    }
    checkFluidJump() {
        if (!this.isPlayerInFluid()) return false;
        Client.setKey('space', true);
        if (Date.now() - this.lastFluidMessage > 2000) {
            if (PathConfig.PATHFINDING_DEBUG) chatPathfinder('Fluid jump detected');
            this.lastFluidMessage = Date.now();
        }
        return true;
    }

    checkSnowJump(lookahead) {
        if (lookahead.length < 1) return false;
        const data = lookahead[0];
        if (this.getBlockName(data.block) !== 'minecraft:snow') return false;
        const layers = this.getSnowLayers(data.block);
        if (layers === 0) return false;
        const diff = data.vec.y() - (8 - layers) * 0.125 - (Player.getY() - 1);
        if (diff > 0.75 && layers > 6) {
            if (PathConfig.PATHFINDING_DEBUG) chatPathfinder('Snow jump detected');
            Client.setKey('space', true);
            return true;
        }
        return false;
    }

    getEdgeDistance(blockX, blockZ) {
        const half = 0.3;
        const pX = Player.getX();
        const pZ = Player.getZ();
        const bx = Math.floor(blockX);
        const bz = Math.floor(blockZ);
        const dx = Math.max(bx - (pX + half), 0, pX - half - (bx + 1));
        const dz = Math.max(bz - (pZ + half), 0, pZ - half - (bz + 1));
        return Math.hypot(dx, dz);
    }

    getJumpVelocity(player) {
        let velocity = 0.42;
        try {
            const strength = Attributes ? player.getAttributeValue(Attributes.JUMP_STRENGTH) : NaN;
            if (Number.isFinite(strength) && strength > 0) velocity = strength;
        } catch (e) {}
        try {
            const effect = MobEffects ? player.getEffect(MobEffects.JUMP_BOOST) : null;
            if (effect) velocity += 0.1 * (effect.getAmplifier() + 1);
        } catch (e) {}
        return velocity;
    }

    // Unaffected by the Speed stat.
    getAirAcceleration(sprinting) {
        return sprinting ? 0.026 : 0.02;
    }

    // Horizontal distances between which a jump started now keeps our feet above `rise`; null if it can't.
    simulateJumpWindow(rise) {
        const player = Player.getPlayer();
        if (!player) return null;

        const sprinting = player.isSprinting();
        const groundSpeed = Math.hypot(Player.getMotionX(), Player.getMotionZ());
        const airAccel = this.getAirAcceleration(sprinting);

        // One ground tick passes before the jump key is processed.
        let distance = groundSpeed;
        let y = 0;
        let vy = this.getJumpVelocity(player);
        let vh = groundSpeed + (sprinting ? SPRINT_JUMP_BOOST : 0);
        let enter = null;

        for (let tick = 0; tick < MAX_SIM_TICKS; tick++) {
            y += vy;
            distance += vh;
            vy = (vy - GRAVITY) * AIR_DRAG;
            vh = vh * AIR_FRICTION + airAccel;

            if (enter === null && y >= rise) enter = distance;
            if (enter !== null && (y < rise || vy < 0 && y + vy < rise)) return { enter, exit: distance };
            if (enter === null && vy < 0) return null;
        }
        return enter === null ? null : { enter, exit: distance };
    }

    getBlockTop(x, y, z) {
        try {
            const world = World.getWorld();
            const pos = new BP(Math.floor(x), Math.floor(y), Math.floor(z));
            const shape = world.getBlockState(pos).getCollisionShape(world, pos);
            if (!shape.isEmpty()) return Math.floor(y) + shape.bounds().maxY;
        } catch (e) {}
        return Math.floor(y) + 1;
    }

    isHeadingToward(blockX, blockZ) {
        const dx = Math.floor(blockX) + 0.5 - Player.getX();
        const dz = Math.floor(blockZ) + 0.5 - Player.getZ();
        const len = Math.hypot(dx, dz);
        if (len < 0.5) return true;
        const yaw = (Player.getYaw() * Math.PI) / 180;
        return (-Math.sin(yaw) * dx + Math.cos(yaw) * dz) / len > 0.3;
    }

    isJumpTimed(blockX, blockY, blockZ) {
        if (!this.isHeadingToward(blockX, blockZ)) return false;
        const rise = this.getBlockTop(blockX, blockY, blockZ) - Player.getY();
        if (rise <= this.STEP_HEIGHT) return false;

        const window = this.simulateJumpWindow(rise);
        if (!window) return this.getEdgeDistance(blockX, blockZ) <= this.MIN_JUMP_TRIGGER;

        const edge = this.getEdgeDistance(blockX, blockZ);
        const latest = Math.min(window.enter + this.JUMP_EARLY_MARGIN, window.exit - this.LANDING_MARGIN);
        return edge <= Math.max(this.MIN_JUMP_TRIGGER, latest);
    }

    checkObstacleJump(lookahead) {
        if (lookahead.length === 0) return false;
        const pX = Player.getX(),
            pY = Player.getY(),
            pZ = Player.getZ();
        const playerFloorY = Math.floor(pY - 0.001);
        const currentFeetBlock = this.getCachedBlock(pX, playerFloorY, pZ);
        const currentName = this.getBlockName(currentFeetBlock);
        const standingOnPartial = currentName.includes('stair') || currentName.includes('slab');
        const stairClimbLimit = standingOnPartial ? 1.05 : this.STEP_HEIGHT;
        let needsJump = false;
        let canWalkInstead = false;
        for (const data of lookahead) {
            if (this.getBlockName(data.block).includes('snow')) continue;
            const heightDifference = data.vec.y() - playerFloorY;
            if (heightDifference <= stairClimbLimit) continue;
            if (!this.isJumpTimed(data.vec.x(), data.vec.y(), data.vec.z())) continue;
            needsJump = true;
            if (data.name.includes('slab')) {
                canWalkInstead = true;
            } else if (data.name.includes('stair')) {
                if (this.canWalkUpStairs(pX, pY, pZ, data.vec.x(), data.vec.y(), data.vec.z())) canWalkInstead = true;
            }
        }
        if (needsJump && !canWalkInstead) {
            if (PathConfig.PATHFINDING_DEBUG) chatPathfinder('Standard jump detected');
            Client.setKey('space', true);
            return true;
        }
        return false;
    }

    checkPreemptiveClimbJump(path, closestIndex) {
        if (!Array.isArray(path) || closestIndex < 0) return false;
        if (closestIndex + 1 >= path.length) return false;

        const currentNode = path[closestIndex];
        const nextNode = path[closestIndex + 1];
        if (!currentNode || !nextNode) return false;

        const currentY = Math.round(currentNode.y);
        const nextY = Math.round(nextNode.y);
        if (nextY <= currentY) return false;

        if (!this.isJumpTimed(nextNode.x, nextY, nextNode.z)) return false;

        const rise = nextY - Math.floor(Player.getY() - 0.001);
        if (rise < 1) return false;

        if (PathConfig.PATHFINDING_DEBUG) chatPathfinder('Predictive climb jump');
        Client.setKey('space', true);
        return true;
    }

    checkGapJump(path, closestIndex) {
        if (closestIndex === -1 || path.length < closestIndex + 3) return false;

        const pY = Player.getY();
        let baseY = Math.round(path[closestIndex].y);

        if (Math.abs(pY - (baseY + 1)) > 1.8) return false;

        let dropIndex = -1;
        let recoveryIndex = -1;

        const maxLook = Math.min(path.length, closestIndex + 7);

        for (let i = closestIndex + 1; i < maxLook; i++) {
            let y = Math.round(path[i].y);
            if (y < baseY) {
                if (dropIndex === -1) dropIndex = i;
            } else if (dropIndex !== -1 && y >= baseY) {
                recoveryIndex = i;
                break;
            } else if (y > baseY && dropIndex === -1) {
                return false;
            }
        }

        if (dropIndex !== -1 && recoveryIndex !== -1) {
            const dropStartNode = path[dropIndex - 1];
            const recoveryNode = path[recoveryIndex];

            const gapHorizDistSq = Math.pow(recoveryNode.x - dropStartNode.x, 2) + Math.pow(recoveryNode.z - dropStartNode.z, 2);

            if (gapHorizDistSq > 0 && gapHorizDistSq <= 20) {
                const pX = Player.getX();
                const pZ = Player.getZ();

                const distToEdgeSq = Math.pow(pX - (dropStartNode.x + 0.5), 2) + Math.pow(pZ - (dropStartNode.z + 0.5), 2);

                if (distToEdgeSq <= 1.35 * 1.35) {
                    if (PathConfig.PATHFINDING_DEBUG) chatPathfinder('Gap jump detected');
                    Client.setKey('space', true);
                    return true;
                }
            }
        }
        return false;
    }

    applyFlagBits(flagBits) {
        if (!Array.isArray(flagBits) || flagBits.length < 8) return;
        this.FLAG_FLUID_FEET = flagBits[0] || this.FLAG_FLUID_FEET;
        this.FLAG_FLUID_HEAD = flagBits[1] || this.FLAG_FLUID_HEAD;
        this.FLAG_LOW_HEADROOM = flagBits[2] || this.FLAG_LOW_HEADROOM;
        this.FLAG_NEAR_EDGE = flagBits[3] || this.FLAG_NEAR_EDGE;
        this.FLAG_NEAR_WALL = flagBits[4] || this.FLAG_NEAR_WALL;
        this.FLAG_STEP_UP_NEXT = flagBits[5] || this.FLAG_STEP_UP_NEXT;
        this.FLAG_DROP_NEXT = flagBits[6] || this.FLAG_DROP_NEXT;
        this.FLAG_TIGHT_CORRIDOR = flagBits[7] || this.FLAG_TIGHT_CORRIDOR;
    }

    detectJump(path, pathFlags = null, pathFlagBits = null) {
        if (!Player.getPlayer()) return this.reset();
        this.applyFlagBits(pathFlagBits);
        if (this.jumpSuppressTicks > 0) {
            Client.setKey('space', false);
            return;
        }
        const { lookahead, closestIndex } = this.drawPathAndPlayerLookAhead(path);

        this.currentLookaheadVecs = lookahead;

        if (closestIndex === -1) return this.reset();
        const nextFlags = Array.isArray(pathFlags) ? pathFlags[Math.min(pathFlags.length - 1, Math.max(0, closestIndex + 1))] || 0 : 0;

        if (nextFlags & this.FLAG_LOW_HEADROOM) {
            this.suppressJump(4);
            Client.setKey('space', false);
            return;
        }

        if (this.checkFluidJump()) return;

        const player = Player.getPlayer();
        if (!player) return this.reset();

        if (!player.onGround()) {
            if (!isRecovering() && !this.isPlayerInFluid()) {
                Client.setKey('space', false);
            }
            return;
        }

        if (this.hasLowCeiling(Math.floor(Player.getX()), Math.floor(Player.getY() - 0.001), Math.floor(Player.getZ()))) {
            this.reset();
            return;
        }

        if (nextFlags & this.FLAG_STEP_UP_NEXT && this.checkPreemptiveClimbJump(path, closestIndex)) return;

        if (this.checkGapJump(path, closestIndex)) return;

        if (this.checkSnowJump(lookahead)) return;
        if (this.checkObstacleJump(lookahead)) return;

        if (!isRecovering()) {
            Client.setKey('space', false);
        }
        this.lastLookaheadPositions = lookahead.map((d) => d.vec.y());
    }

    reset() {
        this.lastLookaheadPositions = [];
        this.currentLookaheadVecs = [];
        this.jumpSuppressTicks = 0;
        this.invalidateNearestIndex();
        this.blockCache.clear();
        this.cacheFrame = 0;
        Client.setKey('space', false);
    }

    invalidateNearestIndex() {
        this.lastNearestPath = null;
        this.lastNearestIndex = -1;
    }

    suppressJump(ticks = 5) {
        this.jumpSuppressTicks = Math.max(this.jumpSuppressTicks, Math.max(0, Math.floor(ticks)));
    }
}

export const Jump = new PathJumps();

import { showNotification } from '../../gui/NotificationManager';
import { chatPathfinder } from '../Chat';
import { BP, Vec3d } from '../Constants';
import { ScheduleTask } from '../ScheduleTask';
import { getDistanceToPlayer } from '../Math';
import { area } from '../Utils';
import { v5Command } from '../V5Commands';
import PathConfig from './PathConfig';
import { destroyPathExecutor, startPathExecutor } from './PathExecutor';
import { PathFlyer } from './PathFlyer';
import { clearSplineCache, drawFloatingSpline, drawLookPoints, generateSpline } from './PathSpline';
import { Jump } from './PathWalker/PathJumps';
import { Aote } from './PathWalker/PathAote';
import { backup, beginMovement, forceJump, stopMovement } from './PathWalker/PathMovement';
import { NonChangeRecovery, Recovery } from './PathWalker/PathRecovery';
import { Rotations } from './PathWalker/PathRotations';
import { Swift } from './SwiftIntegration';

class Finder {
    constructor() {
        this.tick = null;
        this.render = null;
        this.saidInfo = false;
        this.calledFromFile = false;

        this.currentEnd = null;
        this.currentCallback = null;
        this.walkArrivalRadius = 2;
        this.entityTarget = null;
        this.entityTargetResolver = null;
        this.entityGoalOffsets = null;
        this.entityTrackDistance = 8;
        this.silent = false;
        this.recalculateAttempts = 0;
        this.recalculateRetryQueued = false;
        this.MAX_RECALCULATE_ATTEMPTS = 9;
        this.recalculateScheduleId = 0;
        this.searchStartedAt = 0;
        this.SEARCH_TIMEOUT_MS = 25000;
        this.pathVariantSeed = 0;
        this.lastPathSignature = '';
        this.samePathSignatureCount = 0;

        this.currentStarts = null;
        this.startCandidates = [];
        this.selectedStartCandidate = null;
        this.warpCommandIssued = false;
        this.warpRetryCount = 0;
        this.warpLastAttemptAt = 0;
        this.hasReachedWarpPoint = false;
        this.WARP_RETRY_TIMEOUT_MS = 7000;
        this.MAX_WARP_RETRIES = 3;

        this.flyStarted = false;
        this.flyStartDelayTicks = 0;
        this.flySplinePath = null;
        this.cachedPathResult = null;
        this.cachedWalkSplinePath = null;
        this.cachedWalkSplineResult = null;

        v5Command(
            'path goto',
            (...args) => {
                const end = this.parseGoalCoordinates(args, 'Usage: /v5 path goto <x> <y> <z> [x2 y2 z2...]');
                if (!end) return;

                this.resetPath();
                this.calledFromFile = true;
                this.findPath(end);
            },
            ['greedyString']
        );

        v5Command(
            'path fly',
            (...args) => {
                const end = this.parseGoalCoordinates(args, 'Usage: /v5 path fly <x> <y> <z> [x2 y2 z2...]', true);
                if (!end) return;

                this.resetPath();
                this.calledFromFile = true;
                this.findPath(end, null, true);
            },
            ['greedyString']
        );

        v5Command('path stop', () => {
            this.resetPath();
        });
    }

    parseGoalCoordinates(args, usageText, isFly = false) {
        if (args.length < 3 || args.length % 3 !== 0) {
            chatPathfinder(usageText);
            return null;
        }

        const coords = args.map(Number);
        if (coords.some((value) => !Number.isFinite(value))) {
            showNotification('Invalid Coordinates', 'All coordinates must be valid numbers.', 'ERROR', 5000);
            return null;
        }

        const goals = [];
        for (let i = 0; i < coords.length; i += 3) {
            const point = isFly ? this.resolveFlyPoint(coords[i], coords[i + 1], coords[i + 2]) : this.resolveWalkPoint(coords[i], coords[i + 1], coords[i + 2]);
            if (!point) {
                showNotification('Invalid Fly Goal', `No valid fly position near ${coords[i]}, ${coords[i + 1]}, ${coords[i + 2]}.`, 'ERROR', 5000);
                return null;
            }
            goals.push(point);
        }

        return goals;
    }

    findPath(end, onComplete, isFly = false, startPoints = null, preserveRecalculateAttempts = false, walkArrivalRadius = 2) {
        const options = typeof isFly === 'object' && isFly !== null ? isFly : null;
        if (options) {
            isFly = options.isFly === true;
            startPoints = options.startPoints || null;
            preserveRecalculateAttempts = options.preserveRecalculateAttempts === true;
            walkArrivalRadius = options.walkArrivalRadius ?? 2;
        }

        // Resolve walk goals to the block stood on. F3/feet coords are one higher (air),
        // which the native pathfinder can never stand on (PR #123 covered the /v5 path
        // command only; direct findPath callers were still broken).
        if (!isFly && Array.isArray(end)) {
            end = end.map((point) =>
                Array.isArray(point) && point.length >= 3 && point.every((value) => Number.isFinite(value))
                    ? this.resolveWalkPoint(point[0], point[1], point[2])
                    : point
            );
        }

        this.recalculateScheduleId++;
        this.currentEnd = end;
        this.currentStarts = startPoints;
        this.currentCallback = onComplete;
        this.isFly = isFly;
        this.walkArrivalRadius = Number.isFinite(walkArrivalRadius) && walkArrivalRadius > 0 ? walkArrivalRadius : 2;
        if (!preserveRecalculateAttempts) {
            this.entityTarget = options?.entityTarget || null;
            this.entityTargetResolver = options && typeof options.resolveEntityTarget === 'function' ? options.resolveEntityTarget : null;
            this.entityGoalOffsets = this.createEntityGoalOffsets(end, this.entityTarget);
            this.entityTrackDistance = Number.isFinite(options?.entityTrackDistance) && options.entityTrackDistance > 0 ? options.entityTrackDistance : 8;
            this.silent = options?.silent === true;
            this.addAvoidPoints(options?.avoidPoints, options?.avoidRadius);
        }
        this.clearPathCaches();

        const { points: starts, metadata: startMetadata } = this.createStartPoints(startPoints);
        if (!starts?.length) {
            if (!this.silent) showNotification('Pathfinding Failed', 'No valid start points were provided.', 'ERROR', 5000);
            this.callCallback(false);
            return;
        }

        this.startCandidates = startMetadata;
        this.selectedStartCandidate = null;
        this.warpCommandIssued = false;
        this.warpRetryCount = 0;
        this.warpLastAttemptAt = 0;
        this.hasReachedWarpPoint = false;
        if (!preserveRecalculateAttempts) {
            this.recalculateAttempts = 0;
            this.pathVariantSeed = 0;
            this.lastPathSignature = '';
            this.samePathSignatureCount = 0;
        }

        const start = starts[0];

        if (this.calledFromFile) {
            const endStr = end.length > 1 ? `Multiple Goals (${end.length})` : `${end[0][0]}, ${end[0][1]}, ${end[0][2]}`;
            chatPathfinder(`Path from &a${start[0]}, ${start[1]}, ${start[2]}&f to &c${endStr}`);
        }

        if (!Swift.SwiftPath(starts, end, isFly, this.pathVariantSeed, PathConfig.PATHFINDER_MAX_COMPUTE)) {
            if (!this.silent) showNotification('Pathfinding Failed', Swift.getLastError() || 'Failed to start', 'ERROR', 5000);
            this.callCallback(false);
            return;
        }
        this.searchStartedAt = Date.now();

        if (this.calledFromFile && PathConfig.PATHFINDING_DEBUG) {
            chatPathfinder('§eSearching for path...');
        }

        this.startTick();
    }

    startTick() {
        if (this.tick) return;

        startPathExecutor();

        this.tick = register('tick', () => {
            if (Swift.isSearching()) {
                if (this.searchStartedAt > 0 && Date.now() - this.searchStartedAt > this.SEARCH_TIMEOUT_MS) {
                    if (PathConfig.PATHFINDING_DEBUG) {
                        chatPathfinder('§6Path search timed out, recalculating');
                    }
                    Swift.cancel();
                    Swift.clear();
                    this.recalculate('search_timeout');
                }
                return;
            }

            let result = this.cachedPathResult;
            if (!result) {
                result = Swift.getResult();
                if (result) {
                    this.cachedPathResult = result;
                }
            }

            if (result && this.entityTargetResolver && !this.resolveEntityTarget(result)) {
                this.callCallback(false);
                this.resetPath();
                return;
            }

            if (!result || !result.keynodes?.length) {
                if (!this.entityTargetResolver && this.checkIfReachedDestination()) {
                    this.finishSuccess();
                } else {
                    if (this.recalculateAttempts > 0 && !this.recalculateRetryQueued) {
                        this.recalculateRetryQueued = true;
                        this.retryRecalculate();
                        return;
                    }

                    const reason = Swift.getLastError();
                    if (!this.silent) {
                        chatPathfinder(
                            reason === 'End goal is in an unloaded chunk'
                                ? '§cNo path found: End goal is in an unloaded chunk. Load the chunks by going to the destination and try again.'
                                : '§cNo path found' + (reason ? ': ' + reason : '')
                        );
                    }

                    this.callCallback(false);
                    this.resetPath();
                }
                return;
            }

            if (!this.saidInfo && this.calledFromFile && PathConfig.PATHFINDING_DEBUG) {
                const nodeCount = Array.isArray(result.path) ? result.path.length : result.keynodes.length;
                chatPathfinder(`Path found: ${nodeCount} nodes in ${result.time_ms}ms`);
                const nsPerNode = Number(result.nanoseconds_per_node);
                if (Number.isFinite(nsPerNode) && nsPerNode > 0) {
                    chatPathfinder(`Nanoseconds per node: ${Math.round(nsPerNode)}ns`);
                }
                this.saidInfo = true;
            }
            this.updatePathSignatureState(result);

            if (!this.handleStartPointWarp(result)) return;

            if (!this.isFly) {
                const splinePath = this.getCachedWalkSplinePath(result);

                if (PathConfig.RENDER_KEY_NODES || PathConfig.RENDER_FLOATING_SPLINE || PathConfig.RENDER_LOOK_POINTS) {
                    this.startRender(result, splinePath);
                }

                if (this.checkIfReachedDestination()) {
                    this.finishSuccess();
                    return;
                }

                if (!splinePath?.length) return;

                if (Rotations.boxPositions && Rotations.boxPositions.length && Rotations.complete) {
                    this.checkIfReachedDestination() ? this.finishSuccess() : this.recalculate('rotation_complete_not_at_goal');
                    return;
                }

                Rotations.pathRotations(splinePath, this.entityTarget, this.entityTrackDistance);
                this.applyPathRuntimeHints(result);
                Aote.onPathTick(Rotations);
                Jump.detectJump(result.path_between_key_nodes, result.path_flags, result.path_flag_bits);
                beginMovement();

                if (this.recalculateAttempts > 0 && Recovery.hasMadeProgress()) {
                    if (PathConfig.PATHFINDING_DEBUG) {
                        chatPathfinder('§aUnstuck!');
                    }
                    this.recalculateAttempts = 0;
                    Recovery.stop();
                }

                const recoveryAction = Recovery.trackProgress();
                if (recoveryAction) {
                    this.handleRecovery(recoveryAction);
                    if (recoveryAction === 'BACKUP_RECALC') {
                        return;
                    }
                }

                if (!Recovery.isStallRecoveryActive() && NonChangeRecovery.trackProgress(Rotations.currentPathPosition)) {
                    this.recalculate('nonchange_progress');
                    return;
                }
            } else {
                if (!this.flyStarted) {
                    const flyNodes = result.keynodes?.length ? result.keynodes : result.path?.length ? result.path : result.path_between_key_nodes;
                    this.flySplinePath = this.createSplinePath(result);

                    PathFlyer.begin(flyNodes);

                    this.flyStarted = true;
                    this.flyStartDelayTicks = 2;
                }

                if (this.flyStartDelayTicks > 0) {
                    this.flyStartDelayTicks--;
                }

                if (this.flyStarted && this.flyStartDelayTicks === 0) {
                    Aote.onPathTick(PathFlyer, true);

                    if (this.checkIfReachedDestination()) {
                        this.finishSuccess();
                        return;
                    }

                    if (PathFlyer.isActive === false) {
                        if (PathFlyer.complete || this.checkIfReachedDestination()) {
                            this.finishSuccess();
                            return;
                        }

                        this.recalculate('fly_stalled');
                        return;
                    }
                }

                if (this.render) return;

                const shouldRenderFly = PathConfig.RENDER_KEY_NODES || PathConfig.RENDER_FLOATING_SPLINE || PathConfig.RENDER_LOOK_POINTS;
                if (!shouldRenderFly) return;

                this.render = register('postRenderWorld', () => {
                    if (PathConfig.RENDER_KEY_NODES && result.keynodes?.length >= 2) {
                        Render3D.drawStyledBoxes(
                            result.keynodes.map((node) => new Vec3d(node.x, node.y, node.z)),
                            new RenderColor(0, 100, 200, 120),
                            new RenderColor(0, 100, 200, 255),
                            4,
                            true
                        );
                    }

                    if (PathConfig.RENDER_FLOATING_SPLINE) {
                        drawFloatingSpline(this.flySplinePath);
                    }

                    if (PathConfig.RENDER_LOOK_POINTS) {
                        Render3D.drawFilledBoxes(
                            (PathFlyer.path || []).map((p) => new Vec3d(p.x, p.y, p.z)),
                            new RenderColor(0, 255, 0, 150),
                            true
                        );
                    }
                });
            }
        });
    }

    handleRecovery(action) {
        if (!action) return;
        Jump.invalidateNearestIndex();

        switch (action) {
            case 'JUMP':
                forceJump(4);
                break;
            case 'WALL':
                Rotations.setTemporaryLookahead(Math.max(Rotations.RECOVERY_MIN_LOOKAHEAD, 0.35), 12);
                break;
            case 'CLOSE_LOOK':
                Rotations.setTemporaryLookahead(Rotations.RECOVERY_MIN_LOOKAHEAD, 40);
                //forceJump(4);
                break;
            case 'BACKUP_RECALC':
                this.addTransientAvoidAtPlayer(2, 42, 2);
                backup(15, () => this.recalculate('backup_recalc'));
                break;
        }
    }

    recalculate(reason = 'generic') {
        if (!this.isFly) {
            const intensity = this.samePathSignatureCount >= 2 ? 2 : 1;
            this.pathVariantSeed += intensity;
            this.addTransientAvoidAtPlayer(2 + Math.min(1, intensity), 34 + intensity * 8, 2);
        }

        this.recalculateAttempts++;
        this.pathVariantSeed = Math.max(this.pathVariantSeed, this.recalculateAttempts);
        this.recalculateRetryQueued = false;

        if (this.recalculateAttempts > this.MAX_RECALCULATE_ATTEMPTS) {
            if (PathConfig.PATHFINDING_DEBUG) {
                chatPathfinder('§cMax recalculation attempts, failed!');
            }
            this.callCallback(false);
            this.resetPath();
            return;
        }

        if (PathConfig.PATHFINDING_DEBUG) {
            chatPathfinder(`§eRecalculating (${this.recalculateAttempts}/${this.MAX_RECALCULATE_ATTEMPTS})`);
        }

        this.schedulePathRetry(3);
    }

    updatePathSignatureState(result) {
        const signature = typeof result?.path_signature === 'string' ? result.path_signature : '';
        if (!signature) {
            this.lastPathSignature = '';
            this.samePathSignatureCount = 0;
            return;
        }

        if (signature === this.lastPathSignature) {
            this.samePathSignatureCount++;
        } else {
            this.lastPathSignature = signature;
            this.samePathSignatureCount = 0;
        }

        if (this.samePathSignatureCount >= 2 && this.recalculateAttempts > 0) {
            this.pathVariantSeed += 1;
            this.addTransientAvoidAtPlayer(3, 48, 2);
        }
    }

    addTransientAvoidAtPlayer(radius = 2, penalty = 36, ttlSearches = 2) {
        if (this.isFly) return;
        const player = Player.getPlayer();
        if (!player) return;

        const x = Math.floor(Player.getX());
        const y = Math.floor(Player.getY());
        const z = Math.floor(Player.getZ());

        Swift.addTransientAvoidPoint(x, y, z, 1, Math.max(8, penalty * 0.45), Math.max(1, ttlSearches));

        const yaw = Number(Player.getYaw()) || 0;
        const yawRad = ((yaw + 90) * Math.PI) / 180;
        let fx = Math.round(Math.cos(yawRad));
        let fz = Math.round(Math.sin(yawRad));
        if (fx === 0 && fz === 0) fx = 1;

        const cluster = [
            [x + fx, y, z + fz, radius, penalty],
            [x + fx * 2, y, z + fz * 2, radius, penalty * 1.15],
            [x + fz, y, z - fx, Math.max(1, radius - 1), penalty * 0.7],
            [x - fz, y, z + fx, Math.max(1, radius - 1), penalty * 0.7],
        ];

        cluster.forEach((p) => {
            Swift.addTransientAvoidPoint(p[0], p[1], p[2], Math.max(1, Math.floor(p[3])), Number(p[4]) || penalty, ttlSearches);
        });
    }

    addAvoidPoints(points, radius = 2) {
        if (!Array.isArray(points)) return;

        points.forEach((point) => {
            if (!point) return;
            const x = Array.isArray(point) ? point[0] : point.x;
            const y = Array.isArray(point) ? point[1] : point.y;
            const z = Array.isArray(point) ? point[2] : point.z;
            Swift.addTransientAvoidPoint(x, y, z, radius, 1000, this.MAX_RECALCULATE_ATTEMPTS + 2);
        });
    }

    createEntityGoalOffsets(goals, target) {
        const position = this.getEntityPosition(target);
        if (!position || !Array.isArray(goals)) return null;

        const anchor = [Math.floor(position.x), Math.floor(position.y), Math.floor(position.z)];
        return goals.map((goal) => [goal[0] - anchor[0], goal[1] - anchor[1], goal[2] - anchor[2]]);
    }

    getEntityGoals() {
        const position = this.getEntityPosition(this.entityTarget);
        if (!position || !this.entityGoalOffsets) return null;

        const anchor = [Math.floor(position.x), Math.floor(position.y), Math.floor(position.z)];
        return this.entityGoalOffsets.map((offset) => [anchor[0] + offset[0], anchor[1] + offset[1], anchor[2] + offset[2]]);
    }

    resolveEntityTarget(result) {
        const resolver = this.entityTargetResolver;
        this.entityTargetResolver = null;

        try {
            const resolved = resolver(result);
            if (!resolved || !resolved.target || !Array.isArray(resolved.goals) || !resolved.goals.length) return false;

            this.entityTarget = resolved.target;
            this.currentEnd = resolved.goals;
            this.entityGoalOffsets = this.createEntityGoalOffsets(resolved.goals, resolved.target);
            return true;
        } catch (e) {
            console.error('Path entity target resolver error: ' + e);
            return false;
        }
    }

    applyPathRuntimeHints(result) {
        if (!result || this.isFly || Recovery.isStallRecoveryActive()) return;
        if (!Array.isArray(result.path_flags) || !result.path_flags.length) return;

        // path_flags is indexed by path node, not by look point.
        if (Jump.lastNearestIndex < 0) return;
        const pathIndex = Math.min(result.path_flags.length - 1, Jump.lastNearestIndex + 1);
        const flags = result.path_flags[pathIndex] || 0;

        const bits = Array.isArray(result.path_flag_bits) && result.path_flag_bits.length >= 8 ? result.path_flag_bits : null;
        const LOW_HEAD = bits ? bits[2] : 1 << 2;
        const NEAR_EDGE = bits ? bits[3] : 1 << 3;
        const TIGHT = bits ? bits[7] : 1 << 7;

        if (flags & LOW_HEAD) {
            Jump.suppressJump(4);
            Rotations.setTemporaryLookahead(Rotations.RECOVERY_MIN_LOOKAHEAD, 8);
            return;
        }

        if (flags & TIGHT || flags & NEAR_EDGE) {
            Rotations.setTemporaryLookahead(Math.max(Rotations.RECOVERY_MIN_LOOKAHEAD, 0.35), 6);
        }
    }

    retryRecalculate() {
        this.pathVariantSeed = Math.max(this.pathVariantSeed, this.recalculateAttempts);
        this.schedulePathRetry(5);
    }

    schedulePathRetry(delay) {
        const end = this.getEntityGoals() || this.currentEnd;
        const starts = this.currentStarts;
        const callback = this.currentCallback;
        const wasFromFile = this.calledFromFile;
        const attempts = this.recalculateAttempts;
        const walkArrivalRadius = this.walkArrivalRadius;
        const entityTarget = this.entityTarget;
        const entityTrackDistance = this.entityTrackDistance;
        const silent = this.silent;
        const scheduleId = ++this.recalculateScheduleId;

        this.resetPath(false);

        this.saidInfo = false;

        ScheduleTask(delay, () => {
            if (scheduleId !== this.recalculateScheduleId) return;

            this.currentEnd = end;
            this.currentStarts = starts;
            this.currentCallback = callback;
            this.calledFromFile = wasFromFile;
            this.recalculateAttempts = attempts;

            this.findPath(end, callback, {
                isFly: this.isFly,
                startPoints: starts,
                preserveRecalculateAttempts: true,
                walkArrivalRadius,
                entityTarget,
                entityTrackDistance,
                silent,
            });
        });
    }

    checkIfReachedDestination() {
        if (!this.currentEnd) return true;

        const player = Player.getPlayer();
        if (!player) return false;

        const pX = Player.getX(),
            pY = Player.getY(),
            pZ = Player.getZ();

        const entityPosition = this.getEntityPosition(this.entityTarget);
        if (entityPosition) {
            return (
                Math.hypot(pX - entityPosition.x, pZ - entityPosition.z) <= this.walkArrivalRadius &&
                Math.abs(pY - entityPosition.y) <= 2.5 &&
                Rotations.getEntityLookPoint(player.getEyePosition()) !== null
            );
        }

        const goals = this.currentEnd;

        for (const goal of goals) {
            const destX = goal[0];
            const destY = goal[1];
            const destZ = goal[2];

            const dx = pX - (this.isFly ? destX + 0.5 : destX);
            const dy = pY - destY;
            const dz = pZ - (this.isFly ? destZ + 0.5 : destZ);

            const hDistSq = dx * dx + dz * dz;
            const maxHorizontalDistance = this.isFly ? 1.25 : this.walkArrivalRadius;
            if (hDistSq > maxHorizontalDistance * maxHorizontalDistance) continue;

            if (this.isFly) {
                if (Math.abs(dy) > 1) continue;
                if (this.flyStarted && Math.hypot(Player.getMotionX(), Player.getMotionY(), Player.getMotionZ()) > 0.2) continue;
            } else {
                if (dy < -0.1 || dy > 5.5) continue;
            }

            if (this.isFly || player.onGround()) {
                return true;
            }
        }
        return false;
    }

    getEntityPosition(target) {
        if (!target) return null;

        try {
            const entity = target.toMC ? target.toMC() : target;
            if (!entity || entity.isRemoved?.() || entity.isDeadOrDying?.()) return null;
            return { x: entity.getX(), y: entity.getY(), z: entity.getZ() };
        } catch (e) {
            return null;
        }
    }

    finishSuccess() {
        if (!this.silent) showNotification('Path Complete', 'Destination reached!', 'SUCCESS', 2000);
        this.callCallback(true);
        this.resetPath();
    }

    callCallback(success) {
        if (typeof this.currentCallback === 'function') {
            try {
                this.currentCallback(success);
            } catch (e) {
                console.error('Path callback error:', e);
            }
        }
    }

    getPlayerStart() {
        const player = Player.getPlayer();
        if (!player) return null;

        const x = Math.floor(player.getX());
        const z = Math.floor(player.getZ());
        let y = Math.round(player.getY());

        for (let i = 0; i < 5; i++) {
            if (this.isBlockWalkable(x, y, z)) return { x, y: y - 1, z };
            y--;
        }
        return { x, y: Math.round(Player.getY()) - 1, z };
    }

    getPlayerFlyStart() {
        const player = Player.getPlayer();
        if (!player) return null;

        const point = this.resolveFlyPoint(player.getX(), player.getY(), player.getZ(), 4);
        if (point) return { x: point[0], y: point[1], z: point[2] };

        return {
            x: Math.floor(Player.getX()),
            y: Math.floor(Player.getY()),
            z: Math.floor(Player.getZ()),
        };
    }

    isBlockWalkable(x, y, z) {
        const world = World.getWorld();
        if (!world) return false;

        try {
            const pos = new BP(x, y, z);
            const state = world.getBlockState(pos);
            if (!state) return false;
            return state.getCollisionShape(world, pos).isEmpty();
        } catch (e) {
            return false;
        }
    }

    isFlyPositionClear(x, y, z) {
        try {
            return PathManager.isFlyPositionClear(x, y, z);
        } catch (e) {
            return false;
        }
    }

    // Walk goals are the block stood on; F3 feet coordinates are one higher (air), which never resolves.
    resolveWalkPoint(x, y, z, verticalSearch = 3) {
        const baseX = Math.floor(x);
        const baseY = Math.floor(y);
        const baseZ = Math.floor(z);
        const isStandable = (groundY) =>
            !this.isBlockWalkable(baseX, groundY, baseZ) && this.isBlockWalkable(baseX, groundY + 1, baseZ) && this.isBlockWalkable(baseX, groundY + 2, baseZ);

        for (const offset of [0, -1, 1, -2, 2, -3, 3].filter((o) => Math.abs(o) <= verticalSearch)) {
            if (isStandable(baseY + offset)) return [baseX, baseY + offset, baseZ];
        }
        return [baseX, baseY, baseZ];
    }

    resolveFlyPoint(x, y, z, verticalSearch = 3) {
        const baseX = Math.floor(x);
        const baseY = Math.floor(y);
        const baseZ = Math.floor(z);

        if (this.isFlyPositionClear(baseX, baseY, baseZ)) {
            return [baseX, baseY, baseZ];
        }

        for (let offset = 1; offset <= verticalSearch; offset++) {
            const upY = baseY + offset;
            if (this.isFlyPositionClear(baseX, upY, baseZ)) {
                return [baseX, upY, baseZ];
            }

            const downY = baseY - offset;
            if (this.isFlyPositionClear(baseX, downY, baseZ)) {
                return [baseX, downY, baseZ];
            }
        }

        return null;
    }

    createStartPoints(startPoints) {
        if (startPoints) {
            const validStarts = startPoints
                .filter((point) => Array.isArray(point) && point.length >= 3)
                .map((point) => [Number(point[0]), Number(point[1]), Number(point[2])])
                .filter((point) => point.every((v) => Number.isFinite(v)))
                .map((point) => [Math.floor(point[0]), Math.floor(point[1]), Math.floor(point[2])]);

            return {
                points: validStarts,
                metadata: validStarts.map((point) => ({
                    type: 'custom',
                    point: [point[0], point[1], point[2]],
                })),
            };
        }

        const points = [];
        const metadata = [];

        const start = this.isFly ? this.getPlayerFlyStart() : this.getPlayerStart();
        if (!start) {
            return { points, metadata };
        }

        const playerPoint = [start.x, start.y, start.z];

        if (!this.isFly) {
            const variantPoint = this.getVariantWalkStart(playerPoint, this.pathVariantSeed);
            if (variantPoint) {
                points.push(variantPoint);
                metadata.push({
                    type: 'player_variant',
                    point: [variantPoint[0], variantPoint[1], variantPoint[2]],
                    seed: this.pathVariantSeed,
                });
            }
        }

        points.push(playerPoint);
        metadata.push({
            type: 'player',
            point: [playerPoint[0], playerPoint[1], playerPoint[2]],
        });

        if (this.isFly) {
            return { points, metadata };
        }

        PathConfig.getAreaWarpPoints(area()).forEach((warpPoint) => {
            const point = [warpPoint.x, warpPoint.y, warpPoint.z];
            points.push(point);
            metadata.push({
                type: 'warp',
                warp: warpPoint.warp,
                area: warpPoint.area,
                point: [point[0], point[1], point[2]],
            });
        });

        return { points, metadata };
    }

    getVariantWalkStart(playerPoint, seed = 0) {
        if (!Array.isArray(playerPoint) || playerPoint.length < 3 || !Number.isFinite(seed) || seed <= 0) {
            return null;
        }

        const [baseX, baseY, baseZ] = playerPoint;
        const offsets = [
            [1, 0],
            [0, 1],
            [-1, 0],
            [0, -1],
            [1, 1],
            [1, -1],
            [-1, 1],
            [-1, -1],
            [2, 0],
            [0, 2],
            [-2, 0],
            [0, -2],
        ];

        const startIndex = seed % offsets.length;
        for (let i = 0; i < offsets.length; i++) {
            const idx = (startIndex + i) % offsets.length;
            const [dx, dz] = offsets[idx];
            const x = baseX + dx;
            const z = baseZ + dz;

            if (this.isWalkColumnValid(x, baseY, z)) {
                return [x, baseY, z];
            }
        }

        return null;
    }

    isWalkColumnValid(x, groundY, z) {
        if (this.isBlockWalkable(x, groundY, z)) return false;
        return this.isBlockWalkable(x, groundY + 1, z) && this.isBlockWalkable(x, groundY + 2, z);
    }

    handleStartPointWarp(result) {
        if (!this.selectedStartCandidate) {
            this.selectedStartCandidate = this.resolvePathStartCandidate(result);
        }
        if (!this.selectedStartCandidate) {
            return true;
        }

        if (this.selectedStartCandidate.type !== 'warp') {
            return true;
        }

        if (this.isPlayerAtWarpPoint(this.selectedStartCandidate.point)) {
            return true;
        } else {
            this.issueWarpCommand();
            return false;
        }
    }

    issueWarpCommand() {
        const warpName = this.selectedStartCandidate?.warp;
        if (!warpName) return;

        if (!this.warpCommandIssued) {
            this.warpCommandIssued = true;
            this.warpLastAttemptAt = Date.now();
            ChatLib.command(`warp ${warpName}`);
            return;
        }

        const now = Date.now();
        if (now - this.warpLastAttemptAt < this.WARP_RETRY_TIMEOUT_MS) {
            return;
        }

        if (this.warpRetryCount >= this.MAX_WARP_RETRIES) {
            this.failWarpPathfinding();
            return;
        }

        this.warpRetryCount++;
        this.warpCommandIssued = true;
        this.warpLastAttemptAt = now;
        ChatLib.command(`warp ${warpName}`);
        return;
    }

    failWarpPathfinding() {
        const warpName = this.selectedStartCandidate?.warp || 'unknown';
        chatPathfinder(`§cFailed to warp to ${warpName} after ${this.MAX_WARP_RETRIES} retries.`);
        showNotification('Pathfinding Failed', `Warp ${warpName} failed after ${this.MAX_WARP_RETRIES} retries.`, 'ERROR', 5000);
        this.callCallback(false);
        this.resetPath();
    }

    isPlayerAtWarpPoint(point) {
        if (this.hasReachedWarpPoint) return true;

        const dist = getDistanceToPlayer(point[0], point[1], point[2]);
        if (dist.distance <= 9) {
            this.hasReachedWarpPoint = true;
            return true;
        }

        return false;
    }

    resolvePathStartCandidate(result) {
        const selectedStartIndex = typeof result?.selected_start_index === 'number' ? result.selected_start_index : -1;
        if (selectedStartIndex >= 0 && selectedStartIndex < this.startCandidates.length) {
            return this.startCandidates[selectedStartIndex];
        }

        const firstNode = result?.path?.[0];
        if (!firstNode) return this.startCandidates[0];

        let bestCandidate = this.startCandidates[0];
        let bestDistance = Number.MAX_VALUE;

        this.startCandidates.forEach((candidate) => {
            if (!candidate?.point || candidate.point.length < 3) return;
            const distance = this.getStartNodeDistanceSq(firstNode, candidate.point);
            if (distance < bestDistance) {
                bestDistance = distance;
                bestCandidate = candidate;
            }
        });

        return bestCandidate;
    }

    getStartNodeDistanceSq(node, point) {
        const compareY = point[1];
        const dx = node.x - point[0];
        const dy = node.y - compareY;
        const dz = node.z - point[2];
        return dx * dx + dy * dy + dz * dz;
    }

    createSplinePath(path) {
        if (!path) return null;
        const nodes = path.path_between_key_nodes?.length ? path.path_between_key_nodes : path.keynodes;
        return nodes?.length ? generateSpline(nodes, 1) : null;
    }

    getCachedWalkSplinePath(result) {
        if (!result) return null;
        if (this.cachedWalkSplineResult === result && this.cachedWalkSplinePath) {
            return this.cachedWalkSplinePath;
        }

        const spline = this.createSplinePath(result);
        this.cachedWalkSplineResult = result;
        this.cachedWalkSplinePath = spline;
        return spline;
    }

    clearPathCaches() {
        this.cachedPathResult = null;
        this.cachedWalkSplinePath = null;
        this.cachedWalkSplineResult = null;
    }

    startRender(result, splinePath) {
        if (this.render) return;

        this.render = register('postRenderWorld', () => {
            if (PathConfig.RENDER_KEY_NODES && result.keynodes?.length >= 2) {
                Render3D.drawStyledBoxes(
                    result.keynodes.map((node) => new Vec3d(node.x, node.y, node.z)),
                    new RenderColor(0, 100, 200, 120),
                    new RenderColor(0, 100, 200, 255),
                    4,
                    true
                );
            }
            if (PathConfig.RENDER_FLOATING_SPLINE) drawFloatingSpline(splinePath);
            if (PathConfig.RENDER_LOOK_POINTS) drawLookPoints();
        });
    }

    destroyTick() {
        if (this.tick) {
            this.tick.unregister();
            this.tick = null;
        }
    }

    destroyRender() {
        if (this.render) {
            this.render.unregister();
            this.render = null;
        }
    }

    resetPath(clearFlags = true) {
        this.destroyTick();
        this.destroyRender();
        destroyPathExecutor();
        Rotations.resetRotations();
        PathFlyer.reset();
        clearSplineCache();
        Jump.reset();
        Aote.stop(clearFlags);
        stopMovement();
        if (clearFlags) {
            Recovery.stop();
            NonChangeRecovery.stop();
        } else {
            Recovery.resetTracking();
            NonChangeRecovery.resetTracking();
        }
        Swift.cancel();
        Swift.clear();
        if (clearFlags) {
            Swift.clearTransientAvoidPoints();
        }

        this.flyStarted = false;
        this.flyStartDelayTicks = 0;
        this.flySplinePath = null;
        this.clearPathCaches();
        this.startCandidates = [];
        this.selectedStartCandidate = null;
        this.searchStartedAt = 0;
        this.warpCommandIssued = false;
        this.warpRetryCount = 0;
        this.warpLastAttemptAt = 0;
        this.hasReachedWarpPoint = false;

        if (clearFlags) {
            this.recalculateScheduleId++;
            this.saidInfo = false;
            this.calledFromFile = false;
            this.currentEnd = null;
            this.currentStarts = null;
            this.currentCallback = null;
            this.entityTarget = null;
            this.entityTargetResolver = null;
            this.entityGoalOffsets = null;
            this.entityTrackDistance = 8;
            this.silent = false;
            this.recalculateAttempts = 0;
            this.recalculateRetryQueued = false;
            this.pathVariantSeed = 0;
            this.lastPathSignature = '';
            this.samePathSignatureCount = 0;
            this.isFly = false;
        }
    }

    isPathing() {
        return !!this.tick;
    }

    getResult() {
        if (this.cachedPathResult) return this.cachedPathResult;

        const result = Swift.getResult();
        if (result) this.cachedPathResult = result;
        return result;
    }
}

const Pathfinder = new Finder();
export default Pathfinder;

import { Color } from '../../utils/Constants';
import { setTooltip } from '../core/GuiTooltip';
import {
    clamp,
    createHighlight,
    drawRoundedRectangle,
    drawRoundedRectangleWithBorder,
    drawText,
    easeInOutQuad,
    FontSizes,
    getTextWidth,
    isInside,
    PADDING,
    playClickSound,
    THEME,
} from '../Utils';

export class ColorPicker {
    constructor(title, x, y, defaultColor, callback) {
        this.title = title;
        this.x = x;
        this.y = y;
        this.callback = callback;

        let safeDefault = defaultColor;
        if (typeof safeDefault === 'number') {
            safeDefault = safeDefault | 0;
        }

        this.color = safeDefault instanceof Color ? safeDefault : new Color(safeDefault);

        const hsv = java.awt.Color.RGBtoHSB(this.color.getRed(), this.color.getGreen(), this.color.getBlue(), null);
        this.hue = hsv[0];
        this.sat = hsv[1];
        this.val = hsv[2];
        this.alpha = this.color.getAlpha() / 255;

        this.expanded = false;
        this.height = 24;
        this.outerPadding = 10;
        this.expandedHeight = 193;
        this.optionPanelWidth = 0;
        this.panelPaddingY = 10;

        this.draggingHue = false;
        this.draggingSV = false;
        this.draggingAlpha = false;

        this.animStart = 0;
        this.animFrom = 0;
        this.animTo = 0;
        this.animDuration = 220;
        this.animationProgress = 0;
        this.description = null;
        this.highlight = createHighlight();
    }

    startAnimation(expanding) {
        this.animStart = Date.now();
        this.animFrom = this.animationProgress;
        this.animTo = expanding ? 1 : 0;
    }

    updateAnimation() {
        if (this.animStart === 0) return;
        const elapsed = Date.now() - this.animStart;
        const t = Math.min(elapsed / this.animDuration, 1);
        const eased = easeInOutQuad(t);
        this.animationProgress = this.animFrom + (this.animTo - this.animFrom) * eased;
        if (t >= 1) this.animStart = 0;
    }

    startHighlight() {
        this.highlight.startHighlight();
    }

    drawHighlight(panelWidth, panelHeight) {
        this.highlight.draw({
            x: this.x,
            y: this.y,
            width: panelWidth,
            height: panelHeight,
            accentColor: THEME.ACCENT,
            accentFillColor: THEME.ACCENT_DIM,
        });
    }

    getExpandedHeight() {
        return this.expandedHeight + this.outerPadding;
    }

    hsvToRgb(h, s, v, a) {
        const rgb = java.awt.Color.HSBtoRGB(h, s, v);
        const r = (rgb >> 16) & 0xff;
        const g = (rgb >> 8) & 0xff;
        const b = rgb & 0xff;
        return new Color(r / 255, g / 255, b / 255, a);
    }

    updateColor() {
        this.color = this.hsvToRgb(this.hue, this.sat, this.val, this.alpha);
        if (this.callback) this.callback(this.color);
    }

    colorToHex(color) {
        const r = color.getRed().toString(16).padStart(2, '0');
        const g = color.getGreen().toString(16).padStart(2, '0');
        const b = color.getBlue().toString(16).padStart(2, '0');
        const a = color.getAlpha().toString(16).padStart(2, '0');
        return (r + g + b + (this.alpha < 1 ? a : '')).toUpperCase();
    }

    drawCheckerboard(x, y, width, height, radius, cellSize = 4) {
        Render2D.drawCheckerboard(x, y, width, height, radius, cellSize);
    }

    drawHandle(x, y, size, isCircle = true) {
        // shadow!
        drawRoundedRectangle({
            x: x - size / 2 - 1,
            y: y - size / 2 + 1,
            width: size + 2,
            height: size + 2,
            radius: isCircle ? (size + 2) / 2 : 3,
            color: new Color(0, 0, 0, 0.4),
        });

        // border
        drawRoundedRectangle({
            x: x - size / 2 - 1,
            y: y - size / 2 - 1,
            width: size + 2,
            height: size + 2,
            radius: isCircle ? (size + 2) / 2 : 3,
            color: new Color(0.15, 0.15, 0.15, 1),
        });

        // middle white
        drawRoundedRectangle({
            x: x - size / 2,
            y: y - size / 2,
            width: size,
            height: size,
            radius: isCircle ? size / 2 : 2,
            color: new Color(1, 1, 1, 1),
        });
    }

    drawSliderHandle(x, y, width, height) {
        drawRoundedRectangle({
            x: x + 1,
            y: y + 1,
            width: width,
            height: height,
            radius: 3,
            color: new Color(0, 0, 0, 0.3),
        });

        drawRoundedRectangleWithBorder({
            x: x,
            y: y,
            width: width,
            height: height,
            radius: 3,
            color: new Color(1, 1, 1, 1),
            borderWidth: 1,
            borderColor: new Color(0.7, 0.7, 0.7, 1),
        });
    }

    draw(mouseX, mouseY) {
        this.updateAnimation();

        const panelWidth = this.optionPanelWidth - PADDING * 2;
        const collapsedHeight = 24;

        this.drawHighlight(panelWidth, collapsedHeight);

        drawText(this.title, this.x, this.y + collapsedHeight / 2, FontSizes.REGULAR, THEME.TEXT);

        const previewSize = 18;
        const previewX = this.x + panelWidth - previewSize;
        const previewY = this.y + (collapsedHeight - previewSize) / 2;

        this.drawCheckerboard(previewX, previewY, previewSize, previewSize, 6, 4);

        drawRoundedRectangle({
            x: previewX,
            y: previewY,
            width: previewSize,
            height: previewSize,
            radius: 6,
            color: this.color,
        });
        Render2D.drawHollowRect(previewX, previewY, previewSize, previewSize, 2, THEME.BORDER.getRGB(), 6);

        const arrowSize = 10;
        const arrowX = previewX - arrowSize - 6;
        const arrowY = this.y + (collapsedHeight - arrowSize) / 2;

        const isArrowHovered = isInside(mouseX, mouseY, {
            x: arrowX,
            y: arrowY,
            width: arrowSize,
            height: arrowSize,
        });

        drawRoundedRectangle({
            x: arrowX,
            y: arrowY,
            width: arrowSize,
            height: arrowSize,
            radius: 4,
            color: isArrowHovered ? THEME.HOVER : THEME.BG_INSET,
        });

        const arrow = this.expanded ? '▼' : '▶';
        const arrowFontSize = FontSizes.SMALL;
        const centeredArrowY = arrowY + arrowSize / 2 + arrowFontSize / 2 - 3;

        drawText(arrow, arrowX + arrowSize / 2, centeredArrowY, arrowFontSize, THEME.TEXT, 18);

        const componentRect = {
            x: this.x,
            y: this.y,
            width: panelWidth,
            height: collapsedHeight,
        };
        if (this.description && isInside(mouseX, mouseY, componentRect)) {
            setTooltip(this.description);
        }

        if (this.animationProgress > 0) {
            const contentY = this.y + collapsedHeight + 4;
            const fullHeight = this.expandedHeight;
            const animatedHeight = fullHeight * this.animationProgress;

            drawRoundedRectangleWithBorder({
                x: this.x,
                y: contentY,
                width: panelWidth,
                height: animatedHeight,
                radius: 10,
                color: THEME.BG_COMPONENT,
                borderWidth: 1,
                borderColor: THEME.BORDER,
            });

            if (this.animationProgress > 0.3) {
                const pickerPadding = 12;
                const innerWidth = panelWidth - pickerPadding * 2;
                const svHeight = 95;
                const svY = contentY + this.panelPaddingY;
                const svX = this.x + pickerPadding;

                const hueColorInt = java.awt.Color.HSBtoRGB(this.hue, 1, 1) | 0;
                const whiteColorInt = new Color(1, 1, 1, 1).getRGB() | 0;
                Render2D.drawGradientRect(svX, svY, innerWidth, svHeight, whiteColorInt, hueColorInt, 'LeftToRight', 6);

                const transparentInt = new Color(0, 0, 0, 0).getRGB() | 0;
                const blackInt = new Color(0, 0, 0, 1).getRGB() | 0;
                Render2D.drawGradientRect(svX, svY, innerWidth, svHeight, transparentInt, blackInt, 'TopToBottom', 6);

                Render2D.drawHollowRect(svX - 1, svY - 1, innerWidth + 2, svHeight + 2, 1, THEME.BORDER.getRGB(), 7);

                const pickerX = svX + this.sat * innerWidth;
                const pickerY = svY + (1 - this.val) * svHeight;
                this.drawHandle(pickerX, pickerY, 12, true);

                const barHeight = 14;
                const barSpacing = 10;
                const hueY = svY + svHeight + barSpacing;

                Render2D.drawHueBar(svX, hueY, innerWidth, barHeight, 5);
                Render2D.drawHollowRect(svX - 1, hueY - 1, innerWidth + 2, barHeight + 2, 1, THEME.BORDER.getRGB(), 5);

                const hueSliderX = svX + this.hue * innerWidth;
                this.drawSliderHandle(hueSliderX - 3, hueY - 2, 6, barHeight + 4);

                const alphaY = hueY + barHeight + barSpacing;

                this.drawCheckerboard(svX, alphaY, innerWidth, barHeight, 5, 4);

                const cTransInt = new Color(this.color.getRed() / 255, this.color.getGreen() / 255, this.color.getBlue() / 255, 0).getRGB() | 0;
                const cSolidInt = new Color(this.color.getRed() / 255, this.color.getGreen() / 255, this.color.getBlue() / 255, 1).getRGB() | 0;
                Render2D.drawGradientRect(svX, alphaY, innerWidth, barHeight, cTransInt, cSolidInt, 'LeftToRight', 5);

                Render2D.drawHollowRect(svX - 1, alphaY - 1, innerWidth + 2, barHeight + 2, 1, THEME.BORDER.getRGB(), 5);

                const alphaSliderX = svX + this.alpha * innerWidth;
                this.drawSliderHandle(alphaSliderX - 3, alphaY - 2, 6, barHeight + 4);

                const infoY = alphaY + barHeight + this.panelPaddingY;

                const hexColor = this.colorToHex(this.color);
                const hexText = `#${hexColor}`;
                const hexWidth = getTextWidth(hexText, FontSizes.REGULAR) + 16;

                drawRoundedRectangle({
                    x: svX,
                    y: infoY,
                    width: hexWidth,
                    height: 20,
                    radius: 4,
                    color: THEME.BG_INSET,
                });
                drawText(hexText, svX + 8, infoY + 10, FontSizes.REGULAR, THEME.TEXT);

                const alphaPercent = `${Math.round(this.alpha * 100)}%`;
                const alphaTextWidth = getTextWidth(alphaPercent, FontSizes.REGULAR);

                drawRoundedRectangle({
                    x: svX + innerWidth - alphaTextWidth - 16,
                    y: infoY,
                    width: alphaTextWidth + 16,
                    height: 20,
                    radius: 4,
                    color: THEME.BG_INSET,
                });
                drawText(alphaPercent, svX + innerWidth - alphaTextWidth - 8, infoY + 10, FontSizes.REGULAR, THEME.TEXT);
            }
        }
    }

    handleClick(mouseX, mouseY) {
        const panelWidth = this.optionPanelWidth - PADDING * 2;
        const collapsedHeight = 24;

        if (mouseX >= this.x && mouseX <= this.x + panelWidth && mouseY >= this.y && mouseY <= this.y + collapsedHeight) {
            this.expanded = !this.expanded;
            this.startAnimation(this.expanded);
            playClickSound();
            return true;
        }

        if (this.expanded && this.animationProgress > 0.5) {
            const pickerPadding = 12;
            const innerWidth = panelWidth - pickerPadding * 2;
            const svHeight = 95;
            const contentY = this.y + collapsedHeight + 4;
            const svY = contentY + this.panelPaddingY;
            const svX = this.x + pickerPadding;

            if (mouseX >= svX && mouseX <= svX + innerWidth && mouseY >= svY && mouseY <= svY + svHeight) {
                this.draggingSV = true;
                this.handleMouseDrag(mouseX, mouseY);
                return true;
            }

            const barHeight = 14;
            const barSpacing = 10;
            const hueY = svY + svHeight + barSpacing;

            if (mouseX >= svX && mouseX <= svX + innerWidth && mouseY >= hueY && mouseY <= hueY + barHeight) {
                this.draggingHue = true;
                this.handleMouseDrag(mouseX, mouseY);
                return true;
            }

            const alphaY = hueY + barHeight + barSpacing;

            if (mouseX >= svX && mouseX <= svX + innerWidth && mouseY >= alphaY && mouseY <= alphaY + barHeight) {
                this.draggingAlpha = true;
                this.handleMouseDrag(mouseX, mouseY);
                return true;
            }
        }
        return false;
    }

    handleMouseDrag(mouseX, mouseY) {
        if (!this.expanded) return;
        const panelWidth = this.optionPanelWidth - PADDING * 2;
        const pickerPadding = 12;
        const innerWidth = panelWidth - pickerPadding * 2;
        const svHeight = 95;
        const contentY = this.y + 24 + 4;
        const svY = contentY + this.panelPaddingY;
        const svX = this.x + pickerPadding;

        if (this.draggingSV) {
            this.sat = clamp((mouseX - svX) / innerWidth, 0, 1);
            this.val = clamp(1 - (mouseY - svY) / svHeight, 0, 1);
            this.updateColor();
        } else if (this.draggingHue) {
            this.hue = clamp((mouseX - svX) / innerWidth, 0, 0.9999);
            this.updateColor();
        } else if (this.draggingAlpha) {
            this.alpha = clamp((mouseX - svX) / innerWidth, 0, 1);
            this.updateColor();
        }
    }

    handleMouseRelease() {
        this.draggingHue = false;
        this.draggingSV = false;
        this.draggingAlpha = false;
    }
}
